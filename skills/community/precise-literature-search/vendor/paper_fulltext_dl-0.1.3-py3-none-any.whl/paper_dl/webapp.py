"""Compatibility entry point for the dedicated maintenance Chrome launcher.

The core edition retains this import path without the former web server or UI.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any
from urllib.parse import urlparse
import httpx

DEFAULT_CDP_ENDPOINT = "http://127.0.0.1:9222"
CHROME_LAUNCH_WAIT_S = 12.0


def _safe_local_endpoint(value: str, *, default: str) -> str:
    endpoint = (value or default).strip().rstrip("/")
    parsed = urlparse(endpoint)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Endpoint must use http:// or https://")
    if parsed.hostname not in {"localhost", "127.0.0.1"}:
        raise ValueError("Endpoint must point to this computer (localhost)")
    if parsed.path not in {"", "/"}:
        raise ValueError("Endpoint must not contain a path")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Endpoint must not contain credentials, a query, or a fragment")
    return endpoint


def _probe(url: str, timeout: float = 1.5) -> tuple[bool, str]:
    try:
        with httpx.Client(trust_env=False, follow_redirects=False, timeout=timeout) as client:
            response = client.get(url)
            status = response.status_code
            if 200 <= status < 300 and response.json().get("Browser"):
                return True, "Connected"
            return False, f"Responded with HTTP {status}"
    except Exception as exc:  # noqa: BLE001 - readiness errors are user-facing
        return False, f"Not reachable ({type(exc).__name__})"


def _find_chrome_executable() -> Path:
    configured = os.environ.get("PAPER_DL_CHROME_EXECUTABLE", "").strip()
    if configured:
        executable = Path(configured).expanduser()
        if executable.is_file():
            return executable
        raise RuntimeError(
            "PAPER_DL_CHROME_EXECUTABLE does not point to a Chrome executable"
        )

    candidates: list[Path] = []
    if sys.platform == "darwin":
        relative_apps = (
            "Google Chrome.app/Contents/MacOS/Google Chrome",
            "Google Chrome Beta.app/Contents/MacOS/Google Chrome Beta",
            "Chromium.app/Contents/MacOS/Chromium",
        )
        candidates.extend(
            Path(root) / relative
            for root in ("/Applications", Path.home() / "Applications")
            for relative in relative_apps
        )
    elif sys.platform == "win32":
        for root_name in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            root = os.environ.get(root_name)
            if root:
                candidates.extend((
                    Path(root) / "Google/Chrome/Application/chrome.exe",
                    Path(root) / "Chromium/Application/chrome.exe",
                ))
    else:
        for name in (
            "google-chrome",
            "google-chrome-stable",
            "chromium",
            "chromium-browser",
        ):
            resolved = shutil.which(name)
            if resolved:
                candidates.append(Path(resolved))

    executable = next((candidate for candidate in candidates if candidate.is_file()), None)
    if executable is None:
        raise RuntimeError(
            "Chrome could not be found. Install Chrome or set "
            "PAPER_DL_CHROME_EXECUTABLE, then use the manual launch command."
        )
    return executable


def launch_debug_chrome(
    endpoint: str = DEFAULT_CDP_ENDPOINT,
    *,
    profile_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Launch a dedicated local Chrome profile with DevTools enabled."""
    base_url = _safe_local_endpoint(endpoint, default=DEFAULT_CDP_ENDPOINT)
    parsed = urlparse(base_url)
    if parsed.scheme != "http":
        raise ValueError("Automatic Chrome launch requires a local http:// endpoint")
    try:
        port = parsed.port if parsed.port is not None else 80
    except ValueError as exc:
        raise ValueError("Chrome DevTools endpoint has an invalid port") from exc
    if not 1 <= port <= 65535:
        raise ValueError("Chrome DevTools endpoint port must be between 1 and 65535")

    connected, message = _probe(f"{base_url}/json/version")
    if connected:
        return {
            "ok": True,
            "launched": False,
            "message": "Chrome is already connected",
            "endpoint": base_url,
        }

    executable = _find_chrome_executable()
    configured_profile = os.environ.get("PAPER_DL_CHROME_PROFILE_DIR", "").strip()
    profile = Path(
        profile_dir
        or configured_profile
        or (Path.cwd() / ".chrome-cdp-profile")
    ).expanduser().resolve()
    try:
        profile.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(f"Chrome profile could not be created: {exc}") from exc

    command = [
        str(executable),
        "--remote-debugging-address=127.0.0.1",
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile}",
        "--no-first-run",
        "--no-default-browser-check",
    ]
    try:
        subprocess.Popen(  # noqa: S603 - executable is resolved from trusted local paths
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        raise RuntimeError(f"Chrome could not launch: {exc}") from exc

    deadline = time.monotonic() + CHROME_LAUNCH_WAIT_S
    while time.monotonic() < deadline:
        time.sleep(0.25)
        connected, message = _probe(f"{base_url}/json/version", timeout=0.5)
        if connected:
            return {
                "ok": True,
                "launched": True,
                "message": "Chrome launched and connected",
                "endpoint": base_url,
                "profile_dir": str(profile),
            }
    return {
        "ok": False,
        "launched": True,
        "message": (
            "Chrome opened, but its DevTools endpoint is not ready yet. "
            f"Wait a moment and check again ({message})."
        ),
        "endpoint": base_url,
        "profile_dir": str(profile),
    }
