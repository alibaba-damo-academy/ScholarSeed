"""Resolve paper identifiers, acquire full text and persist original files."""

from __future__ import annotations

import os
from pathlib import Path
import tempfile
import time
from typing import Optional
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from .browser_engine import BrowserEngine, BrowserUnavailable, EngineResult
from .classify import Evidence, classify_failure
from .config import ServiceConfig
from .deadline import (
    ItemDeadlineExceeded,
    acquisition_stage,
    check as check_item_deadline,
    paper_deadline,
)
from . import http_fallback
from .identifiers import parse_many
from .item_worker import (
    PersistentItemWorker,
    WorkerFailure,
    WorkerPageHandle,
)
from .institution_access import (
    InstitutionAccessMemory,
    MEMORY_FILENAME,
    NEEDS_LOGIN,
    NO_ACCESS,
)
from .models import (
    BatchReport,
    DownloadAttempt,
    DownloadResult,
    DiscoveryProvenance,
    Identifier,
    IdentifierKind,
    Status,
    UnableReason,
)
from .pdfutil import is_pdf_bytes, pdf_page_count, validate_pdf_identity
from .resolver import Candidate, publisher_for_doi, resolve
from .storage import LibraryStore
from .zotero import ZoteroConnector
from datetime import datetime, timezone


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _worker_timeout_context(logs: tuple[str, ...]) -> tuple[bool, bool, str]:
    """Recover active challenge/login state and the last page from worker logs."""
    challenge_active = False
    login_active = False
    last_url = ""
    for message in logs:
        low = message.lower()
        for marker in ("opening landing:", "landed on:"):
            marker_at = low.find(marker)
            if marker_at >= 0:
                candidate = message[marker_at + len(marker):].strip()
                if candidate.startswith(("http://", "https://")):
                    last_url = candidate.split()[0].rstrip(".,;)")

        if ("challenge did not clear" in low
                or "captcha still unsolved" in low
                or "bot challenge present" in low
                or "captcha / bot challenge detected" in low
                or "challenge needs manual solve" in low):
            challenge_active = True
        elif "challenge cleared" in low:
            challenge_active = False

        if ("institutional login required" in low
                or "institutional authentication" in low):
            login_active = True

    hostname = (urlparse(last_url).hostname or "").lower()
    if hostname == "liblynx.com" or hostname.endswith(".liblynx.com"):
        login_active = True
    return challenge_active, login_active, last_url


def _atomic_write_text(path: Path, text: str) -> None:
    """Durably replace a text artifact without exposing a partial file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path: Optional[Path] = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.tmp-",
            delete=False,
        ) as handle:
            tmp_path = Path(handle.name)
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, path)
        tmp_path = None
    finally:
        if tmp_path is not None:
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass


def _engine_result_from_http(fr, prefix: str = "") -> EngineResult:
    """Wrap a failed HTTP FetchResult as an EngineResult, carrying the status so the
    failure classifier can tell access-denied apart from a generic miss. A direct
    403/401 is reported as access_denied; a 404 is NOT treated as not_found here —
    on a direct/OA PDF URL it usually means a dead mirror, not a missing paper (that
    verdict is reserved for a landing-page 404, handled in the browser engine)."""
    detail = (prefix + fr.detail) if prefix else fr.detail
    er = EngineResult(ok=False, detail=detail, http_status=fr.status or None)
    if fr.status in (401, 403):
        er.access_denied = True
    return er


class PaperDownloadService:
    def __init__(self, config: Optional[ServiceConfig] = None, *, logger=None,
                 solver=None, skip_controller=None, isolate_items: bool = False):
        self.cfg = config or ServiceConfig()
        self.store = LibraryStore(self.cfg)
        self.log = logger or (lambda *a, **k: None)
        # Optional ChallengeSolver (paper_dl.challenge); None = hands-off human wait.
        self._solver = solver
        self._skip_controller = skip_controller
        # CLI downloads run each paper in a persistent child service. Healthy
        # papers reuse its browser; only a hung paper loses and restarts it. The
        # opt-in constructor flag keeps the embeddable API and existing test
        # monkeypatch boundaries backward compatible.
        self._isolate_items = bool(isolate_items)
        self._item_worker: Optional[PersistentItemWorker] = None
        self._worker_login_pages: set[int] = set()
        self._engine: Optional[BrowserEngine] = None
        self._browser_error: Optional[str] = None
        self._zotero: Optional[ZoteroConnector] = None
        self._zotero_wait_fn = None
        self._failed_domains: dict[str, int] = {}  # domain -> failure count
        # Durable match keys (DOI prefix / known resolver publisher / observed
        # host) mapped to safe platform labels. The file is one level above the
        # output directory so sibling run folders share it; it never contains
        # URLs, cookies, credentials, or paper identifiers.
        self._institution_access_memory = InstitutionAccessMemory(
            self.cfg.output_path.parent / MEMORY_FILENAME,
            logger=self.log,
        )
        self._institution_login_gates = (
            self._institution_access_memory.key_to_platform
        )
    # -- public API ----------------------------------------------------------
    def download(self, item: str | Identifier) -> DownloadResult:
        return self.download_many([item]).results[0]

    def download_many(self, items) -> BatchReport:
        idents = self._coerce(items)
        self._institution_access_memory.load()
        report = BatchReport()
        try:
            for i, ident in enumerate(idents):
                if i:
                    time.sleep(self.cfg.inter_request_delay_s)
                if self._skip_controller is not None:
                    self._skip_controller.begin_item(ident.value or ident.original)
                try:
                    self.log(f"[{i+1}/{len(idents)}] {ident.kind.value}: {ident.value or ident.original}")
                    res = self._download_one(ident)
                    report.results.append(res)
                    # Preserve every completed item even if a later browser or
                    # network operation hangs and the process is interrupted.
                    # finished_at intentionally remains null until the full batch
                    # reaches normal completion.
                    self._write_report(report)
                finally:
                    if self._skip_controller is not None:
                        self._skip_controller.end_item()
        finally:
            # In keep-open (debug) mode the caller closes the engine after
            # inspecting the window (see CLI / PaperDownloadService.close()).
            if not self.cfg.browser.keep_open and not self._worker_login_pages:
                self._close_item_worker()
                self._close_engine()
        report.finished_at = _now()
        self._write_report(report)
        return report


    def close(self) -> None:
        """Close the browser engine (used to tear down a keep_open session)."""
        self._close_item_worker()
        self._close_engine()

    def restart_engine(self) -> None:
        """Tear down the current browser and clear errors so the next request
        opens a fresh context. The persistent profile keeps cookies (incl. a
        solved Cloudflare cf_clearance), so a fresh context skips the challenge."""
        if self._item_worker is not None:
            try:
                self._item_worker.restart_engine(
                    max(5.0, float(self.cfg.per_request_timeout_s))
                )
                self._worker_login_pages.clear()
            except WorkerFailure as exc:
                self.log(f"    worker browser restart failed: {exc}; replacing worker")
                self._close_item_worker(force=True)
            self._browser_error = None
            return
        self._close_engine()
        self._browser_error = None
        time.sleep(1.5)   # let the old Chrome fully exit and release the profile lock

    def retry_failed(
        self,
        prev: BatchReport,
        *,
        exclude_reasons: Optional[set[UnableReason]] = None,
    ) -> BatchReport:
        """Re-attempt the not-ok items from a prior report, reusing the SAME browser
        profile so a human-solved Cloudflare clearance (cf_clearance) is kept — a
        fresh context then skips the challenge. Re-resolves from each identifier's
        original string (the cache holds nothing for a failed item). Successful
        rows stay in the batch report, while retried rows are replaced in place.
        """
        excluded = exclude_reasons or set()
        failed = [r for r in prev.results
                  if not r.ok and r.reason not in excluded]
        if not failed:
            return prev
        self.restart_engine()
        self._retry_results(prev, failed)
        return prev

    def open_institution_login_page(self, result: DownloadResult):
        """Open a foreground article tab for an end-of-batch SSO/login assist.

        DOI inputs deliberately restart from doi.org instead of reusing a possibly
        secret-bearing or expired SAML redirect URL. The page stays open during the
        retry so tab/session-scoped publisher state remains available.
        """
        if self._isolate_items:
            worker = self._ensure_item_worker()
            reply = worker.request(
                "open_login",
                timeout_s=float(self.cfg.per_request_timeout_s),
                result=result,
            )
            if reply.timed_out:
                raise BrowserUnavailable(
                    "opening the institutional-login page exceeded the paper timeout"
                )
            handle = WorkerPageHandle(token=int(reply.value))
            self._worker_login_pages.add(handle.token)
            return handle

        eng = self._ensure_engine()
        if eng is None:
            raise BrowserUnavailable(self._browser_error or "browser unavailable")
        ident = result.identifier
        if ident.kind == IdentifierKind.DOI:
            url = f"https://doi.org/{ident.value}"
        elif result.source_url and result.source_url.startswith(("http://", "https://")):
            url = result.source_url
        else:
            url = ident.value or ident.original
        page, _ = eng.open_login_page(url)
        try:
            page.bring_to_front()
        except Exception:
            pass
        return page

    def close_institution_login_page(self, page) -> None:
        """Close only the temporary login-assist tab, never the user's browser."""
        if isinstance(page, WorkerPageHandle):
            try:
                if self._item_worker is not None:
                    self._item_worker.request(
                        "close_login",
                        timeout_s=min(15.0, float(self.cfg.per_request_timeout_s)),
                        token=page.token,
                    )
            except WorkerFailure as exc:
                self.log(f"    could not close login-assist tab: {exc}")
            finally:
                self._worker_login_pages.discard(page.token)
                if not self.cfg.browser.keep_open and not self._worker_login_pages:
                    self._close_item_worker()
            return
        if self._engine is not None:
            self._engine.close_login_page(page)
            return
        try:
            page.close()
        except Exception:
            pass

    def retry_result(self, report: BatchReport,
                     previous: DownloadResult) -> DownloadResult:
        """Retry one result in place using the current authenticated browser.

        This is used immediately after the user completes institutional login, so
        unlike retry_failed it must not restart the browser first.
        """
        index = next((i for i, row in enumerate(report.results)
                      if row is previous), None)
        if index is None:
            raise ValueError("result is not part of the supplied batch report")
        self._retry_results(
            report,
            [previous],
            bypass_institution_login_gate=True,
        )
        retried = report.results[index]
        if retried.ok:
            self._clear_institution_login(previous.institution_login_platform)
            retried.institution_access_state = "authenticated"
            self.store.write_metadata(retried)
            self._write_report(report)
        return retried

    @property
    def institution_access_memory_path(self):
        return self._institution_access_memory.path

    def mark_institute_no_access(
        self,
        report: BatchReport,
        results: list[DownloadResult],
    ) -> bool:
        """Persist an explicit human decision that this institution lacks access."""
        platforms = {
            row.institution_login_platform
            for row in results
            if row.institution_login_platform
        }
        changed = False
        for platform in platforms:
            changed = bool(
                self._institution_access_memory.mark_no_access(platform)
            ) or changed
        if not changed:
            return False

        for row in results:
            platform = row.institution_login_platform
            if platform not in platforms:
                continue
            row.status = Status.UNABLE
            row.reason = UnableReason.INSTITUTE_NO_ACCESS
            row.institution_access_state = NO_ACCESS
            row.message = (
                f"Institute no access for {platform}; publisher attempts "
                "will be skipped in future runs whose --out folders share this "
                "parent directory. "
                "Open-access fallbacks will still be tried."
            )
            self.store.write_metadata(row)
        report.finished_at = _now()
        self._write_report(report)
        return True

    def resolve_institution_login_group(
        self,
        report: BatchReport,
        retried: list[DownloadResult],
    ) -> Optional[str]:
        """Persist the collective access decision for a login-gated platform group.

        Called after end-of-batch login assistance has retried every paper that
        shared one publisher platform. A successful retry confirms access and
        changes the remembered state to ``authenticated``. Any unsuccessful retry
        leaves the state as ``needs_login``: download, paywall, and repeated-login
        failures cannot prove that the institution lacks platform-wide access.

        ``no_access`` is persisted only by :meth:`mark_institute_no_access`, after
        the user explicitly chooses that outcome in the login-assistance prompt.

        Returns the resolved state (``"authenticated"`` or
        :data:`NEEDS_LOGIN`), or ``None`` when the group carries no safe platform.
        """
        platforms = {
            row.institution_login_platform
            for row in retried
            if row.institution_login_platform
        }
        if not platforms:
            return None
        if any(row.ok for row in retried):
            # A still-gated retry earlier in the same group can re-remember the
            # platform after a later success would otherwise clear it (they share
            # one platform label); clear again so confirmed access is never left
            # remembered.
            for platform in platforms:
                self._clear_institution_login(platform)
            return "authenticated"
        return NEEDS_LOGIN


    # -- internals -----------------------------------------------------------
    def _coerce(self, items) -> list[Identifier]:
        if isinstance(items, (str, Identifier)):
            items = [items]
        out: list[Identifier] = []
        for it in items:
            if isinstance(it, Identifier):
                out.append(it)
            else:
                out.extend(parse_many([str(it)]))
        return out


    @staticmethod
    def _platform_host(url: Optional[str]) -> Optional[str]:
        """Return a safe publisher hostname, excluding DOI and federated routers."""
        if not url:
            return None
        try:
            host = (urlparse(url).hostname or "").lower().strip(".")
        except Exception:
            return None
        if host.startswith("www."):
            host = host[4:]
        if (not host or host in {"doi.org", "dx.doi.org"}
                or "openathens" in host or "shibboleth" in host):
            return None
        return host

    def _institution_login_match_keys(self, ident: Identifier, plan=None) -> set[str]:
        """Stable keys available before downloading a later item in the batch."""
        keys: set[str] = set()
        if ident.kind == IdentifierKind.DOI:
            prefix = ident.value.split("/", 1)[0].lower()
            if prefix:
                keys.add(f"doi-prefix:{prefix}")
        elif ident.kind == IdentifierKind.URL:
            host = self._platform_host(ident.value)
            if host:
                keys.add(f"host:{host}")
        publisher = getattr(plan, "publisher", None)
        if publisher:
            keys.add(f"publisher:{str(publisher).lower()}")
        return keys

    @staticmethod
    def _is_open_access_candidate(cand: Candidate) -> bool:
        """Whether a metadata source positively identifies the candidate as OA."""
        label = (cand.label or "").lower()
        publisher = (cand.publisher or "").lower()
        return (
            cand.open_access
            or label.startswith(("pmc-", "unpaywall-", "s2-", "arxiv-"))
            or publisher in {"pmc", "arxiv"}
        )

    @staticmethod
    def _is_independent_access_candidate(cand: Candidate) -> bool:
        """Whether a fallback is independent of publisher subscription access."""
        return (
            cand.independent_access
            or PaperDownloadService._is_open_access_candidate(cand)
        )

    @staticmethod
    def _record_discovery(res: DownloadResult, cand: Candidate) -> None:
        """Persist the evidence attached to the candidate that actually worked."""
        res.discovery = DiscoveryProvenance(
            sources=list(cand.discovery_sources),
            matched_doi=cand.matched_doi,
            work_version=cand.work_version,
            license=cand.license,
            evidence=list(cand.match_evidence),
            strict_identity=cand.requires_strict_identity,
            strict_identity_verified=cand.requires_strict_identity,
            independent_access=cand.independent_access,
            provider_oa_asserted=cand.open_access,
            acquisition_succeeded=True,
        )

    @staticmethod
    def _publisher_candidate(plan, cand: Candidate) -> bool:
        """Whether this candidate exercises the version-of-record platform."""
        return bool(
            getattr(plan, "publisher", None)
            and cand.publisher == plan.publisher
            and not cand.independent_access
            and (
                cand.publisher_open_access
                or not PaperDownloadService._is_independent_access_candidate(cand)
            )
        )

    @staticmethod
    def _publisher_failure_diagnostic(
        er: Optional[EngineResult], *, unattended: bool, known_open_access: bool,
    ) -> tuple[str, str]:
        if er is None:
            return UnableReason.DOWNLOAD_FAILED.value, "publisher request failed"
        reason, message = classify_failure(Evidence(
            identity_mismatch_detail=(
                er.identity_mismatch_detail if er.identity_mismatch else None
            ),
            blocked=er.blocked,
            needs_manual=er.needs_manual,
            unattended=unattended,
            needs_login=er.needs_login,
            login_skipped=er.login_skipped,
            paywalled=er.paywalled,
            found_control=er.found_control,
            found_link=er.found_link,
            viewer_opened=er.viewer_opened,
            not_found=er.not_found,
            url_error_detail=(
                er.url_error_detail or er.detail if er.url_error else None
            ),
            access_denied=er.access_denied,
            known_open_access=known_open_access,
        ))
        return reason.value, er.detail or message

    @staticmethod
    def _validate_candidate_pdf(
        ident: Identifier,
        plan,
        cand: Candidate,
        data: bytes,
        source_url: str,
        result_title: Optional[str] = None,
    ):
        metadata = getattr(plan, "work_metadata", None)
        return validate_pdf_identity(
            data,
            expected_doi=(ident.value if ident.kind == IdentifierKind.DOI else None),
            expected_title=(getattr(plan, "title", None) or result_title),
            source_url=source_url,
            accepted_dois=(
                (cand.matched_doi,)
                if cand.matched_doi and cand.matched_doi != ident.value else ()
            ),
            expected_authors=(
                cand.verified_author_names
                if cand.requires_strict_identity and cand.verified_author_names
                else getattr(metadata, "author_names", ())
            ),
            required_author_matches=cand.required_author_matches,
            strict=cand.requires_strict_identity,
        )

    def _remember_institution_login(
        self,
        ident: Identifier,
        plan,
        observed_url: Optional[str],
    ) -> tuple[str, str]:
        """Remember a high-confidence gate beside the current output directory."""
        keys = self._institution_login_match_keys(ident, plan)
        host = self._platform_host(observed_url)
        if host:
            keys.add(f"host:{host}")
        publisher = getattr(plan, "publisher", None)
        if host:
            platform = host
        elif publisher:
            platform = str(publisher).lower()
        elif ident.kind == IdentifierKind.DOI:
            platform = f"doi-prefix:{ident.value.split('/', 1)[0].lower()}"
        else:
            platform = self._platform_host(ident.value) or "unknown publisher"
        try:
            record = self._institution_access_memory.remember(platform, keys)
        except ValueError:
            # An unusual identifier without a safe key can still be reported for
            # this item; it is deliberately not written to the durable file.
            return platform, NEEDS_LOGIN
        return record.platform, record.state

    def _remember_independent_login(
        self,
        cand: Candidate,
        observed_url: Optional[str],
    ) -> Optional[str]:
        """Remember an independent host gate without attaching publisher keys."""
        host = (
            self._platform_host(observed_url)
            or self._platform_host(cand.landing_url)
            or self._platform_host(cand.pdf_url)
        )
        if not host:
            return None
        try:
            self._institution_access_memory.remember(host, {f"host:{host}"})
        except ValueError:
            return None
        return host

    def _known_institution_login(
        self,
        ident: Identifier,
        plan,
    ) -> Optional[tuple[str, str]]:
        record = self._institution_access_memory.find_gate(
            self._institution_login_match_keys(ident, plan)
        )
        if record is None:
            return None
        return record.platform, record.state

    def _clear_institution_login(self, platform: Optional[str]) -> None:
        if not platform:
            return
        self._institution_access_memory.mark_authenticated(platform)

    def _ensure_item_worker(self) -> PersistentItemWorker:
        if self._item_worker is None:
            self._item_worker = PersistentItemWorker(self.cfg, logger=self.log)
        return self._item_worker

    def _close_item_worker(self, *, force: bool = False) -> None:
        worker = self._item_worker
        self._item_worker = None
        self._worker_login_pages.clear()
        if worker is None:
            return
        if force:
            worker.abort()
        else:
            worker.close()

    def _ensure_engine(self) -> Optional[BrowserEngine]:
        if not self.cfg.browser.enabled:
            self._browser_error = "browser disabled in config"
            return None
        if self._engine is not None:
            if self._engine.is_alive():
                return self._engine
            # The context died (e.g. the user closed the window in keep_open mode);
            # tear it down and start fresh below.
            self.log("    browser window was closed — restarting the engine")
            self._close_engine()
            self._browser_error = None
        if self._browser_error is not None:
            return None
        eng = None
        try:
            eng = BrowserEngine(self.cfg, logger=self.log, solver=self._solver,
                                skip_check=self._skip_requested)
            eng.__enter__()
            self._engine = eng
            self.log(f"browser engine started (backend={getattr(eng, 'backend', '?')}, "
                     f"headless={self.cfg.browser.headless})")
            return eng
        except BrowserUnavailable as e:
            self._browser_error = str(e)
            self.log(f"browser unavailable: {e}")
            return None
        except ItemDeadlineExceeded:
            # A watchdog can fire while Playwright/Patchright is starting, before
            # the engine has been assigned to self._engine. Tear down that local
            # partial instance so its driver/browser process is not leaked.
            if eng is not None:
                try:
                    eng.__exit__(None, None, None)
                except Exception:
                    pass
            raise

    def _close_engine(self) -> None:
        if self._engine is not None:
            try:
                self._engine.__exit__(None, None, None)
            except Exception:
                pass
            self._engine = None

    def _retry_results(
        self,
        report: BatchReport,
        previous_results: list[DownloadResult],
        *,
        bypass_institution_login_gate: bool = False,
    ) -> None:
        """Replace selected rows after retry while retaining the batch and history."""
        positions = {id(row): i for i, row in enumerate(report.results)}
        try:
            for retry_index, previous in enumerate(previous_results):
                if retry_index:
                    time.sleep(self.cfg.inter_request_delay_s)
                position = positions.get(id(previous))
                if position is None:
                    continue
                ident = self._coerce(previous.identifier.original)[0]
                if self._skip_controller is not None:
                    self._skip_controller.begin_item(ident.value or ident.original)
                try:
                    self.log(
                        f"[retry {retry_index + 1}/{len(previous_results)}] "
                        f"{ident.kind.value}: {ident.value or ident.original}"
                    )
                    retry_kwargs = {"previous": previous}
                    if bypass_institution_login_gate:
                        retry_kwargs["bypass_institution_login_gate"] = True
                    report.results[position] = self._download_one(ident, **retry_kwargs)
                finally:
                    if self._skip_controller is not None:
                        self._skip_controller.end_item()
        finally:
            if not self.cfg.browser.keep_open and not self._worker_login_pages:
                self._close_item_worker()
                self._close_engine()
        report.finished_at = _now()
        self._write_report(report)

    def _download_one(
        self,
        ident: Identifier,
        *,
        previous: Optional[DownloadResult] = None,
        bypass_institution_login_gate: bool = False,
    ) -> DownloadResult:
        if self._isolate_items:
            return self._download_one_isolated(
                ident,
                previous=previous,
                bypass_institution_login_gate=bypass_institution_login_gate,
            )
        return self._download_one_local(
            ident,
            previous=previous,
            bypass_institution_login_gate=bypass_institution_login_gate,
        )

    @staticmethod
    def _initial_result(
        ident: Identifier,
        previous: Optional[DownloadResult],
    ) -> DownloadResult:
        res = DownloadResult(identifier=ident, status=Status.UNABLE)
        if previous is not None:
            # Keep the complete acquisition audit trail across the manual-login
            # boundary. Stage timings include both runs, while the user's idle
            # login time remains visible only in the item wall-clock timestamps.
            res.started_at = previous.started_at
            res.attempts = list(previous.attempts)
            res.manual_challenge = previous.manual_challenge
            res.institution_login_platform = previous.institution_login_platform
            res.institution_access_state = previous.institution_access_state
        return res

    def _download_one_isolated(
        self,
        ident: Identifier,
        *,
        previous: Optional[DownloadResult] = None,
        bypass_institution_login_gate: bool = False,
    ) -> DownloadResult:
        """Run one complete acquisition behind a killable process boundary."""
        res = self._initial_result(ident, previous)
        if ident.kind == IdentifierKind.DOI:
            res.publisher = publisher_for_doi(ident.value)
            if res.publisher:
                res.publisher_path_status = "not_attempted"
        if self._skip_requested():
            return self._finalize_skipped(res)
        timeout_s = float(self.cfg.per_request_timeout_s)
        if timeout_s <= 0:
            raise ValueError("per_request_timeout_s must be greater than zero")
        started = time.monotonic()
        try:
            reply = self._ensure_item_worker().request(
                "download",
                timeout_s=timeout_s,
                skip_check=self._skip_requested,
                ident=ident,
                previous=previous,
                bypass_institution_login_gate=bypass_institution_login_gate,
            )
        except WorkerFailure as exc:
            self._close_item_worker(force=True)
            self.log(f"  acquisition worker failed; it will restart: {exc}")
            res.attempts.append(DownloadAttempt(
                method="worker-process",
                url=ident.value or ident.original,
                ok=False,
                detail="acquisition worker exited unexpectedly",
                elapsed_s=round(time.monotonic() - started, 2),
            ))
            res.reason = UnableReason.DOWNLOAD_FAILED
            res.message = (
                "The isolated acquisition worker exited unexpectedly. "
                "A fresh worker will be used for the next paper."
            )
            return self._finalize_unable(res)

        if reply.skipped:
            self.log("  skip requested; stopped the isolated browser worker")
            return self._finalize_skipped(res)
        if reply.timed_out:
            challenge_active, login_active, last_url = _worker_timeout_context(
                reply.recent_logs
            )
            if last_url:
                res.source_url = last_url
            if challenge_active:
                timeout_detail = (
                    "bot challenge remained active until the hard deadline"
                )
                res.reason, res.message = classify_failure(Evidence(
                    needs_manual=True,
                    unattended=self.cfg.autodev,
                ))
                res.manual_challenge = True
            elif login_active:
                timeout_detail = (
                    "institutional authentication remained incomplete until "
                    "the hard deadline"
                )
                res.reason, res.message = classify_failure(Evidence(
                    needs_login=True,
                ))
            else:
                timeout_detail = f"hard per-paper timeout after {timeout_s:g}s"
                if last_url:
                    timeout_detail += f"; last page: {last_url}"
                res.reason = UnableReason.TIMEOUT
                res.message = (
                    f"Hard per-paper time limit ({timeout_s:g}s) reached. "
                    "The unresponsive acquisition worker was stopped; the next "
                    "paper will use a fresh worker."
                )
            res.attempts.append(DownloadAttempt(
                method="worker-process",
                url=last_url or ident.value or ident.original,
                ok=False,
                detail=timeout_detail,
                elapsed_s=round(time.monotonic() - started, 2),
            ))
            self.log(
                f"  hard per-paper timeout ({timeout_s:g}s) reached; "
                "terminated the isolated browser worker"
            )
            if res.publisher:
                res.publisher_path_status = "failed"
                res.publisher_path_reason = res.reason.value
                res.publisher_path_detail = timeout_detail
            return self._finalize_unable(res)

        # The child may have learned or changed institutional-access memory.
        # Reload the parent's view before login assistance or the next decision.
        self._institution_access_memory.load_if_changed()
        return reply.value

    def _download_one_local(
        self,
        ident: Identifier,
        *,
        previous: Optional[DownloadResult] = None,
        bypass_institution_login_gate: bool = False,
    ) -> DownloadResult:
        res = self._initial_result(ident, previous)
        timeout_s = float(self.cfg.per_request_timeout_s)
        try:
            with paper_deadline(timeout_s):
                return self._download_one_with_deadline(
                    ident,
                    res,
                    bypass_institution_login_gate=bypass_institution_login_gate,
                )
        except ItemDeadlineExceeded as exc:
            self._zotero_wait_fn = None
            stage = exc.stage
            if stage is not None:
                res.attempts.append(DownloadAttempt(
                    method=stage.method,
                    url=stage.url,
                    ok=False,
                    detail=f"hard per-paper timeout after {timeout_s:g}s",
                    elapsed_s=round(max(0.0, time.monotonic() - stage.started_monotonic), 2),
                ))
            self.log(
                f"  hard per-paper timeout ({timeout_s:g}s) reached; stopping this paper"
            )
            res.reason = UnableReason.TIMEOUT
            res.message = (
                f"Hard per-paper time limit ({timeout_s:g}s) reached. "
                "Increase --paper-timeout or per_request_timeout_s if this paper "
                "needs more time."
            )
            return self._finalize_unable(res)

    def _download_one_with_deadline(
        self,
        ident: Identifier,
        res: DownloadResult,
        *,
        bypass_institution_login_gate: bool = False,
    ) -> DownloadResult:
        """Run one paper inside the absolute deadline installed by _download_one."""

        if self._skip_requested():
            return self._finalize_skipped(res)
        # Clear the engine's per-item bot-challenge flag so manual_challenge on the
        # result reflects only challenges hit while processing THIS identifier.
        if self._engine is not None:
            self._engine.reset_challenge_flag()

        if ident.kind == IdentifierKind.UNKNOWN:
            res.reason = UnableReason.UNPARSEABLE
            res.message = f"Could not recognize '{ident.original}' as a DOI, arXiv id, or URL."
            res.finished_at = _now()
            self.store.write_metadata(res)
            self.store.append_index(res)
            return res

        # Cache hit: we already keep a validated PDF or HTML full-text copy.
        cached_pdf = self.store.has_original(ident)
        cached_html = self.store.has_html(ident)
        if (cached_pdf or cached_html) and not self.cfg.overwrite:
            persisted = self.store.read_metadata(ident)
            if persisted is not None:
                # Preserve the acquisition audit, title and durable metadata
                # with the empty result constructed for this invocation.
                res = persisted
            res.status = Status.CACHED
            res.reason = None
            if cached_pdf:
                res.content_type = "pdf"
                res.original_path = str(self.store.original_path(ident))
                try:
                    res.bytes = self.store.original_path(ident).stat().st_size
                except OSError:
                    pass
            else:
                hp = self.store.fulltext_path(ident)
                res.content_type = "html_fulltext"
                res.original_path = str(hp)
                try:
                    res.bytes = hp.stat().st_size
                except OSError:
                    pass
            res.message = "Already in library. Use --overwrite to download again (Python API: config.overwrite = True)."
            res.finished_at = _now()
            self.store.write_metadata(res)
            self.store.append_index(res)
            return res

        plan = resolve(ident, self.cfg)
        if self._skip_requested():
            return self._finalize_skipped(res)
        remembered_login_platform: Optional[str] = None
        remembered_access_state: Optional[str] = None
        if plan.title:
            res.title = plan.title
        res.publisher = getattr(plan, "publisher", None)
        if res.publisher and res.publisher_path_status is None:
            res.publisher_path_status = "not_attempted"
        for n in plan.notes:
            self.log("  " + n)
        if not plan.candidates:
            res.reason = UnableReason.NOT_FOUND
            res.message = "No download strategy available. " + " ".join(plan.notes)
            return self._finalize_unable(res)

        known_open_access = any(
            cand.publisher_open_access for cand in plan.candidates
        )

        if not bypass_institution_login_gate:
            remembered = self._known_institution_login(ident, plan)
            if remembered:
                remembered_login_platform, remembered_access_state = remembered
        if remembered_login_platform:
            res.institution_login_platform = remembered_login_platform
            res.institution_access_state = remembered_access_state
            if ident.kind == IdentifierKind.DOI:
                res.source_url = f"https://doi.org/{ident.value}"
            elif ident.kind == IdentifierKind.URL:
                res.source_url = ident.value
            fallback_candidates = [
                cand for cand in plan.candidates
                if self._is_independent_access_candidate(cand)
            ]
            if not fallback_candidates:
                if remembered_access_state == NO_ACCESS:
                    self.log(
                        f"  [institution-login] Institute no access for "
                        f"{remembered_login_platform}; skipping repeated "
                        "publisher attempts"
                    )
                    res.reason = UnableReason.INSTITUTE_NO_ACCESS
                    res.message = (
                        f"Institute no access for {remembered_login_platform}; "
                        "skipped publisher attempts using the saved "
                        "institution-access memory."
                    )
                else:
                    self.log(
                        f"  [institution-login] {remembered_login_platform} is "
                        "already queued; skipping repeated publisher attempts"
                    )
                    res.reason = UnableReason.NEEDS_LOGIN
                    res.message = (
                        f"Institutional login is already required for "
                        f"{remembered_login_platform}; skipped repeated attempts "
                        "until end-of-batch login assistance."
                    )
                return self._finalize_unable(res)
            if remembered_access_state == NO_ACCESS:
                self.log(
                    f"  [institution-login] Institute no access for "
                    f"{remembered_login_platform}; skipping publisher and "
                    f"trying {len(fallback_candidates)} independent full-text fallback(s)"
                )
            else:
                self.log(
                    f"  [institution-login] {remembered_login_platform} is already "
                    f"queued; skipping publisher and trying "
                    f"{len(fallback_candidates)} independent full-text fallback(s)"
                )
            plan.candidates = fallback_candidates
            if known_open_access:
                # The saved state describes subscription content on this
                # platform, not this publisher-hosted OA paper. Do not stamp the
                # per-paper result as no-access/needs-login even though the state
                # was useful for suppressing redundant subscription attempts.
                res.institution_login_platform = None
                res.institution_access_state = None

        # Reset per-item domain failure tracking (transient errors shouldn't
        # persist across items in the batch).
        if self.cfg.autodev:
            self._failed_domains.clear()

        # Try candidates in order.
        pdf_bytes: Optional[bytes] = None
        html_fallback_bytes: Optional[bytes] = None
        html_fallback_candidate: Optional[Candidate] = None
        html_fallback_source_url: Optional[str] = None
        saw_blocked = saw_paywall = saw_found_control = False
        saw_found_link = saw_viewer_opened = False
        saw_action_reason: Optional[str] = None
        saw_not_found = saw_access_denied = False
        saw_url_error_detail: Optional[str] = None
        saw_identity_mismatch_detail: Optional[str] = None
        saw_needs_manual = False
        saw_needs_login = saw_login_skipped = False
        skip_non_oa_after_publisher_terminal = False
        zotero_triggered = False
        self._zotero_wait_fn = None
        if self.cfg.zotero.enabled and ident.kind == IdentifierKind.DOI:
            self._zotero_wait_fn = self._make_zotero_wait_fn(ident.value, res)

        for idx, cand in enumerate(plan.candidates):
            if self._skip_requested():
                return self._finalize_skipped(res)
            check_item_deadline()
            if (skip_non_oa_after_publisher_terminal
                    and not self._is_independent_access_candidate(cand)):
                self.log(
                    "  publisher terminal state already confirmed; skipping "
                    f"non-OA {cand.method} candidate"
                )
                continue
            # --autodev: skip browser candidates for domains that repeatedly fail
            if (self.cfg.autodev and cand.method == "browser" and cand.landing_url):
                domain = urlparse(cand.landing_url).netloc
                if self._failed_domains.get(domain, 0) >= 2:
                    self.log(f"  [autodev] skipping {domain} (failed {self._failed_domains[domain]}x)")
                    res.attempts.append(DownloadAttempt(
                        method=cand.method, url=cand.landing_url,
                        ok=False, detail=f"[autodev] domain {domain} skipped (repeated failures)",
                        elapsed_s=0.0))
                    continue
            t0 = time.time()
            try:
                with acquisition_stage(
                    cand.method, cand.pdf_url or cand.landing_url or ""
                ):
                    got, er = self._attempt_candidate(cand, res)
            except Exception as e:  # noqa: BLE001
                res.attempts.append(DownloadAttempt(
                    method=cand.method, url=cand.pdf_url or cand.landing_url or "",
                    ok=False, detail=f"exception: {type(e).__name__}: {e}",
                    elapsed_s=round(time.time() - t0, 2)))
                continue

            elapsed = round(time.time() - t0, 2)
            if self._skip_requested():
                return self._finalize_skipped(res)
            # Strong institutional-login evidence is non-interactive: skip the
            # current paper immediately and preserve the precise reason.
            if (er is not None and er.needs_login
                    and not (self.cfg.autodev and er.needs_manual)):
                if self._is_independent_access_candidate(cand):
                    host = self._remember_independent_login(
                        cand,
                        er.final_url,
                    )
                    er.login_skipped = False
                    er.detail = (
                        "independent full-text candidate requires login"
                        + (f" at {host}" if host else "")
                        + "; continuing with other candidates"
                    )
                else:
                    (
                        res.institution_login_platform,
                        res.institution_access_state,
                    ) = self._remember_institution_login(
                        ident,
                        plan,
                        er.final_url,
                    )
                    er.login_skipped = True
                    er.detail = (
                        "institutional login required; paper skipped automatically"
                    )
            # Track domain failures for --autodev fast-skip
            if (self.cfg.autodev and not got and er is not None
                    and cand.method == "browser" and cand.landing_url):
                if (er.blocked or (er.detail and any(kw in (er.detail or '').lower()
                        for kw in ('nav failed', 'net::', 'connection', 'err_', 'timed out', 'timeout')))):
                    domain = urlparse(cand.landing_url).netloc
                    self._failed_domains[domain] = self._failed_domains.get(domain, 0) + 1
            if er is not None:
                saw_blocked = saw_blocked or er.blocked
                saw_paywall = saw_paywall or er.paywalled
                saw_found_control = saw_found_control or er.found_control
                saw_found_link = saw_found_link or er.found_link
                saw_viewer_opened = saw_viewer_opened or er.viewer_opened
                if er.failure_reason:
                    saw_action_reason = er.failure_reason
                saw_not_found = saw_not_found or er.not_found
                if er.url_error and saw_url_error_detail is None:
                    saw_url_error_detail = (
                        er.url_error_detail or er.detail
                        or "URL error: browser could not open the paper page."
                    )
                saw_access_denied = saw_access_denied or er.access_denied
                if er.identity_mismatch and saw_identity_mismatch_detail is None:
                    saw_identity_mismatch_detail = (
                        er.identity_mismatch_detail or er.detail
                    )
                saw_needs_manual = saw_needs_manual or er.needs_manual
                saw_needs_login = saw_needs_login or er.needs_login
                saw_login_skipped = saw_login_skipped or er.login_skipped
                if er.title and not res.title:
                    res.title = er.title
                if er.final_url and not res.source_url:
                    res.source_url = er.final_url
                # remember a usable HTML page for the full-text fallback
                if er.landing_html and html_fallback_bytes is None:
                    # Strict title-discovered candidates must never bypass PDF
                    # identity checks via the generic HTML finalizer.
                    if (not saw_identity_mismatch_detail
                            and not cand.requires_strict_identity
                            and self._html_is_fulltext(
                                er.landing_html, er.paywalled
                            )):
                        html_fallback_bytes = er.landing_html.encode("utf-8", "ignore")
                        html_fallback_candidate = cand
                        html_fallback_source_url = (
                            er.final_url or cand.landing_url or cand.pdf_url
                        )

            if got:
                pdf_source = (
                    er.pdf_url if er and er.pdf_url
                    else cand.pdf_url or cand.landing_url or ""
                )
                verdict = self._validate_candidate_pdf(
                    ident, plan, cand, got, pdf_source, res.title
                )
                if not verdict.accepted:
                    self.log(f"    rejected wrong PDF: {verdict.detail}")
                    got = None
                    if er is None:
                        er = EngineResult(ok=False, found_link=True, pdf_url=pdf_source)
                    saw_found_link = True
                    er.ok = False
                    er.data = None
                    er.detail = f"rejected PDF identity: {verdict.detail}"

            if self._publisher_candidate(plan, cand):
                if got:
                    res.publisher_path_status = "success"
                    res.publisher_path_reason = None
                    res.publisher_path_detail = (
                        er.detail if er is not None else "publisher PDF downloaded"
                    )
                else:
                    reason_value, publisher_detail = self._publisher_failure_diagnostic(
                        er,
                        unattended=self.cfg.autodev,
                        known_open_access=known_open_access or cand.open_access,
                    )
                    res.publisher_path_status = "failed"
                    res.publisher_path_reason = reason_value
                    res.publisher_path_detail = publisher_detail

            res.attempts.append(DownloadAttempt(
                method=cand.method,
                url=(er.pdf_url if er and er.pdf_url else (cand.pdf_url or cand.landing_url or "")),
                ok=bool(got), detail=(er.detail if er else "")[:300], elapsed_s=elapsed))

            if got:
                pdf_bytes = got
                res.pdf_url = res.attempts[-1].url
                res.acquisition_source = (
                    er.acquisition_source if er is not None else "direct_request"
                )
                res.source_url = (
                    (er.final_url if er is not None else None)
                    or cand.landing_url
                    or res.pdf_url
                )
                self._record_discovery(res, cand)
                break

            # Pensoft's generated PDF endpoint can be extremely slow while its
            # complete OA article is already present in the landing HTML. In
            # unattended mode, finish with that full text rather than entering
            # another equivalent PDF buffering path that cannot be interrupted.
            if (self.cfg.autodev and cand.publisher == "pensoft"
                    and html_fallback_bytes is not None):
                self.log(
                    "  [autodev] Pensoft PDF stream exceeded the bounded fast path; "
                    "keeping the complete open-access HTML instead"
                )
                if html_fallback_candidate is not None:
                    res.source_url = html_fallback_source_url
                    self._record_discovery(res, html_fallback_candidate)
                return self._finalize_html(ident, res, html_fallback_bytes)

            if er is not None and er.login_skipped:
                remaining_independent = any(
                    self._is_independent_access_candidate(c)
                    for c in plan.candidates[idx + 1:]
                )
                if remaining_independent:
                    skip_non_oa_after_publisher_terminal = True
                    self.log(
                        "  institutional login required — skipping publisher "
                        "work and continuing with independent full-text fallbacks"
                    )
                    continue
                self.log("  institutional login required — no independent fallback remains")
                break

            if self.cfg.autodev and er is not None and er.needs_manual:
                remaining_independent = any(
                    self._is_independent_access_candidate(c)
                    for c in plan.candidates[idx + 1:]
                )
                if remaining_independent:
                    skip_non_oa_after_publisher_terminal = True
                    self.log(
                        "  unresolved publisher captcha in --autodev — "
                        "continuing with independent full-text fallbacks"
                    )
                    continue
                self.log(
                    "  unresolved captcha in --autodev — skipping remaining "
                    "candidates for this paper"
                )
                break


            # If the engine triggered Zotero Connector on the live page, stop
            # trying other candidates and proceed directly to poll Zotero.
            if er is not None and er.zotero_triggered:
                if cand.requires_strict_identity:
                    self.log(
                        "  ignoring generic Zotero fallback for strict-identity "
                        "candidate; continuing with independently validated candidates"
                    )
                    continue
                zotero_triggered = True
                self.log("  Zotero Connector was triggered on the live page; "
                         "proceeding to poll Zotero for the saved item...")
                break

            # Fast-failure: skip remaining candidates when the paper clearly
            # doesn't exist or the domain denied access (genuine paywall).
            if (not got and er is not None and cand.method == "browser"
                    and not self._is_independent_access_candidate(cand)):
                if er.url_error:
                    remaining = plan.candidates[idx + 1:]
                    has_independent_fallback = any(
                        self._is_independent_access_candidate(c) for c in remaining)
                    if not has_independent_fallback:
                        self.log("  URL error (no independent fallback candidates) — stopping")
                        break
                    skip_non_oa_after_publisher_terminal = True
                    self.log(
                        "  URL error on publisher page — skipping repeated browser "
                        "work and trying remaining independent full-text fallbacks"
                    )
                if er.not_found:
                    remaining = plan.candidates[idx + 1:]
                    has_independent_fallback = any(
                        self._is_independent_access_candidate(c) for c in remaining)
                    if not has_independent_fallback:
                        self.log("  paper not found (no fallback candidates) — stopping")
                        break
                    skip_non_oa_after_publisher_terminal = True
                    self.log("  paper not found on publisher — trying remaining independent fallbacks")
                if er.access_denied and not er.found_link:
                    # Only break if no remaining HTTP/OA candidates could provide
                    # a free copy (PMC, Unpaywall, arXiv etc.).
                    remaining = plan.candidates[idx + 1:]
                    has_independent_fallback = any(
                        self._is_independent_access_candidate(c) for c in remaining)
                    if not has_independent_fallback:
                        self.log("  access denied (no fallback candidates) — stopping")
                        break
                    skip_non_oa_after_publisher_terminal = True
                    self.log("  access denied on publisher — trying remaining independent fallbacks")

        # Fast OA/direct candidates have already run before the browser reaches
        # an interactive challenge. In unattended mode, an unresolved captcha is
        # terminal for this item; move to the next paper.
        if self.cfg.autodev and saw_needs_manual and pdf_bytes is None:
            res.reason, res.message = classify_failure(Evidence(
                needs_manual=True,
                unattended=True,
            ))
            return self._finalize_unable(res)


        if pdf_bytes is not None:
            return self._finalize_pdf(ident, res, pdf_bytes)

        if self._skip_requested():
            return self._finalize_skipped(res)

        # --- Zotero Connector fallback ----------------------------------------
        # The engine already triggered the Zotero Connector save on the live
        # page (inside attempt()). Now we just need to poll the Zotero API to
        # wait for the item & PDF to appear.
        if zotero_triggered and ident.kind == IdentifierKind.DOI:
            check_item_deadline()
            zotero_t0 = time.time()
            with acquisition_stage(
                "zotero_connector", res.source_url or ident.value
            ):
                zotero_bytes = self._try_zotero_connector(ident, res)
            if zotero_bytes is not None:
                pdf_bytes = zotero_bytes
                res.attempts.append(DownloadAttempt(
                    method="zotero_connector",
                    url=res.source_url or ident.value,
                    ok=True, detail="ok via Zotero Connector",
                    elapsed_s=round(time.time() - zotero_t0, 2)))
                return self._finalize_pdf(ident, res, pdf_bytes)

        if self._skip_requested():
            return self._finalize_skipped(res)

        # No PDF — maybe we can keep the HTML full text instead.
        if html_fallback_bytes is not None and not saw_identity_mismatch_detail:
            if html_fallback_candidate is not None:
                res.source_url = html_fallback_source_url
                self._record_discovery(res, html_fallback_candidate)
            return self._finalize_html(ident, res, html_fallback_bytes)

        if remembered_login_platform and not known_open_access:
            if remembered_access_state == NO_ACCESS:
                res.reason = UnableReason.INSTITUTE_NO_ACCESS
                res.message = (
                    f"Institute no access for {remembered_login_platform}; "
                    "publisher attempts were skipped and the available "
                    "independent full-text fallbacks did not succeed."
                )
            else:
                res.reason = UnableReason.NEEDS_LOGIN
                res.message = (
                    f"Institutional login is already required for "
                    f"{remembered_login_platform}; repeated publisher "
                    "attempts were skipped and the available independent full-text fallbacks "
                    "did not succeed."
                )
            return self._finalize_unable(res)

        # Classify the failure honestly (least-ambiguous signal wins). The pure
        # classifier lives in paper_dl.classify so it is unit-tested directly.
        ev = Evidence(
            identity_mismatch_detail=saw_identity_mismatch_detail,
            blocked=saw_blocked,
            needs_manual=saw_needs_manual,
            unattended=self.cfg.autodev,
            needs_login=saw_needs_login and not known_open_access,
            login_skipped=saw_login_skipped,
            paywalled=saw_paywall,
            found_control=saw_found_control,
            found_link=saw_found_link,
            viewer_opened=saw_viewer_opened,
            not_found=saw_not_found,
            url_error_detail=saw_url_error_detail,
            access_denied=saw_access_denied,
            known_open_access=known_open_access,
            timed_out=False,
            only_http=all(a.method == "http" for a in res.attempts),
            browser_error=self._browser_error,
            timeout_s=self.cfg.per_request_timeout_s,
        )
        res.reason, res.message = classify_failure(ev)
        res.action_reason = saw_action_reason or res.reason.value
        return self._finalize_unable(res)

    def _attempt_candidate(self, cand: Candidate, res: DownloadResult):
        """Return (pdf_bytes_or_None, EngineResult_or_None)."""
        # HTTP fast-path
        if cand.method == "http" and cand.pdf_url and self.cfg.http_first:
            fr = http_fallback.fetch(cand.pdf_url, self.cfg, referer=cand.referer)
            if fr.ok and is_pdf_bytes(fr.data):
                return fr.data, None
            return None, _engine_result_from_http(fr)

        # Browser path
        eng = self._ensure_engine()
        if eng is None:
            # Browser not available: if the candidate has a direct PDF URL, still
            # try a plain HTTP GET as a last resort.
            if cand.pdf_url:
                fr = http_fallback.fetch(cand.pdf_url, self.cfg, referer=cand.referer)
                if fr.ok and is_pdf_bytes(fr.data):
                    return fr.data, None
                return None, _engine_result_from_http(fr, prefix="no browser; http: ")
            return None, EngineResult(ok=False, detail=f"browser unavailable: {self._browser_error}")


        eng.zotero_wait_fn = self._zotero_wait_fn
        er = eng.attempt(cand)
        return (er.data if er.ok else None), er

    def _skip_requested(self) -> bool:
        try:
            return bool(self._skip_controller and self._skip_controller.is_requested())
        except Exception:
            return False


    def _make_zotero_wait_fn(self, doi: str, res: DownloadResult):
        """Build a callback that polls Zotero for the item + PDF.

        Invoked by the engine right after the Connector is triggered, while the
        article tab is still open, so Zotero can use the live browser session to
        download the full-text PDF. Returns True once the PDF is on disk.
        """
        zc = self._ensure_zotero()
        baseline_version = 0
        if zc is not None and zc.ensure_running():
            try:
                baseline_version = zc.get_library_version()
            except (AttributeError, TypeError):
                baseline_version = 0

        def _wait() -> bool:
            if zc is None or not zc.ensure_running():
                return False
            self.log("    [zotero] polling Zotero for item + PDF (page kept alive)...")
            item = zc.wait_for_item(
                doi,
                baseline_version=baseline_version,
                cancel_fn=self._skip_requested,
            )
            if item is None:
                return False
            item_key = item.get("key", "")
            if item_key:
                res.zotero.item_key = item_key
                res.zotero.collection_key = self.cfg.zotero.collection_key
                self._file_into_collection(zc, item_key)
            pdf_path = zc.wait_for_pdf(item_key, cancel_fn=self._skip_requested)
            return pdf_path is not None
        return _wait


    def _ensure_zotero(self) -> Optional[ZoteroConnector]:
        """Lazily initialize the ZoteroConnector client."""
        if self._zotero is not None:
            return self._zotero
        self._zotero = ZoteroConnector(self.cfg.zotero, logger=self.log)
        return self._zotero


    def _file_into_collection(self, zc: ZoteroConnector, item_key: str) -> None:
        """Move a Connector-saved item into the configured target collection.

        The Zotero Connector ignores our configured collection and drops new
        items into the UI's last-used collection, so once the item appears we
        re-file it into ``zotero.collection_key`` ourselves. No-op when no
        collection is configured or the key does not exist.
        """
        coll = self.cfg.zotero.collection_key
        if not coll or not item_key:
            return
        if not zc.validate_collection_key(coll):
            self.log(f"    [zotero] configured collection_key={coll!r} not found "
                     "in Zotero; leaving item where the Connector placed it")
            return
        zc.add_item_to_collection(item_key, coll)


    def _try_zotero_connector(self, ident: Identifier, res: DownloadResult) -> Optional[bytes]:
        """Poll Zotero for the PDF after the Connector was triggered.

        Called AFTER the engine already triggered the Zotero Connector shortcut
        on the live article page (inside attempt()). This method just polls
        Zotero's local API until the new item appears and its PDF attachment
        is downloaded to local storage. Returns the PDF bytes or None.
        """
        zc = self._ensure_zotero()
        if not zc.ensure_running():
            res.zotero.error = "Zotero is not running or unreachable"
            return None

        doi = ident.value
        self.log(f"    [zotero] polling Zotero for DOI={doi}...")

        # The live-page wait callback records the exact newly-created/updated item.
        if res.zotero.item_key:
            item_key = res.zotero.item_key
            pdf_path = zc.wait_for_pdf(item_key, cancel_fn=self._skip_requested)
            if pdf_path:
                return self._read_zotero_pdf(pdf_path, res, item_key)
            res.zotero.error = (
                "Newly saved Zotero item has no PDF attachment"
            )
            return None

        # Check if this DOI already exists in Zotero (e.g. saved just now or earlier).
        existing = zc.find_item_by_doi(doi)
        if existing is not None:
            self.log("    [zotero] item already exists in Zotero, checking for PDF...")
            item_key = existing.get("key", "")
            res.zotero.item_key = item_key
            self._file_into_collection(zc, item_key)
            pdf_path = zc.wait_for_pdf(item_key, cancel_fn=self._skip_requested)
            if pdf_path:
                return self._read_zotero_pdf(pdf_path, res, item_key)
            res.zotero.error = "Zotero item exists but no PDF attachment was found"
            return None

        # Poll for the new item to appear (the Connector save is in progress).
        item = zc.wait_for_item(doi, cancel_fn=self._skip_requested)
        if item is None:
            res.zotero.error = "Zotero did not save the item within the timeout"
            return None

        item_key = item.get("key", "")
        res.zotero.item_key = item_key
        res.zotero.collection_key = self.cfg.zotero.collection_key
        self._file_into_collection(zc, item_key)

        # Wait for the PDF attachment to be downloaded.
        pdf_path = zc.wait_for_pdf(item_key, cancel_fn=self._skip_requested)
        if pdf_path is None:
            res.zotero.error = "Zotero saved the item but no PDF attachment was found"
            return None

        return self._read_zotero_pdf(pdf_path, res, item_key)


    def _read_zotero_pdf(self, pdf_path, res: DownloadResult, item_key: str) -> Optional[bytes]:
        """Read and validate a PDF from Zotero's storage."""
        try:
            pdf_bytes = pdf_path.read_bytes()
        except OSError as e:
            res.zotero.error = f"Could not read PDF from Zotero storage: {e}"
            return None

        if not is_pdf_bytes(pdf_bytes):
            res.zotero.error = "File in Zotero storage is not a valid PDF"
            return None

        res.zotero.saved = True
        res.zotero.item_key = item_key
        res.zotero.linked_file = str(pdf_path)
        self.log(f"    [zotero] successfully retrieved PDF ({len(pdf_bytes)} bytes) from Zotero storage")
        return pdf_bytes


    # -- finalizers ----------------------------------------------------------
    def _finalize_pdf(self, ident: Identifier, res: DownloadResult, pdf_bytes: bytes) -> DownloadResult:
        res.bytes = len(pdf_bytes)
        res.content_type = "pdf"
        n_pages = pdf_page_count(pdf_bytes)
        if not is_pdf_bytes(pdf_bytes) or n_pages == 0:
            # last-ditch: still keep what we got, but flag it
            res.status = Status.UNABLE
            res.reason = UnableReason.INVALID_PDF
            res.message = "Downloaded data is not a valid/parseable PDF."
            op = self.store.save_pdf(ident, pdf_bytes)
            res.original_path = str(op)
            return self._finalize_unable(res)

        if (res.discovery.strict_identity
                and not res.discovery.strict_identity_verified):
            res.status = Status.UNABLE
            res.reason = UnableReason.INVALID_PDF
            res.message = (
                "Rejected a strict-identity candidate that did not pass the "
                "candidate-specific identity check."
            )
            return self._finalize_unable(res)

        identity = validate_pdf_identity(
            pdf_bytes,
            expected_doi=(ident.value if ident.kind == IdentifierKind.DOI else None),
            expected_title=res.title,
            source_url=res.pdf_url,
            accepted_dois=(
                (res.discovery.matched_doi,)
                if res.discovery.matched_doi
                and res.discovery.matched_doi != ident.value else ()
            ),
        )
        if not identity.accepted:
            res.status = Status.UNABLE
            res.reason = UnableReason.INVALID_PDF
            res.message = f"Rejected a non-primary PDF: {identity.detail}."
            return self._finalize_unable(res)

        op = self.store.save_pdf(ident, pdf_bytes)
        res.original_path = str(op)
        res.status = Status.SUCCESS
        self._record_manual_challenge(res)
        res.message = f"Downloaded ({n_pages} pages)."
        res.finished_at = _now()
        self.store.write_metadata(res)
        self.store.append_index(res)
        return res

    def _finalize_html(self, ident: Identifier, res: DownloadResult, html: bytes) -> DownloadResult:
        p = self.store.save_html(ident, html)
        res.status = Status.SUCCESS
        res.content_type = "html_fulltext"
        self._record_manual_challenge(res)
        res.original_path = str(p)
        res.bytes = len(html)
        res.message = "No PDF available; saved HTML full text instead."
        res.finished_at = _now()
        self.store.write_metadata(res)
        self.store.append_index(res)
        return res

    def _finalize_skipped(self, res: DownloadResult) -> DownloadResult:
        res.reason = UnableReason.SKIPPED
        res.message = "Skipped by user while this paper was running."
        self.log("  paper skipped by user")
        return self._finalize_unable(res)

    def _finalize_unable(self, res: DownloadResult) -> DownloadResult:
        res.status = Status.UNABLE
        self._record_manual_challenge(res)
        res.finished_at = _now()
        self.store.write_metadata(res)
        self.store.append_index(res)
        return res

    def _record_manual_challenge(self, res: DownloadResult) -> None:
        """Stamp the result if a bot challenge/captcha was encountered for this item
        (so report.json / summary.md can show which items needed a manual solve)."""
        if self._engine is not None and self._engine.challenge_seen:
            res.manual_challenge = True

    # -- helpers -------------------------------------------------------------
    @staticmethod
    def _html_is_fulltext(html: str, paywalled: bool) -> bool:
        if paywalled or not html or len(html) < 40_000:
            return False
        try:
            soup = BeautifulSoup(html, "lxml")
            for hidden in soup(["script", "style", "noscript", "template"]):
                hidden.decompose()
            visible_text = " ".join(soup.get_text(" ", strip=True).split())
        except Exception:
            return False
        # Large application shells can contain article-related words in their
        # JavaScript while the actual full text is still waiting in an unloaded
        # iframe.  Only preserve HTML that already contains substantial visible
        # prose; otherwise later independent candidates must remain eligible.
        if len(visible_text) < 5_000:
            return False
        # Keep the established marker heuristic unchanged after the new visible-
        # prose gate so existing non-English/class-based full-text pages retain
        # their historical behavior.
        low = html.lower()
        markers = ("references", "introduction", "<article", "fulltext", "body-content")
        return sum(m in low for m in markers) >= 2

    def _write_report(self, report: BatchReport) -> None:
        out = self.cfg.output_path
        out.mkdir(parents=True, exist_ok=True)
        _atomic_write_text(out / "report.json", report.to_json())
        # A compact human-readable companion to the structured report.
        try:
            from .report import summary_markdown
            _atomic_write_text(out / "summary.md", summary_markdown(report))
        except Exception as e:  # noqa: BLE001 - the summary is best-effort
            self.log(f"    could not write summary.md: {type(e).__name__}: {e}")
