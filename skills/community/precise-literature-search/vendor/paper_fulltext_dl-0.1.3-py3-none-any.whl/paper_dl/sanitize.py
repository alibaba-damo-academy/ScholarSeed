"""Redact signed URLs in download diagnostics and persisted metadata."""

from __future__ import annotations

import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

# Query-parameter names whose values are secrets (mask them in shared output).
_SENSITIVE_PARAMS = {
    "token", "access_token", "auth", "authorization", "sig", "signature",
    "key", "apikey", "api_key", "jwt", "sid", "session", "sessionid", "ticket",
    "hmac", "expires", "expiry", "se", "sv", "sp", "srt", "wskey", "code",
    "secret", "password", "pwd", "id_token", "refresh_token",
    # Federated identity / OAuth correlation and assertion payloads.
    "samlrequest", "samlresponse", "samlart", "relaystate", "state",
    "wresult", "wctx", "oauth_token",
}
# Substrings that, if present in a query-param NAME, mark its value secret.
_SENSITIVE_NAME_SUBSTR = (
    "token", "auth", "sig", "sess", "secret", "cred", "ticket", "hmac",
    "nonce", "otp", "passw", "jwt", "key", "hash", "bearer", "saml",
    "relaystate", "wresult", "wctx",
)
# Structural params kept legible even if the value looks tokenish (so the flow
# stays readable — these identify the article, not the session).
_SAFE_PARAMS = {
    "doi", "arnumber", "accepttc", "id", "page", "pii", "isbn", "issn",
    "volume", "issue", "spage", "epage", "tp", "punumber", "anumber",
}
# Request/response headers that must never appear in shared output.
_SECRET_HEADERS = {"cookie", "set-cookie", "authorization", "proxy-authorization"}

_REDACT = "REDACTED"


def _looks_secret(s: str) -> bool:
    """Heuristic: does this string look like an opaque high-entropy token/signature
    (as opposed to a readable slug, a DOI, or a short numeric id)? Used to mask
    secrets that live in a URL *path* segment or an unlabelled query value."""
    s = (s or "").strip()
    if len(s) < 12:
        return False
    # JWT: header.payload.signature (base64url segments separated by dots)
    if re.fullmatch(r"[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{6,}", s):
        return True
    # long hex run (session ids, signatures)
    if re.fullmatch(r"[0-9a-fA-F]{16,}", s):
        return True
    # one opaque alphanumeric run (no hyphen/space word separators -> not a slug)
    if re.fullmatch(r"[A-Za-z0-9_=]+", s) and len(s) >= 16:
        if any(c.isalpha() for c in s) and any(c.isdigit() for c in s):
            return True
    # base64-ish blob
    if re.fullmatch(r"[A-Za-z0-9+/]{24,}={0,2}", s) and any(c.isdigit() for c in s):
        return True
    return False


def _strip_userinfo(netloc: str) -> str:
    """Drop any ``user:pass@`` credentials from an authority component."""
    return netloc.rsplit("@", 1)[-1] if "@" in (netloc or "") else (netloc or "")


def _is_tokenish_value(v: str) -> bool:
    """Mixed-case alphanumeric of length >= 8 is almost always a token/id hash,
    rarely a meaningful human-set query value (catches e.g. ``Xy7Qz9KpLm``)."""
    return (len(v) >= 8 and any(c.isupper() for c in v)
            and any(c.islower() for c in v) and any(c.isdigit() for c in v))


def _mask_param(name: str, value: str) -> str:
    """Mask a query value when it's a secret, keeping structural params legible."""
    n = (name or "").lower()
    if n in _SAFE_PARAMS:
        return value
    if (n in _SENSITIVE_PARAMS or any(sub in n for sub in _SENSITIVE_NAME_SUBSTR)
            or len(value) > 40 or _looks_secret(value) or _is_tokenish_value(value)):
        return _REDACT
    return value


def _mask_url(url: str) -> str:
    """Produce a shareable URL: strip ``user:pass@`` credentials, mask token-like
    query values AND token-like path segments, but keep structurally meaningful
    bits (``acceptTC=true``, ``arnumber=12345``, ``doi=...``, ``/article.pdf``) so
    the flow stays legible. Runs even when there is no query string (path-only
    tokens still get masked)."""
    try:
        parts = urlsplit(url)
    except Exception:
        return url
    netloc = _strip_userinfo(parts.netloc)
    # path: mask any segment that looks like an opaque token (signed-CDN paths,
    # /secure/<token>/, a JWT path component) while leaving readable slugs alone.
    segs = [(_REDACT if _looks_secret(s) else s) for s in parts.path.split("/")]
    path = "/".join(segs)
    query = ""
    if parts.query:
        out = [(k, _mask_param(k, v)) for k, v in parse_qsl(parts.query, keep_blank_values=True)]
        query = urlencode(out)
    return urlunsplit((parts.scheme, netloc, path, query, ""))


def sanitize_url(url: str) -> str:
    """Public URL sanitizer for persisted reports and metadata."""
    return _mask_url(url)


_URL_IN_TEXT_RE = re.compile(r"https?://[^\s<>\"']+")


def sanitize_text(text: str) -> str:
    """Mask secret-bearing URLs embedded in a diagnostic string."""
    return _URL_IN_TEXT_RE.sub(lambda m: sanitize_url(m.group(0)), text or "")
