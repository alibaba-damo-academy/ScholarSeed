"""Deterministic maintenance commands for the core downloader."""
from __future__ import annotations

import json
from pathlib import Path
import typer

from .translators.audit import compare_adapter_directories, render_markdown

app = typer.Typer(add_completion=False, help="Core downloader maintenance tools.")


@app.callback()
def main() -> None:
    """Audit proposed maintenance changes without applying them."""


@app.command("translator-diff")
def translator_diff(
    current: Path = typer.Argument(..., exists=True, file_okay=False, readable=True),
    proposed: Path = typer.Argument(..., exists=True, file_okay=False, readable=True),
    output_format: str = typer.Option("markdown", "--format", help="markdown | json"),
    check: bool = typer.Option(False, "--check", help="Exit 1 when human approval is required"),
):
    """Audit two generated Zotero translator adapter directories."""
    report = compare_adapter_directories(current, proposed)
    if output_format == "json":
        typer.echo(json.dumps(report, ensure_ascii=False, indent=2))
    elif output_format == "markdown":
        typer.echo(render_markdown(report), nl=False)
    else:
        raise typer.BadParameter("--format must be 'markdown' or 'json'")
    if check and report["approvalRequired"]:
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
