# Third-party components

## PDF inspection

PDF page counting, text extraction, and thumbnail validation use
[pypdfium2](https://github.com/pypdfium2-team/pypdfium2), available under
Apache-2.0 or BSD-3-Clause. Its underlying PDFium engine uses a BSD-style
license; additional licenses apply to PDFium's bundled dependencies.

This project declares pypdfium2 as an external dependency. The upstream wheels
include the applicable license files. When bundling these dependencies into an
application or other binary distribution, retain the pypdfium2, PDFium, and
bundled dependency license files from the actual wheels being distributed.
See the upstream [licensing documentation](https://pypdfium2.readthedocs.io/en/stable/readme.html#licensing).

Tests generate synthetic PDFs with ReportLab (BSD license). ReportLab is a
development dependency and is not needed to run the downloader.

## Optional Zotero translators

Zotero translator files are not bundled. Users may supply their own files;
their provenance and licensing are documented in
[translators/THIRD_PARTY_NOTICES.md](translators/THIRD_PARTY_NOTICES.md).

These notes describe the components above, not a complete dependency license
inventory. Each dependency retains its own license.
