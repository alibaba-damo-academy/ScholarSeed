"""Core data models shared across the service."""

from __future__ import annotations

import enum
import hashlib
import json
from dataclasses import dataclass, field, asdict, fields
from datetime import datetime, timezone
from typing import Any, Optional


class IdentifierKind(str, enum.Enum):
    DOI = "doi"
    ARXIV = "arxiv"
    URL = "url"
    UNKNOWN = "unknown"


class Status(str, enum.Enum):
    SUCCESS = "success"
    UNABLE = "unable"
    CACHED = "cached"  # already in the library, returned without re-downloading


class UnableReason(str, enum.Enum):
    UNPARSEABLE = "unparseable_identifier"
    NOT_FOUND = "not_found"
    URL_ERROR = "url_error"
    NO_PDF_LINK = "no_pdf_link"
    PAYWALL = "paywall_or_access_denied"
    BLOCKED = "blocked_captcha_or_cloudflare"
    NEEDS_MANUAL = "needs_manual_solve"  # bot challenge/captcha remains unresolved
    NEEDS_LOGIN = "needs_institutional_login"
    INSTITUTE_NO_ACCESS = "institute_no_access"
    SKIPPED = "skipped_by_user"
    DOWNLOAD_FAILED = "download_failed"
    INVALID_PDF = "invalid_or_corrupt_pdf"
    IDENTITY_MISMATCH = "identifier_mismatch"
    NETWORK_ERROR = "network_error"
    TIMEOUT = "timeout"
    UNKNOWN_ERROR = "unknown_error"


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Identifier:
    """A normalized input identifier."""

    kind: IdentifierKind
    value: str          # normalized canonical value (e.g. bare DOI, arXiv id, or URL)
    original: str       # exactly what the user passed in

    @property
    def slug(self) -> str:
        """Collision-resistant filesystem key used as the library folder name."""
        import re
        from urllib.parse import urlsplit

        base = self.value or self.original
        if self.kind == IdentifierKind.URL:
            # Signed URLs commonly carry credentials in their query string or
            # path. Keep the readable portion deliberately host-only; the hash
            # below still provides stable collision resistance without exposing
            # the secret in directory names and persisted output paths.
            try:
                base = urlsplit(base).hostname or "url"
            except Exception:
                base = "url"
        base = base.strip().lower()
        base = re.sub(r"^https?://", "", base)
        readable = re.sub(r"[^a-z0-9._-]+", "_", base).strip("_")[:100]
        identity = f"{self.kind.value}\0{self.value or self.original}"
        digest = hashlib.sha256(identity.encode("utf-8", "surrogatepass")).hexdigest()[:16]
        return f"{readable or 'item'}--{digest}"

    @property
    def legacy_slug(self) -> str:
        """Pre-hash folder name, used only to find an unambiguous old cache."""
        import re

        base = (self.value or self.original).strip().lower()
        base = re.sub(r"^https?://", "", base)
        return (re.sub(r"[^a-z0-9._-]+", "_", base).strip("_")[:120]
                or "item")


@dataclass
class ZoteroResult:
    """Result of saving a paper to Zotero via the Connector extension."""

    saved: bool = False
    item_key: Optional[str] = None
    collection_key: Optional[str] = None
    attachment_key: Optional[str] = None
    linked_file: Optional[str] = None   # path to the PDF in Zotero storage
    error: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DownloadAttempt:
    """One concrete attempt against one candidate URL — for the audit trail."""

    method: str           # e.g. "browser", "http", "unpaywall"
    url: str
    ok: bool
    detail: str = ""
    elapsed_s: float = 0.0


@dataclass
class DiscoveryProvenance:
    """Why the selected full-text candidate was considered for acquisition."""

    sources: list[str] = field(default_factory=list)
    matched_doi: Optional[str] = None
    work_version: Optional[str] = None
    license: Optional[str] = None
    evidence: list[str] = field(default_factory=list)
    strict_identity: bool = False
    strict_identity_verified: bool = False
    independent_access: bool = False
    provider_oa_asserted: bool = False
    acquisition_succeeded: bool = False


@dataclass
class DownloadResult:
    """The outcome for a single requested identifier."""

    identifier: Identifier
    status: Status
    reason: Optional[UnableReason] = None
    message: str = ""
    title: Optional[str] = None
    source_url: Optional[str] = None       # landing page / where the PDF came from
    pdf_url: Optional[str] = None
    original_path: Optional[str] = None    # kept copy, exactly as downloaded
    content_type: str = "pdf"              # "pdf" or "html_fulltext"
    bytes: int = 0
    zotero: ZoteroResult = field(default_factory=ZoteroResult)
    attempts: list[DownloadAttempt] = field(default_factory=list)
    # A bot challenge / captcha was encountered while processing this item — in an
    # interactive window the human had to solve it (whether or not the download
    # ultimately succeeded). Lets the report show which items needed a manual solve.
    manual_challenge: bool = False
    # Safe publisher/platform label (normally a hostname) learned when a strong
    # institutional-login gate is detected. Used to suppress duplicate work and
    # group end-of-batch login assistance, including across runs sharing --out.
    institution_login_platform: Optional[str] = None
    # "needs_login", "no_access", or "authenticated". The first two can come
    # from the durable access-memory file; authenticated is result history only.
    institution_access_state: Optional[str] = None
    started_at: str = field(default_factory=_utcnow)
    finished_at: Optional[str] = None
    # Appended for positional compatibility with older DownloadResult callers.
    discovery: DiscoveryProvenance = field(default_factory=DiscoveryProvenance)
    # Additive acquisition diagnostics; older reports remain valid.
    acquisition_source: Optional[str] = None
    action_reason: Optional[str] = None
    # The aggregate result may succeed from PMC/arXiv while the publisher route
    # failed.  Preserve that publisher-only outcome so audits do not have to
    # reverse-engineer it from the attempt list.
    publisher: Optional[str] = None
    publisher_path_status: Optional[str] = None  # "success" | "failed" | "not_attempted"
    publisher_path_reason: Optional[str] = None
    publisher_path_detail: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.status in (Status.SUCCESS, Status.CACHED)

    def to_dict(self) -> dict[str, Any]:
        from .sanitize import sanitize_text, sanitize_url

        d = asdict(self)
        d["identifier"]["kind"] = self.identifier.kind.value
        d["status"] = self.status.value
        d["reason"] = self.reason.value if self.reason else None
        d["message"] = sanitize_text(d.get("message") or "")
        for key in ("value", "original"):
            if d["identifier"].get(key):
                d["identifier"][key] = sanitize_text(d["identifier"][key])
        for key in ("source_url", "pdf_url"):
            if d.get(key):
                d[key] = sanitize_url(d[key])
        for key in ("publisher", "publisher_path_status", "publisher_path_reason",
                    "publisher_path_detail"):
            if d.get(key):
                d[key] = sanitize_text(str(d[key]))
        for attempt in d.get("attempts") or []:
            attempt["url"] = sanitize_url(attempt.get("url") or "")
            attempt["detail"] = sanitize_text(attempt.get("detail") or "")
        if (d.get("zotero") or {}).get("error"):
            d["zotero"]["error"] = sanitize_text(d["zotero"]["error"])
        discovery = d.get("discovery") or {}
        for key in ("sources", "evidence"):
            discovery[key] = [
                sanitize_text(str(value)) for value in (discovery.get(key) or [])
            ]
        for key in ("matched_doi", "work_version", "license"):
            if discovery.get(key):
                discovery[key] = sanitize_text(str(discovery[key]))
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DownloadResult":
        """Rehydrate a persisted result while tolerating older metadata files."""
        raw = dict(data or {})
        ident_data = raw.pop("identifier", {}) or {}
        try:
            kind = IdentifierKind(ident_data.get("kind", IdentifierKind.UNKNOWN.value))
        except ValueError:
            kind = IdentifierKind.UNKNOWN
        ident = Identifier(
            kind=kind,
            value=str(ident_data.get("value", "")),
            original=str(ident_data.get("original", ident_data.get("value", ""))),
        )
        try:
            status = Status(raw.pop("status", Status.UNABLE.value))
        except ValueError:
            status = Status.UNABLE
        reason_value = raw.pop("reason", None)
        try:
            reason = UnableReason(reason_value) if reason_value else None
        except ValueError:
            reason = None

        def known(model, values):
            allowed = {f.name for f in fields(model)}
            return {k: v for k, v in (values or {}).items() if k in allowed}

        raw["zotero"] = ZoteroResult(**known(ZoteroResult, raw.get("zotero")))
        raw["discovery"] = DiscoveryProvenance(**known(
            DiscoveryProvenance, raw.get("discovery")))
        raw["attempts"] = [
            DownloadAttempt(**known(DownloadAttempt, attempt))
            for attempt in (raw.get("attempts") or [])
            if isinstance(attempt, dict)
        ]
        return cls(
            identifier=ident,
            status=status,
            reason=reason,
            **known(cls, raw),
        )

    def index_row(self) -> dict[str, Any]:
        """The flat record appended to the library index.jsonl — defined here so it
        cannot drift from metadata.json (storage adds the timestamp)."""
        from .sanitize import sanitize_text

        return {
            "identifier": sanitize_text(self.identifier.value),
            "kind": self.identifier.kind.value,
            "status": self.status.value,
            "reason": self.reason.value if self.reason else None,
            "title": self.title,
            "original_path": self.original_path,
            "manual_challenge": self.manual_challenge,
        }


@dataclass
class BatchReport:
    """Aggregate report for a batch of requests."""

    results: list[DownloadResult] = field(default_factory=list)
    started_at: str = field(default_factory=_utcnow)
    finished_at: Optional[str] = None

    @property
    def n_total(self) -> int:
        return len(self.results)

    @property
    def n_success(self) -> int:
        return sum(1 for r in self.results if r.status == Status.SUCCESS)

    @property
    def n_cached(self) -> int:
        return sum(1 for r in self.results if r.status == Status.CACHED)

    @property
    def n_unable(self) -> int:
        return sum(1 for r in self.results if r.status == Status.UNABLE)

    @property
    def n_needs_manual(self) -> int:
        return sum(1 for r in self.results
                   if r.reason == UnableReason.NEEDS_MANUAL)

    @property
    def n_manual_challenge(self) -> int:
        return sum(1 for r in self.results if r.manual_challenge)

    def to_dict(self) -> dict[str, Any]:
        return {
            "summary": {
                "total": self.n_total,
                "success": self.n_success,
                "cached": self.n_cached,
                "unable": self.n_unable,
                "needs_manual": self.n_needs_manual,
                "manual_challenge": self.n_manual_challenge,
            },
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "results": [r.to_dict() for r in self.results],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
