"""Plain-HTTP fast path / fallback using httpx.

Used for direct & open-access URLs (arXiv, Unpaywall, *.pdf links) where a full
browser is unnecessary. Carries realistic headers and honors the optional
proxy / EZproxy settings.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

from urllib.parse import urlparse, urlunparse

import httpx

from .config import ServiceConfig
from .deadline import check as check_item_deadline, clamp_seconds
from .pdfutil import is_pdf_bytes, looks_like_html

# Hosts that must NOT be routed through an institutional proxy (free / OA / APIs).
_EZPROXY_SKIP_HOSTS = (
    "arxiv.org", "doi.org", "dx.doi.org", "api.unpaywall.org",
    "unpaywall.org", "localhost", "127.0.0.1",
)


@dataclass
class FetchResult:
    ok: bool
    data: Optional[bytes] = None
    content_type: str = ""
    final_url: str = ""
    status: int = 0
    detail: str = ""


def _headers(cfg: ServiceConfig, referer: Optional[str]) -> dict[str, str]:
    h = {
        "User-Agent": cfg.browser.user_agent,
        "Accept": "application/pdf,text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    }
    if referer:
        h["Referer"] = referer
    return h


def apply_ezproxy(url: str, cfg: ServiceConfig) -> str:
    """Rewrite a publisher URL to go through the institution's EZproxy, if set.

    Prefers the hostname-rewrite form (www.nature.com ->
    www-nature-com.ezproxy.lib.example.edu); falls back to the legacy login-prefix
    form. Free/OA/API hosts (arXiv, doi.org, Unpaywall) are never proxied.
    """
    bc = cfg.browser
    if not url or (not bc.ezproxy_host and not bc.ezproxy_prefix):
        return url
    try:
        p = urlparse(url)
    except Exception:
        return url
    host = (p.netloc or "").lower()
    proxy_host = (bc.ezproxy_host or "").lower().strip(".")
    if proxy_host and (host == proxy_host or host.endswith("." + proxy_host)):
        return url
    if not host or any(host == h or host.endswith("." + h) for h in _EZPROXY_SKIP_HOSTS):
        return url
    if bc.ezproxy_host:
        new_netloc = host.replace(".", "-") + "." + bc.ezproxy_host
        return urlunparse((p.scheme, new_netloc, p.path, p.params, p.query, p.fragment))
    return bc.ezproxy_prefix + url


def _client(cfg: ServiceConfig) -> httpx.Client:
    proxies = cfg.browser.proxy or None
    # Cap the read/connect timeouts: httpx's read timeout is the max gap BETWEEN
    # bytes (not the total download time), so a tight bound still lets a large
    # PDF stream, while stopping a stalled or molasses-slow server (e.g. a 502
    # that dribbles back after a minute) from burning the whole per-item budget.
    # http_timeout_s is the tunable read budget, still capped by the per-item one.
    read_timeout = clamp_seconds(
        min(float(cfg.per_request_timeout_s), float(cfg.http_timeout_s))
    )
    connect_timeout = clamp_seconds(
        min(20.0 if cfg.autodev else 30.0, read_timeout)
    )
    return httpx.Client(
        follow_redirects=True,
        timeout=httpx.Timeout(read_timeout, connect=connect_timeout),
        proxy=proxies,
        headers={"User-Agent": cfg.browser.user_agent},
    )


def fetch(url: str, cfg: ServiceConfig, referer: Optional[str] = None) -> FetchResult:
    """GET a URL; return raw bytes plus a verdict on whether it is a PDF."""
    target = apply_ezproxy(url, cfg)
    started = time.monotonic()
    # In unattended downloading a server that continuously dribbles bytes never
    # trips httpx's gap-based read timeout. Keep the fast path fast and allow the
    # browser/HTML strategies to run before the per-paper deadline is exhausted.
    total_transfer_cap = min(float(cfg.http_timeout_s), 15.0) if cfg.autodev else None
    try:
        check_item_deadline()
        with _client(cfg) as client:
            # Stream so the absolute deadline is checked between chunks. The
            # per-read timeout is also clamped to the remaining item budget, so a
            # server that stops yielding bytes cannot cross the cap cooperatively.
            with client.stream("GET", target, headers=_headers(cfg, referer)) as r:
                chunks = []
                for chunk in r.iter_bytes():
                    check_item_deadline()
                    if (total_transfer_cap is not None
                            and time.monotonic() - started > total_transfer_cap):
                        return FetchResult(
                            ok=False,
                            content_type=r.headers.get("content-type", "").lower(),
                            final_url=str(r.url),
                            status=r.status_code,
                            detail=("autodev total-transfer timeout after "
                                    f"{total_transfer_cap:g}s"),
                        )
                    chunks.append(chunk)
                data = b"".join(chunks)
                check_item_deadline()
                ct = r.headers.get("content-type", "").lower()
                ok = r.status_code == 200 and (is_pdf_bytes(data) or "pdf" in ct)
                return FetchResult(
                    ok=ok,
                    data=data,
                    content_type=ct,
                    final_url=str(r.url),
                    status=r.status_code,
                    detail=f"status={r.status_code} ct={ct} bytes={len(data)}",
                )
    except httpx.TimeoutException as e:
        return FetchResult(ok=False, detail=f"timeout: {e}")
    except Exception as e:  # noqa: BLE001
        return FetchResult(ok=False, detail=f"error: {type(e).__name__}: {e}")


def fetch_html(url: str, cfg: ServiceConfig, referer: Optional[str] = None) -> FetchResult:
    """GET a URL expecting HTML (for landing-page discovery)."""
    target = apply_ezproxy(url, cfg)
    try:
        check_item_deadline()
        with _client(cfg) as client:
            with client.stream("GET", target, headers=_headers(cfg, referer)) as r:
                chunks = []
                for chunk in r.iter_bytes():
                    check_item_deadline()
                    chunks.append(chunk)
                data = b"".join(chunks)
                check_item_deadline()
                return FetchResult(
                    ok=r.status_code == 200,
                    data=data,
                    content_type=r.headers.get("content-type", "").lower(),
                    final_url=str(r.url),
                    status=r.status_code,
                    detail=f"status={r.status_code}",
                )
    except Exception as e:  # noqa: BLE001
        return FetchResult(ok=False, detail=f"error: {type(e).__name__}: {e}")
