"""Stable download runtime shared by the public CLI and internal callers.

This is a single-command tool — pass identifiers directly, no subcommand word.

Examples
--------
  paper-dl 10.1038/s41467-023-37495-9 arXiv:1706.03762
  paper-dl --input ids.txt --out results --storage library
  paper-dl 10.1137/080716542 --connect-cdp http://127.0.0.1:9222
"""

from __future__ import annotations

import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import typer
import yaml
from rich.console import Console

from .config import ServiceConfig
from .identifiers import lines_from_input_text
from .models import BatchReport, UnableReason
from .report import render
from .sanitize import sanitize_text
from .service import PaperDownloadService
from .skip_control import KeyboardSkipController

console = Console()


# The browser preset applied by --max-stealth is expressed as data so composition
# is unit-testable and explicit CLI flags can override it. It never sets
# ``user_agent``: with real Chrome or Patchright a spoofed UA is more detectable.
STEALTH_PRESET: dict = {"headless": False, "prefer_patchright": True}


def _apply_browser_overrides(cfg, *, channel, profile, proxy, ezproxy_host,
                             headless, keep_open, max_stealth,
                             connect_cdp=None) -> None:
    """Apply CLI browser options with precedence: config/YAML < preset < explicit flag.

    ``--max-stealth`` selects real Chrome plus a visible window. An explicit
    ``--channel`` wins over that preset, and ``headless`` is ``None`` when the
    user did not pass either visibility flag, so YAML is not clobbered.
    ``--connect-cdp`` attaches to an existing Chrome and forces the interactive
    posture.
    """
    bc = cfg.browser
    if max_stealth:
        # real-Chrome default; an explicit --channel or a configured channel wins.
        bc.channel = channel or bc.channel or "chrome"
        for k, v in STEALTH_PRESET.items():
            setattr(bc, k, v)
    # explicit CLI flags win over presets and config.
    if channel:
        bc.channel = channel
    if profile:
        bc.user_data_dir = profile
    if proxy:
        bc.proxy = proxy
    if ezproxy_host:
        bc.ezproxy_host = ezproxy_host
    if keep_open:
        bc.keep_open = True
    if headless is not None:
        bc.headless = headless
    # Attach to a user-launched Chrome instead of launching one. Force the
    # interactive posture: keep the engine connected so you can solve a challenge
    # in your own browser and the manual-assist retry works; headless is moot (your
    # Chrome is whatever you started) but False keeps the solve/retry loop running.
    if connect_cdp:
        bc.cdp_endpoint = connect_cdp
        bc.enabled = True
        bc.keep_open = True
        bc.headless = False


def _assist_institution_logins(
    svc: PaperDownloadService,
    report: BatchReport,
    skip_controller,
    *,
    input_fn=input,
    output_fn=None,
) -> BatchReport:
    """Open each login-gated platform once, then retry its paper group."""
    pending = [row for row in report.results
               if not row.ok and row.reason == UnableReason.NEEDS_LOGIN]
    if not pending:
        return report

    emit = output_fn or console.print
    emit("\n[bold]Institutional login assistance[/bold]")
    groups: dict[str, list] = {}
    for row in pending:
        key = row.institution_login_platform or f"item:{id(row)}"
        groups.setdefault(key, []).append(row)

    emit(
        f"{len(pending)} paper(s) across {len(groups)} publisher platform(s) need "
        "institutional authentication. Each platform will open once in the same "
        "browser profile/session used for downloading."
    )
    emit(
        "Complete institutional SSO/login in the browser. Cookies created by the "
        "publisher or identity provider are reused by the retry. "
        "[yellow]Caution:[/yellow] choosing n=Institute no access marks the "
        "whole publisher platform, not only this paper or journal, and remembers "
        "that decision across sibling --out folders in the same parent directory."
    )

    for index, group in enumerate(groups.values(), 1):
        previous = group[0]
        ident = previous.identifier.value or previous.identifier.original
        platform = previous.institution_login_platform
        group_label = platform or ident
        emit(
            f"\n[bold][{index}/{len(groups)}] {group_label}[/bold] "
            f"({len(group)} paper(s))"
        )
        emit(
            f"Opening {ident}. Choose institutional access and complete SSO/2FA. "
            "If the publisher confirms your institute has no access, choose n."
        )
        page = None
        try:
            page = svc.open_institution_login_page(previous)
        except Exception as exc:  # noqa: BLE001
            emit(
                f"[red]Could not open the login page:[/red] "
                f"{type(exc).__name__}: {exc}"
            )
            continue

        try:
            while True:
                try:
                    answer = input_fn(
                        "Enter=login complete, retry group; n=Institute no access "
                        "(marks whole platform; be cautious); s=skip group; "
                        "q=stop login assistance: "
                    ).strip().lower()
                except (EOFError, KeyboardInterrupt):
                    answer = "q"
                if answer in {"", "n", "s", "q"}:
                    break
                emit("[yellow]Please press Enter, or type n, s, or q.[/yellow]")

            if answer == "q":
                emit("Stopping institutional-login assistance.")
                break
            if answer == "s":
                emit(
                    f"Leaving {len(group)} paper(s) for {group_label} as needing "
                    "institutional login."
                )
                continue
            if answer == "n":
                if svc.mark_institute_no_access(report, group):
                    emit(
                        f"[yellow]Institute no access:[/yellow] remembered "
                        f"{group_label} for {len(group)} paper(s) in "
                        f"{svc.institution_access_memory_path}."
                    )
                else:
                    emit(
                        "[red]Could not remember Institute no access:[/red] no safe "
                        "publisher platform key was available."
                    )
                continue

            retried_results: list = []
            for group_index, target in enumerate(group, 1):
                target_ident = (
                    target.identifier.value or target.identifier.original
                )
                emit(
                    f"[dim]Retrying [{group_index}/{len(group)}] {target_ident} "
                    "with the authenticated browser session...[/dim]"
                )
                try:
                    with skip_controller:
                        if getattr(skip_controller, "enabled", False):
                            emit("[dim]Press s to skip the running retry.[/dim]")
                        retried = svc.retry_result(report, target)
                except Exception as exc:  # noqa: BLE001
                    emit(
                        f"[red]Retry could not run:[/red] "
                        f"{type(exc).__name__}: {exc}"
                    )
                    continue

                retried_results.append(retried)
                if retried.ok:
                    emit(
                        f"[green]Download succeeded after institutional login: "
                        f"{target_ident}[/green]"
                    )
                elif retried.reason == UnableReason.NEEDS_LOGIN:
                    emit(
                        f"[yellow]Still needs institutional access: "
                        f"{target_ident}.[/yellow] Login may be incomplete, or your "
                        "institution may not have entitlement to this paper."
                    )
                else:
                    reason = retried.reason.value if retried.reason else "unknown"
                    emit(
                        f"[yellow]Retry finished unable ({reason}): "
                        f"{target_ident}.[/yellow]"
                    )

            # Persist only confirmed access. A failed retry keeps needs_login;
            # no_access requires the explicit `n` choice above because a failed
            # article cannot prove platform-wide lack of entitlement.
            state = svc.resolve_institution_login_group(report, retried_results)
            if state == "authenticated":
                emit(
                    f"[green]Access confirmed for {group_label};[/green] marked the "
                    f"platform authenticated in {svc.institution_access_memory_path}."
                )
            elif state == "needs_login":
                emit(
                    f"[dim]Access was not confirmed for {group_label}; kept the "
                    "saved needs-login gate for a future login-assist run. The "
                    "platform was not marked Institute no access.[/dim]"
                )
        finally:
            if page is not None:
                svc.close_institution_login_page(page)

    return report


def _run_cli(
    *,
    identifiers: list[str] | None = None,
    input_file: Path | None = None,
    config: Path | None = None,
    storage: str | None = None,
    out: str | None = None,
    email: str | None = None,
    profile: str | None = None,
    proxy: str | None = None,
    ezproxy_host: str | None = None,
    channel: str | None = None,
    headless: bool | None = None,
    max_stealth: bool = False,
    connect_cdp: str | None = None,
    keep_open: bool = False,
    overwrite: bool | None = None,
    prefer_oa: bool | None = None,
    translators_dir: Path | None = None,
    no_translators: bool = False,
    zotero_save: bool = False,
    no_zotero: bool = False,
    zotero_collection_key: str | None = None,
    zotero_storage_dir: str | None = None,
    autodev: bool = False,
    paper_timeout: float | None = None,
):
    """Download one or more papers."""
    try:
        ids: list[str] = list(identifiers or [])
        if input_file:
            ids += lines_from_input_text(Path(input_file).read_text(encoding="utf-8-sig"))
        if not ids:
            console.print("No identifiers given. Pass them as arguments or via --input.")
            raise typer.Exit(2)
        cfg = ServiceConfig.load(config)
    except (OSError, UnicodeError, ValueError, TypeError, yaml.YAMLError) as exc:
        console.print(f"Input/configuration error: {exc}", markup=False)
        raise typer.Exit(2) from exc

    if storage:
        cfg.storage_dir = storage
    if out:
        cfg.output_dir = out
    if email:
        cfg.unpaywall_email = email
    if paper_timeout is not None:
        cfg.per_request_timeout_s = paper_timeout
    _apply_browser_overrides(
        cfg, channel=channel, profile=profile, proxy=proxy, ezproxy_host=ezproxy_host,
        headless=headless, keep_open=keep_open, max_stealth=max_stealth,
        connect_cdp=connect_cdp)
    if autodev:
        cfg.browser.challenge_human_wait_s = min(cfg.browser.challenge_human_wait_s, 10.0)
        cfg.browser.challenge_wait_s = min(cfg.browser.challenge_wait_s, 10.0)
        cfg.browser.download_wait_s = min(cfg.browser.download_wait_s, 15.0)
        cfg.inter_request_delay_s = min(cfg.inter_request_delay_s, 0.3)
        # Unattended retains its historical shorter cap unless the configured/CLI
        # hard deadline is already lower.
        cfg.per_request_timeout_s = min(cfg.per_request_timeout_s, 180.0)
        cfg.zotero.save_timeout_s = min(cfg.zotero.save_timeout_s, 12.0)
        cfg.zotero.poll_interval_s = min(cfg.zotero.poll_interval_s, 1.0)
        # Cap page-load wait so a slow / gated landing can't burn the full 35s
        # before we fall through to the standard strategies.
        cfg.browser.nav_timeout_ms = min(cfg.browser.nav_timeout_ms, 20_000)
        # Keep every individual browser-side PDF transfer well below the item
        # deadline. Some Playwright response-body calls defer Python signal
        # delivery, so the POSIX watchdog alone cannot reliably pre-empt them.
        cfg.browser.pdf_request_timeout_ms = min(
            cfg.browser.pdf_request_timeout_ms, 15_000
        )
        cfg.autodev = True
        console.print("[yellow]--autodev: unattended mode — bot challenges are skipped "
                      "(marked 'needs manual solve'), inaccessible publishers skipped "
                      "after 2 failures[/yellow]")
    if overwrite is not None:
        cfg.overwrite = overwrite
    if prefer_oa is not None:
        cfg.prefer_published = not prefer_oa
    if no_translators and translators_dir is not None:
        console.print("Conflicting flags: --no-translators and --translators-dir cannot be used together.")
        raise typer.Exit(2)
    if no_translators:
        cfg.browser.translators_dir = None
    elif translators_dir is not None:
        cfg.browser.translators_dir = str(translators_dir.expanduser().resolve())
    if no_zotero and zotero_save:
        console.print("Conflicting flags: --no-zotero and --zotero-save cannot be used together.")
        raise typer.Exit(2)
    if no_zotero:
        cfg.zotero.enabled = False
    elif zotero_save:
        cfg.zotero.enabled = True
    if zotero_collection_key:
        cfg.zotero.collection_key = zotero_collection_key
    if zotero_storage_dir:
        cfg.zotero.storage_dir = zotero_storage_dir

    skip_controller = KeyboardSkipController(output_fn=lambda m: console.print(m))
    svc = PaperDownloadService(
        cfg,
        logger=lambda m: console.print(sanitize_text(m), style="dim", markup=False),
        skip_controller=skip_controller,
        isolate_items=True,
    )
    interactive = (cfg.browser.keep_open and not cfg.browser.headless
                   and not cfg.autodev)
    login_assist = (cfg.browser.enabled and not cfg.browser.headless
                    and not cfg.autodev)
    try:
        with skip_controller:
            if skip_controller.enabled:
                console.print("[dim]While a paper is running, press [bold]s[/bold] "
                              "(no Enter) to skip it.[/dim]")
            report = svc.download_many(ids)
        if login_assist:
            report = _assist_institution_logins(
                svc, report, skip_controller,
            )
        console.rule("Results")
        render(report, console)
        console.print(f"\nReport: [bold]{cfg.output_path / 'report.json'}[/bold]")
        console.print(f"Library: [bold]{cfg.storage_path}[/bold]")


        # Manual-assist loop: the live browser keeps the cleared cf_clearance
        # cookie, so once you solve a challenge in the window, retrying the failed
        # items reuses that session and skips the challenge.
        while interactive:
            failed = [
                r.identifier for r in report.results
                if not r.ok and r.reason not in {
                    UnableReason.NEEDS_LOGIN,
                    UnableReason.INSTITUTE_NO_ACCESS,
                }
            ]
            if failed:
                console.print(
                    f"\n[yellow]{len(failed)} item(s) unable.[/yellow] If you solved a "
                    "challenge (or opened the PDF) in the browser window, type "
                    "[bold]r[/bold] then Enter to retry them — they'll reuse the cleared "
                    "session. Press [bold]Enter[/bold] alone to finish.")
            elif report.n_unable:
                console.print(
                    f"\n[yellow]{report.n_unable} item(s) remain unable.[/yellow] "
                    "Institutional-login and Institute-no-access items are not "
                    "retried again automatically. "
                    "Press [bold]Enter[/bold] to finish."
                )
            else:
                console.print("\n[green]All done.[/green] Press [bold]Enter[/bold] to finish.")
                if cfg.browser.cdp_endpoint:
                    console.print("[dim]Your connected Chrome will stay open.[/dim]")
            try:
                ans = input().strip().lower()
            except (EOFError, KeyboardInterrupt):
                break
            if failed and ans == "r":
                console.print("[dim]Retrying with the same browser profile/session…[/dim]")
                try:
                    with skip_controller:
                        if skip_controller.enabled:
                            console.print("[dim]Press [bold]s[/bold] to skip the running paper.[/dim]")
                        report = svc.retry_failed(
                            report,
                            exclude_reasons={
                                UnableReason.NEEDS_LOGIN,
                                UnableReason.INSTITUTE_NO_ACCESS,
                            },
                        )
                    console.rule("Retry results")
                    render(report, console)
                except Exception as e:  # noqa: BLE001
                    console.print(f"[red]Retry could not run:[/red] {type(e).__name__}: {e}")
                    console.print("Tip: just re-run the same command — your solved session "
                                  "is saved in the browser profile; complete any new challenge if prompted.")
                    break
                continue
            break
    finally:
        svc.close()
    raise typer.Exit(0 if report.n_unable == 0 else 1)
