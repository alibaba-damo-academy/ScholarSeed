"""Small helpers for validating and inspecting downloaded bytes."""

from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass

from .discovery import is_non_article_pdf_url, is_supplement_url
from .work_identity import normalize_identity, strict_pdf_author_matches

_QUIET = False
_dbg = logging.getLogger("paper_dl.pdf")


def get_fitz():
    """Import PyMuPDF and, on first use, silence MuPDF's C-level error spam.

    Publisher PDFs frequently have non-standard xref tables; MuPDF prints
    "format error: cannot find object in xref" while it auto-repairs them. The
    repair is non-fatal (the output PDF is valid), so we suppress the console
    noise — callers can still read accumulated warnings via mupdf_warnings()."""
    global _QUIET
    import fitz  # PyMuPDF

    if not _QUIET:
        try:
            fitz.TOOLS.mupdf_display_errors(False)
        except Exception:
            pass
        _QUIET = True
    return fitz


def drain_mupdf_warnings() -> str:
    """Return (and clear) any accumulated MuPDF warnings, best-effort."""
    try:
        import fitz
        return (fitz.TOOLS.mupdf_warnings() or "").strip()
    except Exception:
        return ""


def is_pdf_bytes(data: bytes | None) -> bool:
    if not data or len(data) < 1024:
        return False
    head = data[:1024].lstrip()
    return head[:5] == b"%PDF-"


def looks_like_html(data: bytes | None) -> bool:
    if not data:
        return False
    head = data[:2048].lstrip().lower()
    return head.startswith(b"<!doctype html") or head.startswith(b"<html") or b"<head" in head[:200]


def pdf_page_count(data: bytes) -> int:
    """Best-effort page count without a hard dependency at import time."""
    try:
        fitz = get_fitz()
        with fitz.open(stream=data, filetype="pdf") as doc:
            return doc.page_count
    except Exception as e:  # noqa: BLE001
        _dbg.debug("pdf_page_count failed: %r", e)
        return 0


def extract_text(data: bytes, max_pages: int = 2) -> str:
    """Best-effort plain-text of the first ``max_pages`` pages (for cheap content
    checks like article identity validation). Empty string on failure."""
    try:
        fitz = get_fitz()
        out = []
        with fitz.open(stream=data, filetype="pdf") as doc:
            for i in range(min(max_pages, doc.page_count)):
                try:
                    out.append(doc.load_page(i).get_text("text") or "")
                except Exception:
                    continue
        return "\n".join(out)
    except Exception as e:  # noqa: BLE001
        _dbg.debug("extract_text failed: %r", e)
        return ""


def pdf_has_visible_content(data: bytes) -> bool:
    """Check rendered pages, including image-only scans and invisible OCR text.

    A bounded grayscale thumbnail avoids allocating a full-resolution image of
    an unusually large page. Stop as soon as any page has visible marks; a blank
    cover does not invalidate the article on subsequent pages.
    """
    try:
        fitz = get_fitz()
        with fitz.open(stream=data, filetype="pdf") as doc:
            for page in doc:
                size = max(page.rect.width, page.rect.height, 1)
                scale = min(1.0, 512 / size)
                pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale),
                                      colorspace=fitz.csGRAY, alpha=False)
                if min(pix.samples, default=255) < 250:
                    return True
    except Exception as exc:  # noqa: BLE001 - an unreadable render is not usable
        _dbg.debug("PDF content inspection failed: %r", exc)
    return False


@dataclass(frozen=True)
class PdfIdentityVerdict:
    accepted: bool
    detail: str
    confidence: str


_DOI_RE = re.compile(r"(?<![A-Z0-9])10\.\d{4,9}/[-._;()/:A-Z0-9]+", re.I)
_TITLE_STOPWORDS = {
    "about", "after", "among", "article", "based", "between", "from",
    "into", "journal", "paper", "study", "that", "their", "these", "this",
    "through", "using", "with", "without",
}
_ISSUE_MATTER_TEXT_RE = re.compile(
    r"\b(?:table of contents|contents\s+vol\.|submission information|"
    r"subscription information|associate editors|editorial board)\b",
    re.I,
)
_ERROR_DOCUMENT_RE = re.compile(
    r"\b(?:error\s+404\s+page not found|404\s+(?:error|page not found)|"
    r"access denied|request could not be satisfied)\b",
    re.I,
)


def _canonical_doi(value: str) -> str:
    cleaned = (value or "").strip().casefold()
    cleaned = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", cleaned)
    cleaned = cleaned.rstrip(".,;:")
    while cleaned.endswith(")") and cleaned.count("(") < cleaned.count(")"):
        cleaned = cleaned[:-1]
    return cleaned


# Only standalone section headings delimit citations, not mentions in prose or
# titles such as "References for graph theory". Use the same primary text for
# DOI, title and author evidence so a bibliography cannot satisfy any of them.
_REFERENCE_HEADING_RE = re.compile(
    r"^[ \t]*(?:(?:\d+(?:\.\d+)*[.)]?|[IVX]+[.)]?)[ \t]+)?"
    r"(?:references(?:[ \t]+and[ \t]+notes)?|bibliography|literature[ \t]+cited)"
    r"[ \t]*[:.]?[ \t]*$", re.I | re.M,
)


def _dois_in_text(text: str, expected_dois: tuple[str, ...] = ()) -> set[str]:
    # A known DOI can span typesetting lines, but its expected length is not
    # evidence of where the printed DOI ends. Retain subsequent standalone DOI
    # fragments too, including ones separated by further line breaks. Prose,
    # blank lines, common section headings and another DOI bound the token.
    text = text.replace("\u00ad", "")
    line_break = r"(?:[ \t]*\r?\n[ \t]*)?"
    continuation = (
        r"(?:[ \t]*\r?\n[ \t]*"
        r"(?!(?:abstract|introduction|keywords|background|methods|results|"
        r"discussion|conclusions?|references|bibliography)[ \t]*:?[ \t]*(?:\r?\n|$))"
        r"(?!10\.\d{4,9}/)[-._;()/:A-Z0-9]+(?=[ \t]*(?:\r?\n|$)))*"
    )
    for expected in expected_dois:
        expected = _canonical_doi(expected)
        if not expected:
            continue
        pattern = re.compile(
            r"(?<![A-Z0-9])" + line_break.join(re.escape(c) for c in expected)
            + r"[-._;()/:A-Z0-9]*" + continuation, re.I,
        )

        # Normalize even a longer candidate: leaving the source untouched
        # would let _DOI_RE below rediscover its first line as the expected DOI.
        text = pattern.sub(lambda match: re.sub(r"\s+", "", match.group()), text)
    return {_canonical_doi(match) for match in _DOI_RE.findall(text)}


def _title_tokens(value: str) -> set[str]:
    return {
        token for token in re.findall(r"[a-z0-9]+", (value or "").casefold())
        if len(token) >= 4 and token not in _TITLE_STOPWORDS
    }


def validate_pdf_identity(
    data: bytes,
    *,
    expected_doi: str | None = None,
    expected_title: str | None = None,
    source_url: str | None = None,
    accepted_dois: tuple[str, ...] = (),
    expected_authors: tuple[str, ...] = (),
    required_author_matches: int | None = None,
    strict: bool = False,
) -> PdfIdentityVerdict:
    """Reject high-confidence wrong-document PDFs before they reach storage.

    Normal publisher candidates retain the historical fail-open behavior because
    legitimate scans can lack machine-readable identity. Title-discovered
    alternates pass ``strict=True`` and must contain a requested/alternate DOI or
    an exact normalized title plus enough verified author names in the first five
    extracted pages; inconclusive evidence is rejected.
    """
    if not is_pdf_bytes(data) or pdf_page_count(data) == 0:
        return PdfIdentityVerdict(False, "not a parseable PDF", "high")
    if not pdf_has_visible_content(data):
        return PdfIdentityVerdict(False, "PDF is blank or has no renderable page content", "high")
    if source_url and is_non_article_pdf_url(source_url):
        return PdfIdentityVerdict(
            False, "URL identifies issue/front matter rather than an article", "high"
        )
    if source_url and is_supplement_url(source_url):
        return PdfIdentityVerdict(
            False, "URL identifies supplementary material, not the article", "high"
        )

    text = extract_text(data, max_pages=5 if strict else 3)
    if len(text.strip()) <= 4_000 and _ERROR_DOCUMENT_RE.search(text[:2_000]):
        return PdfIdentityVerdict(
            False, "PDF contains a publisher error page, not an article", "high"
        )
    text = _REFERENCE_HEADING_RE.split(text, maxsplit=1)[0]
    doi_values = tuple(dict.fromkeys(
        value for value in ((expected_doi or ""), *accepted_dois) if value
    ))
    expected_doi_values = tuple(_canonical_doi(value) for value in doi_values)
    found_dois = _dois_in_text(text, expected_doi_values)
    doi_matches = [value in found_dois for value in expected_doi_values]
    for index, matched in enumerate(doi_matches):
        if matched:
            detail = ("requested DOI found in PDF" if index == 0
                      else "verified alternate DOI found in PDF")
            return PdfIdentityVerdict(True, detail, "high")

    if strict:
        normalized_title = normalize_identity(expected_title)
        normalized_text = normalize_identity(text)
        if not normalized_title or normalized_title not in normalized_text:
            return PdfIdentityVerdict(
                False, "strict identity: exact paper title not found in PDF", "high"
            )
        matched_authors, author_count = strict_pdf_author_matches(
            text, expected_authors
        )
        if author_count == 0:
            return PdfIdentityVerdict(
                False, "strict identity: verified author evidence is missing", "high"
            )
        required_authors = (
            required_author_matches
            if isinstance(required_author_matches, int)
            and not isinstance(required_author_matches, bool)
            and 1 <= required_author_matches <= author_count
            else math.ceil(0.6 * author_count)
        )
        if matched_authors < required_authors:
            return PdfIdentityVerdict(
                False,
                "strict identity: author evidence below threshold "
                f"({matched_authors}/{author_count}, need {required_authors})",
                "high",
            )
        return PdfIdentityVerdict(
            True,
            "exact paper title and verified authors found in PDF "
            f"({matched_authors}/{author_count})",
            "high",
        )

    wanted_tokens = _title_tokens(expected_title or "")
    found_tokens = _title_tokens(text)
    if wanted_tokens:
        overlap = len(wanted_tokens & found_tokens) / len(wanted_tokens)
        if overlap >= 0.65 and len(wanted_tokens & found_tokens) >= 3:
            return PdfIdentityVerdict(True, "paper title matches PDF text", "high")

    # Require two issue-level signals to avoid rejecting an ordinary article
    # that merely mentions an editorial board or contents in its prose.
    issue_markers = len(set(
        marker.casefold() for marker in _ISSUE_MATTER_TEXT_RE.findall(text[:12_000])
    ))
    if issue_markers >= 2 and (not wanted_tokens or len(wanted_tokens & found_tokens) < 3):
        return PdfIdentityVerdict(
            False, "PDF text is journal issue matter, not a primary article", "high"
        )

    if (expected_doi and found_dois
            and (not wanted_tokens or len(wanted_tokens & found_tokens) < 3)):
        return PdfIdentityVerdict(
            False, "PDF contains a different DOI and does not match the paper title", "high"
        )
    return PdfIdentityVerdict(
        True, "no conflicting primary-paper identity evidence", "inconclusive"
    )
