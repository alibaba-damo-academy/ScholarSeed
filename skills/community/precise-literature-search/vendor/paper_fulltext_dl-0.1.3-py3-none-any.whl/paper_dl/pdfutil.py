"""Small helpers for validating and inspecting downloaded bytes."""

from __future__ import annotations

import logging
import math
import re
import threading
from contextlib import closing
from dataclasses import dataclass
from urllib.parse import unquote, urlparse

from .discovery import is_non_article_pdf_url, is_supplement_url
from .publishers.catalog import publisher_for_host, publisher_for_prefix
from .work_identity import normalize_identity, strict_pdf_author_matches

# PDFium is not thread-safe, even for separate documents. Keep creation, use,
# and destruction of all native objects inside this process-wide lock.
_PDFIUM_LOCK = threading.RLock()
_dbg = logging.getLogger("paper_dl.pdf")


def is_pdf_bytes(data: bytes | None) -> bool:
    if not data or len(data) < 1024:
        return False
    head = data[:1024].lstrip()
    return head[:5] == b"%PDF-"


def looks_like_html(data: bytes | None) -> bool:
    if not data:
        return False
    head = data[:2048].lstrip().lower()
    return head.startswith(b"<!doctype html") or head.startswith(b"<html") or b"<head" in head[:200]


def pdf_page_count(data: bytes) -> int:
    """Best-effort page count without a hard dependency at import time."""
    try:
        with _PDFIUM_LOCK:
            import pypdfium2 as pdfium

            with pdfium.PdfDocument(data) as doc:
                return len(doc)
    except Exception as e:  # noqa: BLE001
        _dbg.debug("pdf_page_count failed: %r", e)
        return 0


def extract_text(data: bytes, max_pages: int = 2) -> str:
    """Best-effort plain-text of the first ``max_pages`` pages (for cheap content
    checks like article identity validation). Empty string on failure."""
    try:
        out = []
        with _PDFIUM_LOCK:
            import pypdfium2 as pdfium

            with pdfium.PdfDocument(data) as doc:
                for i in range(min(max_pages, len(doc))):
                    try:
                        with closing(doc[i]) as page, closing(page.get_textpage()) as textpage:
                            text = textpage.get_text_bounded() or ""
                            # PDFium marks a hyphen at a joined line with U+0002.
                            # Preserve the hyphen: it can be part of a DOI suffix.
                            text = text.replace("\x02", "-")
                            out.append(text.replace("\r\n", "\n").replace("\r", "\n"))
                    except Exception:
                        continue
        # A page boundary must not join a DOI to a following page number/token.
        return "\n\n".join(out)
    except Exception as e:  # noqa: BLE001
        _dbg.debug("extract_text failed: %r", e)
        return ""


def pdf_has_visible_content(data: bytes) -> bool:
    """Check rendered pages, including image-only scans and invisible OCR text.

    A bounded grayscale thumbnail avoids allocating a full-resolution image of
    an unusually large page. Stop as soon as any page has visible marks; a blank
    cover does not invalidate the article on subsequent pages.
    """
    try:
        with _PDFIUM_LOCK:
            import pypdfium2 as pdfium

            with pdfium.PdfDocument(data) as doc:
                for i in range(len(doc)):
                    with closing(doc[i]) as page:
                        width, height = page.get_size()
                        if not all(math.isfinite(v) and v > 0 for v in (width, height)):
                            continue
                        scale = min(1.0, 512 / max(width, height))
                        with closing(page.render(
                            scale=scale, grayscale=True, fill_color=(255, 255, 255, 255),
                        )) as bitmap:
                            samples = bytes(bitmap.buffer)
                            # Stride padding is not a pixel and may contain zeros.
                            for row in range(bitmap.height):
                                start = row * bitmap.stride
                                if min(samples[start:start + bitmap.width], default=255) < 250:
                                    return True
    except Exception as exc:  # noqa: BLE001 - an unreadable render is not usable
        _dbg.debug("PDF content inspection failed: %r", exc)
    return False


@dataclass(frozen=True)
class PdfIdentityVerdict:
    accepted: bool
    detail: str
    confidence: str


_DOI_RE = re.compile(r"(?<![A-Z0-9])10\.\d{4,9}/[-._;()/:A-Z0-9]+", re.I)
_TITLE_STOPWORDS = {
    "about", "after", "among", "article", "based", "between", "from",
    "into", "journal", "paper", "study", "that", "their", "these", "this",
    "through", "using", "with", "without",
}
# Below this amount, extracted text can be stray OCR from an otherwise scanned
# document; keep such PDFs eligible unless another high-confidence check fails.
_MIN_SUBSTANTIAL_TEXT_WORDS = 20
_ISSUE_MATTER_TEXT_RE = re.compile(
    r"\b(?:table of contents|contents\s+vol\.|submission information|"
    r"subscription information|associate editors|editorial board)\b",
    re.I,
)
_ERROR_DOCUMENT_RE = re.compile(
    r"\b(?:error\s+404\s+page not found|404\s+(?:error|page not found)|"
    r"access denied|request could not be satisfied)\b",
    re.I,
)


def _canonical_doi(value: str) -> str:
    cleaned = (value or "").strip().casefold()
    cleaned = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", cleaned)
    cleaned = cleaned.rstrip(".,;:")
    while cleaned.endswith(")") and cleaned.count("(") < cleaned.count(")"):
        cleaned = cleaned[:-1]
    return cleaned


# Only standalone section headings delimit citations, not mentions in prose or
# titles such as "References for graph theory". Use the same primary text for
# DOI, title and author evidence so a bibliography cannot satisfy any of them.
_REFERENCE_HEADING_RE = re.compile(
    r"^[ \t]*(?:(?:\d+(?:\.\d+)*[.)]?|[IVX]+[.)]?)[ \t]+)?"
    r"(?:references(?:[ \t]+and[ \t]+notes)?|bibliography|literature[ \t]+cited)"
    r"[ \t]*[:.]?[ \t]*$", re.I | re.M,
)


def _dois_in_text(text: str, expected_dois: tuple[str, ...] = ()) -> set[str]:
    # A known DOI can span typesetting lines, but its expected length is not
    # evidence of where the printed DOI ends. Retain subsequent standalone DOI
    # fragments too, including ones separated by further line breaks. Prose,
    # blank lines, common section headings and another DOI bound the token.
    text = text.replace("\u00ad", "")
    line_break = r"(?:[ \t]*\r?\n[ \t]*)?"
    continuation = (
        r"(?:[ \t]*\r?\n[ \t]*"
        r"(?!(?:abstract|introduction|keywords|background|methods|results|"
        r"discussion|conclusions?|references|bibliography)[ \t]*:?[ \t]*(?:\r?\n|$))"
        r"(?!10\.\d{4,9}/)[-._;()/:A-Z0-9]+(?=[ \t]*(?:\r?\n|$)))*"
    )
    for expected in expected_dois:
        expected = _canonical_doi(expected)
        if not expected:
            continue
        pattern = re.compile(
            r"(?<![A-Z0-9])" + line_break.join(re.escape(c) for c in expected)
            + r"[-._;()/:A-Z0-9]*" + continuation, re.I,
        )

        # Normalize even a longer candidate: leaving the source untouched
        # would let _DOI_RE below rediscover its first line as the expected DOI.
        text = pattern.sub(lambda match: re.sub(r"\s+", "", match.group()), text)
    return {_canonical_doi(match) for match in _DOI_RE.findall(text)}


def _title_tokens(value: str) -> set[str]:
    return {
        token for token in re.findall(r"[a-z0-9]+", (value or "").casefold())
        if len(token) >= 4 and token not in _TITLE_STOPWORDS
    }


def _source_url_supports_expected_doi(
    expected_doi: str | None,
    source_url: str | None,
) -> bool:
    """Return whether the URL itself is authoritative identity evidence."""
    expected = _canonical_doi(expected_doi or "")
    if not expected or not source_url:
        return False

    decoded_url = unquote(source_url)
    expected_in_url = re.search(
        r"(?<![A-Z0-9])" + re.escape(expected) + r"(?![-._;()/:A-Z0-9])",
        decoded_url,
        re.I,
    )
    if expected_in_url:
        return True

    expected_publisher = publisher_for_prefix(expected.split("/", 1)[0])
    try:
        source_host = urlparse(source_url).hostname or ""
    except ValueError:
        return False
    return bool(
        expected_publisher
        and publisher_for_host(source_host) == expected_publisher
    )


def validate_pdf_identity(
    data: bytes,
    *,
    expected_doi: str | None = None,
    expected_title: str | None = None,
    source_url: str | None = None,
    accepted_dois: tuple[str, ...] = (),
    expected_authors: tuple[str, ...] = (),
    required_author_matches: int | None = None,
    strict: bool = False,
) -> PdfIdentityVerdict:
    """Reject high-confidence wrong-document PDFs before they reach storage.

    A URL on the requested DOI publisher's known host, or one containing that
    DOI, retains fail-open behavior because its source confirms identity. Other
    text-rich PDFs must confirm the available requested title or DOI; image-only
    and sparse-OCR scans remain eligible. Title-discovered alternates pass
    ``strict=True`` and must contain a requested/alternate DOI or an exact
    normalized title plus enough verified author names in the first five
    extracted pages; inconclusive evidence is rejected.
    """
    if not is_pdf_bytes(data) or pdf_page_count(data) == 0:
        return PdfIdentityVerdict(False, "not a parseable PDF", "high")
    if not pdf_has_visible_content(data):
        return PdfIdentityVerdict(False, "PDF is blank or has no renderable page content", "high")
    if source_url and is_non_article_pdf_url(source_url):
        return PdfIdentityVerdict(
            False, "URL identifies issue/front matter rather than an article", "high"
        )
    if source_url and is_supplement_url(source_url):
        return PdfIdentityVerdict(
            False, "URL identifies supplementary material, not the article", "high"
        )

    text = extract_text(data, max_pages=5 if strict else 3)
    if len(text.strip()) <= 4_000 and _ERROR_DOCUMENT_RE.search(text[:2_000]):
        return PdfIdentityVerdict(
            False, "PDF contains a publisher error page, not an article", "high"
        )
    text = _REFERENCE_HEADING_RE.split(text, maxsplit=1)[0]
    doi_values = tuple(dict.fromkeys(
        value for value in ((expected_doi or ""), *accepted_dois) if value
    ))
    expected_doi_values = tuple(_canonical_doi(value) for value in doi_values)
    found_dois = _dois_in_text(text, expected_doi_values)
    doi_matches = [value in found_dois for value in expected_doi_values]
    for index, matched in enumerate(doi_matches):
        if matched:
            detail = ("requested DOI found in PDF" if index == 0
                      else "verified alternate DOI found in PDF")
            return PdfIdentityVerdict(True, detail, "high")

    if strict:
        normalized_title = normalize_identity(expected_title)
        normalized_text = normalize_identity(text)
        if not normalized_title or normalized_title not in normalized_text:
            return PdfIdentityVerdict(
                False, "strict identity: exact paper title not found in PDF", "high"
            )
        matched_authors, author_count = strict_pdf_author_matches(
            text, expected_authors
        )
        if author_count == 0:
            return PdfIdentityVerdict(
                False, "strict identity: verified author evidence is missing", "high"
            )
        required_authors = (
            required_author_matches
            if isinstance(required_author_matches, int)
            and not isinstance(required_author_matches, bool)
            and 1 <= required_author_matches <= author_count
            else math.ceil(0.6 * author_count)
        )
        if matched_authors < required_authors:
            return PdfIdentityVerdict(
                False,
                "strict identity: author evidence below threshold "
                f"({matched_authors}/{author_count}, need {required_authors})",
                "high",
            )
        return PdfIdentityVerdict(
            True,
            "exact paper title and verified authors found in PDF "
            f"({matched_authors}/{author_count})",
            "high",
        )

    wanted_tokens = _title_tokens(expected_title or "")
    found_tokens = _title_tokens(text)
    if wanted_tokens:
        overlap = len(wanted_tokens & found_tokens) / len(wanted_tokens)
        if overlap >= 0.65 and len(wanted_tokens & found_tokens) >= 3:
            return PdfIdentityVerdict(True, "paper title matches PDF text", "high")

    # Require two issue-level signals to avoid rejecting an ordinary article
    # that merely mentions an editorial board or contents in its prose.
    issue_markers = len(set(
        marker.casefold() for marker in _ISSUE_MATTER_TEXT_RE.findall(text[:12_000])
    ))
    if issue_markers >= 2 and (not wanted_tokens or len(wanted_tokens & found_tokens) < 3):
        return PdfIdentityVerdict(
            False, "PDF text is journal issue matter, not a primary article", "high"
        )

    if (expected_doi and found_dois
            and (not wanted_tokens or len(wanted_tokens & found_tokens) < 3)):
        return PdfIdentityVerdict(
            False, "PDF contains a different DOI and does not match the paper title", "high"
        )
    if (wanted_tokens
            and len(re.findall(r"\w+", text, re.UNICODE))
            >= _MIN_SUBSTANTIAL_TEXT_WORDS
            and not _source_url_supports_expected_doi(expected_doi, source_url)):
        return PdfIdentityVerdict(
            False,
            "PDF from an unverified source has substantial text but does not "
            "confirm the requested DOI or title",
            "inconclusive",
        )
    return PdfIdentityVerdict(
        True, "no conflicting primary-paper identity evidence", "inconclusive"
    )
