"""Local library: keep a copy of every requested paper + metadata + an index."""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .config import ServiceConfig
from .models import DownloadResult, Identifier, IdentifierKind
from .pdfutil import looks_like_html, validate_pdf_identity


class LibraryStore:
    def __init__(self, config: ServiceConfig):
        self.cfg = config
        self.root = config.storage_path
        self.root.mkdir(parents=True, exist_ok=True)
        self.index_path = self.root / "index.jsonl"
        self._index_lock = threading.Lock()

    # -- atomic write helpers ------------------------------------------------
    @staticmethod
    def _atomic_write_bytes(path: Path, data: bytes) -> None:
        """Write durably: a temp file in the same dir, fsync, then an atomic
        os.replace. A crash / Ctrl-C / disk-full mid-write can never leave a
        half-written file at ``path`` — which a later run would otherwise treat as
        a completed cached download (the truncated-PDF cache-poisoning bug)."""
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f".{path.name}.tmp-{os.getpid()}")
        try:
            with open(tmp, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)        # atomic on the same volume (incl. Windows)
        finally:
            try:
                if tmp.exists():
                    tmp.unlink()
            except OSError:
                pass

    @classmethod
    def _atomic_write_text(cls, path: Path, text: str) -> None:
        cls._atomic_write_bytes(path, text.encode("utf-8"))

    def item_dir(self, ident: Identifier) -> Path:
        d = self.root / ident.slug
        if not d.exists():
            legacy = self.root / ident.legacy_slug
            if self._legacy_dir_matches(legacy, ident):
                d = legacy
        d.mkdir(parents=True, exist_ok=True)
        return d

    @staticmethod
    def _legacy_dir_matches(path: Path, ident: Identifier) -> bool:
        """Use an old unhashed directory only when metadata proves its identity."""
        try:
            data = json.loads((path / "metadata.json").read_text(encoding="utf-8"))
            stored = data.get("identifier") or {}
            return (stored.get("kind") == ident.kind.value
                    and stored.get("value") == ident.value)
        except (OSError, ValueError, TypeError):
            return False

    def original_path(self, ident: Identifier) -> Path:
        return self.item_dir(ident) / "original.pdf"


    def has_original(self, ident: Identifier) -> bool:
        """Revalidate parseability, visible content and identity before reuse.

        This also rejects invalid files admitted by earlier downloader versions,
        so an old successful metadata record cannot permanently hide a retry.
        """
        p = self.original_path(ident)
        try:
            if not (p.exists() and p.stat().st_size > 1024):
                return False
            with p.open("rb") as f:
                head = f.read(1024)
        except OSError:
            return False
        if head.lstrip()[:5] != b"%PDF-":
            return False
        try:
            metadata = self.read_metadata(ident)
            return validate_pdf_identity(
                p.read_bytes(),
                expected_doi=ident.value if ident.kind == IdentifierKind.DOI else None,
                expected_title=metadata.title if metadata else None,
                source_url=metadata.pdf_url if metadata else None,
                accepted_dois=(
                    (metadata.discovery.matched_doi,)
                    if metadata and metadata.discovery.matched_doi else ()
                ),
            ).accepted
        except OSError:
            return False

    def fulltext_path(self, ident: Identifier) -> Path:
        return self.item_dir(ident) / "fulltext.html"

    def has_html(self, ident: Identifier) -> bool:
        p = self.fulltext_path(ident)
        try:
            if not (p.exists() and p.stat().st_size > 0):
                return False
            return looks_like_html(p.read_bytes()[:2048])
        except OSError:
            return False

    # -- writes --------------------------------------------------------------
    def save_pdf(self, ident: Identifier, original: bytes) -> Path:
        """Save the downloaded PDF unchanged using an atomic replacement."""
        path = self.original_path(ident)
        self._atomic_write_bytes(path, original)
        return path

    def save_html(self, ident: Identifier, html: bytes) -> Path:
        d = self.item_dir(ident)
        p = d / "fulltext.html"
        self._atomic_write_bytes(p, html)
        return p

    def write_metadata(self, result: DownloadResult) -> Path:
        d = self.item_dir(result.identifier)
        p = d / "metadata.json"
        self._atomic_write_text(p, json.dumps(result.to_dict(), indent=2, ensure_ascii=False))
        return p

    def read_metadata(self, ident: Identifier) -> Optional[DownloadResult]:
        p = self.item_dir(ident) / "metadata.json"
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            result = DownloadResult.from_dict(data)
        except (OSError, ValueError, TypeError):
            return None
        if (result.identifier.kind != ident.kind
                or result.identifier.value != ident.value):
            return None
        result.identifier = ident
        return result

    def append_index(self, result: DownloadResult) -> None:
        # One definition of an index row lives on the model (DownloadResult.index_row)
        # so it cannot drift from metadata.json; storage only adds the timestamp.
        rec = {"ts": datetime.now(timezone.utc).isoformat(), **result.index_row()}
        line = json.dumps(rec, ensure_ascii=False) + "\n"
        # Serialize appends so the manual-assist retry (a second engine against the
        # same store) can't interleave a half-written JSON line.
        with self._index_lock:
            with self.index_path.open("a", encoding="utf-8") as f:
                f.write(line)
