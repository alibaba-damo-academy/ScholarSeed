"""Durable, privacy-safe memory for institutional publisher access gates."""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Optional


MEMORY_FILENAME = "institution-access-memory.json"
MEMORY_VERSION = 1
NEEDS_LOGIN = "needs_login"
NO_ACCESS = "no_access"
AUTHENTICATED = "authenticated"
_VALID_STATES = {NEEDS_LOGIN, NO_ACCESS, AUTHENTICATED}
_GATE_STATES = {NEEDS_LOGIN, NO_ACCESS}
_SAFE_PLATFORM_RE = re.compile(r"^[a-z0-9][a-z0-9._:-]{0,254}$")
_SAFE_KEY_RE = re.compile(
    r"^(?:doi-prefix|publisher|host):[a-z0-9][a-z0-9._-]{0,254}$"
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_platform(value: object) -> Optional[str]:
    platform = str(value or "").strip().lower()
    if not _SAFE_PLATFORM_RE.fullmatch(platform):
        return None
    return platform


def _safe_keys(values: Iterable[object]) -> set[str]:
    return {
        key
        for value in values
        if (key := str(value or "").strip().lower())
        and _SAFE_KEY_RE.fullmatch(key)
    }


@dataclass
class InstitutionAccessRecord:
    platform: str
    state: str = NEEDS_LOGIN
    match_keys: set[str] = field(default_factory=set)
    first_seen_at: str = field(default_factory=_now)
    last_seen_at: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        return {
            "platform": self.platform,
            "state": self.state,
            "match_keys": sorted(self.match_keys),
            "first_seen_at": self.first_seen_at,
            "last_seen_at": self.last_seen_at,
        }


class InstitutionAccessMemory:
    """Read and atomically update safe gates beside an output directory.

    The file intentionally contains no URLs, cookies, credentials, identity-provider
    details, or paper identifiers. Only normalized platform labels and match keys
    that paper-dl itself generated are accepted when loading it.
    """

    def __init__(self, path: Path, *, logger: Optional[Callable[[str], None]] = None):
        self.path = path
        self.log = logger or (lambda _: None)
        self.records: dict[str, InstitutionAccessRecord] = {}
        # Kept as one stable dict object so callers can inspect it in diagnostics.
        self.key_to_platform: dict[str, str] = {}
        self._loaded_once = False
        self._loaded_signature: Optional[tuple[int, int, int]] = None

    def _file_signature(self) -> Optional[tuple[int, int, int]]:
        """Cheap identity for change detection across atomic process writes."""
        try:
            stat = self.path.stat()
        except FileNotFoundError:
            return None
        except OSError:
            # Force a real load so its existing best-effort diagnostics handle
            # the unusual filesystem error instead of silently using stale data.
            return None
        return stat.st_mtime_ns, stat.st_size, stat.st_ino

    def load_if_changed(self) -> bool:
        """Reload only when another process changed or removed the memory file.

        Returns ``True`` when a real load was performed. The per-paper parent and
        worker synchronization paths call this frequently; an unchanged file now
        costs one stat rather than a JSON read plus a repeated user-facing log.
        """
        signature = self._file_signature()
        if self._loaded_once and signature == self._loaded_signature:
            return False
        self.load()
        return True

    def load(self) -> None:
        observed_signature = self._file_signature()
        self.records.clear()
        self.key_to_platform.clear()
        try:
            if observed_signature is None and not self.path.exists():
                return
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            if payload.get("version") != MEMORY_VERSION:
                raise ValueError("unsupported memory-file version")
            entries = payload.get("platforms")
            if not isinstance(entries, list):
                raise ValueError("platforms must be a list")
            for raw in entries:
                if not isinstance(raw, dict):
                    continue
                platform = _safe_platform(raw.get("platform"))
                state = raw.get("state")
                keys = _safe_keys(raw.get("match_keys") or [])
                if not platform or state not in _VALID_STATES or not keys:
                    continue
                record = InstitutionAccessRecord(
                    platform=platform,
                    state=state,
                    match_keys=keys,
                    first_seen_at=str(raw.get("first_seen_at") or _now()),
                    last_seen_at=str(raw.get("last_seen_at") or _now()),
                )
                self.records[platform] = record
            self._rebuild_key_index()
            if self.records:
                self.log(
                    f"  [institution-login] loaded {len(self.records)} remembered "
                    f"platform(s) from {self.path}"
                )
        except Exception as exc:  # noqa: BLE001 - corrupt memory must not stop a batch
            self.records.clear()
            self.key_to_platform.clear()
            self.log(
                f"  [institution-login] ignoring unreadable access memory "
                f"{self.path}: {type(exc).__name__}: {exc}"
            )
        finally:
            # Retain the signature observed before reading. If an atomic replace
            # raced the read, the next load_if_changed sees the new inode/mtime
            # and refreshes again rather than accepting stale state indefinitely.
            self._loaded_signature = observed_signature
            self._loaded_once = True

    def find(self, match_keys: Iterable[str]) -> Optional[InstitutionAccessRecord]:
        for key in sorted(_safe_keys(match_keys)):
            platform = self.key_to_platform.get(key)
            if platform and platform in self.records:
                return self.records[platform]
        return None

    def find_gate(self, match_keys: Iterable[str]) -> Optional[InstitutionAccessRecord]:
        """Return only states that should suppress or defer publisher attempts."""
        for key in sorted(_safe_keys(match_keys)):
            platform = self.key_to_platform.get(key)
            record = self.records.get(platform or "")
            if record is not None and record.state in _GATE_STATES:
                return record
        return None

    def remember(
        self,
        platform: str,
        match_keys: Iterable[str],
        *,
        state: str = NEEDS_LOGIN,
        force_state: bool = False,
    ) -> InstitutionAccessRecord:
        safe_platform = _safe_platform(platform)
        keys = _safe_keys(match_keys)
        if not safe_platform or not keys or state not in _VALID_STATES:
            raise ValueError("unsafe or incomplete institutional-access memory record")

        now = _now()
        record = self.records.get(safe_platform)
        if record is None:
            record = InstitutionAccessRecord(
                platform=safe_platform,
                state=state,
                match_keys=set(),
                first_seen_at=now,
                last_seen_at=now,
            )
            self.records[safe_platform] = record

        # A generic login gate must not overwrite an explicit no-access decision.
        # Direct warm-up feedback passes force_state=True so a later confirmed
        # entitlement can intentionally replace stale negative memory.
        if force_state or record.state != NO_ACCESS or state == NO_ACCESS:
            record.state = state
        record.last_seen_at = now

        # A match key belongs to one platform. If a more precise hostname replaces
        # an older resolver label, merge the records without ever downgrading an
        # explicit no-access decision.
        old_platforms = {
            old_platform
            for key in keys
            if (old_platform := self.key_to_platform.get(key))
            and old_platform != safe_platform
        }
        for old_platform in sorted(old_platforms):
            old = self.records.pop(old_platform, None)
            if old is None:
                continue
            record.match_keys.update(old.match_keys)
            if old.state == NO_ACCESS and not force_state:
                record.state = NO_ACCESS
            record.first_seen_at = min(record.first_seen_at, old.first_seen_at)
        record.match_keys.update(keys)

        self._drop_empty_records()
        self._rebuild_key_index()
        self._save_best_effort()
        return record

    def mark_no_access(self, platform: str) -> Optional[InstitutionAccessRecord]:
        safe_platform = _safe_platform(platform)
        record = self.records.get(safe_platform or "")
        if record is None:
            return None
        record.state = NO_ACCESS
        record.last_seen_at = _now()
        self._save_best_effort()
        return record

    def mark_authenticated(self, platform: str) -> Optional[InstitutionAccessRecord]:
        """Remember successful access without treating it as a future gate."""
        safe_platform = _safe_platform(platform)
        record = self.records.get(safe_platform or "")
        if record is None:
            return None
        record.state = AUTHENTICATED
        record.last_seen_at = _now()
        self._save_best_effort()
        return record

    def clear(self, platform: str) -> None:
        safe_platform = _safe_platform(platform)
        if not safe_platform:
            return
        self.records.pop(safe_platform, None)
        for key, mapped in list(self.key_to_platform.items()):
            if mapped == safe_platform:
                del self.key_to_platform[key]
        self._save_best_effort()

    def _drop_empty_records(self) -> None:
        for platform, record in list(self.records.items()):
            if not record.match_keys:
                del self.records[platform]

    def _rebuild_key_index(self) -> None:
        self.key_to_platform.clear()
        for platform in sorted(self.records):
            for key in sorted(self.records[platform].match_keys):
                self.key_to_platform[key] = platform

    def _save_best_effort(self) -> None:
        payload = {
            "version": MEMORY_VERSION,
            "updated_at": _now(),
            "platforms": [
                self.records[platform].to_dict()
                for platform in sorted(self.records)
            ],
        }
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            text = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
            tmp = self.path.with_name(f".{self.path.name}.tmp-{os.getpid()}")
            try:
                with tmp.open("w", encoding="utf-8") as handle:
                    handle.write(text)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(tmp, self.path)
                self._loaded_signature = self._file_signature()
                self._loaded_once = True
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except OSError:
                    pass
        except Exception as exc:  # noqa: BLE001 - downloads must continue in memory
            self.log(
                f"  [institution-login] could not persist access memory "
                f"{self.path}: {type(exc).__name__}: {exc}"
            )
