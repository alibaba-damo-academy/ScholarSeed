"""Pure failure classification — map the evidence gathered across a download's
attempts to a precise, user-facing ``(UnableReason, message)``.

Extracted from :class:`~paper_dl.service.PaperDownloadService` so this — the
tool's single most user-visible decision, and the guidance that tells the user to
re-run with an interactive browser session or institutional access — can be unit-tested without
driving a live browser. The strings and the precedence are load-bearing; change
them deliberately (``tests/test_classify.py`` pins them with golden assertions).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .models import UnableReason


@dataclass(frozen=True)
class Evidence:
    """Signals accumulated while trying one identifier's candidates."""

    blocked: bool = False                 # a bot challenge / captcha did not clear
    needs_manual: bool = False            # a bot challenge/captcha remains unresolved
    unattended: bool = False              # the run deliberately cannot wait for a human
    needs_login: bool = False             # explicit institutional SSO/login gate
    login_skipped: bool = False           # login-gated paper was skipped automatically
    paywalled: bool = False               # a landing page looked paywalled
    found_control: bool = False           # clicked a PDF/download control
    found_link: bool = False              # located a concrete PDF URL but got no file
    viewer_opened: bool = False           # Chrome visibly rendered it; capture failed
    not_found: bool = False               # the identifier resolves to no paper (404 / "DOI Not Found")
    url_error_detail: Optional[str] = None  # terminal landing/network/static-error diagnosis
    access_denied: bool = False           # the publisher refused access (HTTP 403/401, not a bot wall)
    known_open_access: bool = False       # an OA source positively identified this paper
    timed_out: bool = False               # retained for legacy/cooperative callers
    only_http: bool = False               # every attempt used the plain-HTTP path
    browser_error: Optional[str] = None   # the browser engine was unavailable
    timeout_s: float = 0                  # the per-item hard cap, for the message
    identity_mismatch_detail: Optional[str] = None


def classify_failure(ev: Evidence) -> tuple[UnableReason, str]:
    """Classify a failed download honestly (least-ambiguous signal wins)."""
    browser_note = ev.browser_error
    if ev.identity_mismatch_detail:
        reason = UnableReason.IDENTITY_MISMATCH
        message = ev.identity_mismatch_detail
    elif ev.needs_manual:
        reason = UnableReason.NEEDS_MANUAL
        if ev.unattended:
            message = ("A bot challenge / captcha needs a human to solve it — skipped in "
                       "unattended (--autodev) mode. Re-run without --autodev, connect "
                       "to a visible Chrome with --connect-cdp, and complete verification "
                       "in the browser window. If YAML sets autodev: true, disable it too.")
        else:
            message = (
                "A bot challenge / captcha was still present after the interactive "
                "solve window, or reappeared while opening the PDF. This was an "
                "interactive run, not an unattended (--autodev) skip. Retry this "
                "paper in the same debugging Chrome session and also solve any "
                "challenge that appears on the PDF tab."
            )
    elif ev.url_error_detail:
        reason = UnableReason.URL_ERROR
        detail = ev.url_error_detail.strip()
        message = (detail if detail.lower().startswith("url error")
                   else f"URL error: {detail}")
    elif ev.browser_error and ev.only_http:
        reason = UnableReason.DOWNLOAD_FAILED
        message = f"HTTP attempts failed and browser engine unavailable: {ev.browser_error}"
        browser_note = None  # already included in the main diagnosis
    elif ev.blocked:
        reason = UnableReason.BLOCKED
        message = ("A bot challenge (Cloudflare/captcha) did not clear. Re-run with "
                   "--connect-cdp using a visible Chrome, complete verification, and retry.")
    elif ev.needs_login:
        reason = UnableReason.NEEDS_LOGIN
        if ev.login_skipped:
            message = ("Institutional login is required for this publisher; this paper "
                       "was skipped automatically.")
        else:
            message = ("Institutional login is required before this publisher will provide "
                       "the PDF. Open it in the same browser profile, complete SSO, and retry.")
    elif ev.viewer_opened:
        reason = UnableReason.DOWNLOAD_FAILED
        message = (
            "The PDF opened in the debugging Chrome, but the downloader could not "
            "capture and save its bytes. Access was successful; this is a browser "
            "viewer capture failure, not evidence that entitlement is missing."
        )
    elif ev.found_link:
        reason = UnableReason.DOWNLOAD_FAILED
        if ev.known_open_access:
            message = (
                "This paper is reported open access and a PDF link was found, but "
                "the publisher did not deliver PDF bytes. This is a download or "
                "bot-protection failure, not evidence that the institute lacks "
                "access. Retry with the same browser session via --connect-cdp."
            )
        else:
            message = (
                "Located a concrete PDF URL, but the browser session did not "
                "capture PDF bytes. This is a download failure; it is not by "
                "itself evidence that login or entitlement is missing."
            )
    elif ev.found_control:
        reason = UnableReason.DOWNLOAD_FAILED
        message = (
            "A PDF/download control was found, but it did not expose a direct PDF "
            "URL or yield PDF bytes. This is a download-flow failure; it is not "
            "evidence that login or entitlement is missing."
        )
    elif ev.not_found:
        reason = UnableReason.NOT_FOUND
        message = ("The identifier does not resolve to a paper — the DOI resolver or "
                   "publisher reports it does not exist (404 / 'DOI Not Found'). "
                   "Double-check the DOI / URL for a typo.")
    elif ev.access_denied:
        if ev.known_open_access:
            reason = UnableReason.DOWNLOAD_FAILED
            message = (
                "This paper is reported open access, but its OA endpoint returned "
                "HTTP 403/401. This is a publisher delivery or bot-protection "
                "failure, not evidence that the institute lacks access."
            )
        else:
            reason = UnableReason.PAYWALL
            message = ("Access denied (HTTP 403/401) and no open-access copy was found. "
                       "Check access in your browser and use your institution's network, "
                       "VPN, or login if required. Then retry with --connect-cdp.")
    elif ev.paywalled:
        reason = UnableReason.PAYWALL
        message = ("Access denied / paywalled and no open-access copy was found. "
                   "Run on the campus VPN (or with an institutional profile) and retry.")
    elif ev.timed_out:
        reason = UnableReason.TIMEOUT
        message = (f"Hard per-paper time limit ({ev.timeout_s:g}s) reached. "
                   "Increase --paper-timeout or per_request_timeout_s if this "
                   "paper needs more time.")
    else:
        reason = UnableReason.NO_PDF_LINK
        message = "Could not locate a PDF link or button on the source."
    if browser_note:
        message += f" (browser note: {browser_note})"
    return reason, message
