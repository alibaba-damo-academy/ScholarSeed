"""Human-readable download results."""

from rich.console import Console
from rich.table import Table
from rich.text import Text

from .models import BatchReport
from .sanitize import sanitize_text


def plain_lines(report: BatchReport) -> list[str]:
    lines = []
    for index, result in enumerate(report.results, 1):
        identifier = sanitize_text(result.identifier.value or result.identifier.original)
        reason = f" ({result.reason.value})" if result.reason else ""
        lines.append(f"{index}. {result.status.value}{reason}: {identifier}")
        lines.append(f"   {sanitize_text(result.message)}")
        if result.ok and result.original_path:
            lines.append(f"   -> {result.original_path}")
    return lines


def render(report: BatchReport, console: Console | None = None) -> None:
    console = console or Console()
    table = Table("#", "Identifier", "Status", "Result")
    for index, result in enumerate(report.results, 1):
        detail = sanitize_text(result.message)
        if result.ok and result.original_path:
            detail += f"\n{result.original_path}"
        table.add_row(
            str(index),
            Text(sanitize_text(result.identifier.value or result.identifier.original)),
            result.status.value,
            Text(detail),
        )
    console.print(table)
    console.print(
        f"Total {report.n_total} | downloaded {report.n_success} | "
        f"cached {report.n_cached} | unable {report.n_unable}"
    )


def summary_markdown(report: BatchReport) -> str:
    lines = [
        "# Download results", "",
        f"Total: {report.n_total}; downloaded: {report.n_success}; "
        f"cached: {report.n_cached}; unable: {report.n_unable}.", "",
    ]
    lines.extend(plain_lines(report))
    return "\n".join(lines) + "\n"
