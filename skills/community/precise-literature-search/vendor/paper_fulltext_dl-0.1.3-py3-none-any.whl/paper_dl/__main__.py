"""Download papers from command-line identifiers or a text list."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer

from .cli_runtime import _run_cli


for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


app = typer.Typer(
    add_completion=False,
    help="Download academic papers to local storage.",
)


@app.command()
def main(
    identifiers: list[str] = typer.Argument(None, help="DOIs / arXiv ids / URLs"),
    input_file: Optional[Path] = typer.Option(None, "--input", "-i", help="File with one identifier per line; blank lines and '#' comments (full-line or inline) are ignored"),
    config: Optional[Path] = typer.Option(None, "--config", "-c", help="YAML config file"),
    storage: Optional[str] = typer.Option(None, "--storage", help="Library directory for kept copies"),
    out: Optional[str] = typer.Option(None, "--out", help="Output directory for report.json"),
    email: Optional[str] = typer.Option(None, "--email", help="Email for Unpaywall OA discovery"),
    profile: Optional[str] = typer.Option(None, "--profile", help="Persistent browser profile dir (institutional login)"),
    proxy: Optional[str] = typer.Option(None, "--proxy", help="HTTP proxy server"),
    ezproxy_host: Optional[str] = typer.Option(None, "--ezproxy-host", help="e.g. ezproxy.lib.example.edu"),
    channel: Optional[str] = typer.Option(None, "--channel", help="Real browser channel: chrome | msedge"),
    headless: Optional[bool] = typer.Option(None, "--headless/--no-headless", help="Run the browser headless (default: per config; visible under --max-stealth)"),
    max_stealth: bool = typer.Option(False, "--max-stealth", help="Launch installed Chrome in a visible window with a persistent profile"),
    connect_cdp: Optional[str] = typer.Option(None, "--connect-cdp", help="Attach to an already-running Chrome via its local DevTools endpoint"),
    keep_open: bool = typer.Option(False, "--keep-open", help="Keep the browser available for inspection/retry until you press Enter"),
    overwrite: Optional[bool] = typer.Option(None, "--overwrite", help="Refetch even if already in the library"),
    prefer_oa: Optional[bool] = typer.Option(None, "--prefer-oa/--prefer-published", help="Prefer verified OA copies (default), or the publisher version"),
    translators_dir: Optional[Path] = typer.Option(None, "--translators-dir", help="Enable user-installed translators from a converted adapter directory (off by default)"),
    no_translators: bool = typer.Option(False, "--no-translators", help="Skip translators, overriding browser.translators_dir in YAML; independent of Zotero Desktop"),
    zotero_save: bool = typer.Option(False, "--zotero-save", help="Enable Zotero Desktop/Connector fallback after normal download strategies fail"),
    no_zotero: bool = typer.Option(False, "--no-zotero", help="Disable a Zotero fallback enabled by YAML"),
    zotero_collection_key: Optional[str] = typer.Option(None, "--zotero-collection-key", help="Target Zotero collection key"),
    zotero_storage_dir: Optional[str] = typer.Option(None, "--zotero-storage-dir", help="Path to Zotero's storage directory"),
    autodev: bool = typer.Option(False, "--autodev", help="Unattended batch download: skip human challenges and shorten waits"),
    paper_timeout: Optional[float] = typer.Option(None, "--paper-timeout", min=0.001, help="Hard wall-clock limit in seconds for each paper"),
):
    """Download one or more papers."""
    return _run_cli(
        identifiers=identifiers,
        input_file=input_file,
        config=config,
        storage=storage,
        out=out,
        email=email,
        profile=profile,
        proxy=proxy,
        ezproxy_host=ezproxy_host,
        channel=channel,
        headless=headless,
        max_stealth=max_stealth,
        connect_cdp=connect_cdp,
        keep_open=keep_open,
        overwrite=overwrite,
        prefer_oa=prefer_oa,
        translators_dir=translators_dir,
        no_translators=no_translators,
        zotero_save=zotero_save,
        no_zotero=no_zotero,
        zotero_collection_key=zotero_collection_key,
        zotero_storage_dir=zotero_storage_dir,
        autodev=autodev,
        paper_timeout=paper_timeout,
    )


if __name__ == "__main__":
    app()
