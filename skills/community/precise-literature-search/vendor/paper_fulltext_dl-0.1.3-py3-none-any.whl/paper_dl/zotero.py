"""Zotero Connector integration — save papers via the browser extension.

When standard PDF download methods fail (e.g. ScienceDirect entitlement walls),
this module triggers the Zotero Connector browser extension to capture the paper.
The Connector uses the browser's full session/cookies and its built-in publisher
translators to download PDFs that paper-dl's own fetch methods cannot reach.

Flow
----
1. The browser engine has already navigated to the article landing page.
2. We trigger the Zotero Connector via a keyboard shortcut (Cmd+Shift+S on macOS).
3. The Connector extension recognizes the page, runs its translator, and tells
   Zotero desktop to download the PDF using the browser's session cookies.
4. We poll Zotero's local API until the new item (matched by DOI) appears.
5. We locate the PDF attachment in Zotero's storage directory.
6. The PDF bytes are returned to the service layer for validation and local storage.
"""

from __future__ import annotations

import json
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import httpx

from .config import ZoteroConfig
from .deadline import clamp_seconds, sleep as deadline_sleep
from .models import ZoteroResult
from .pdfutil import is_pdf_bytes


class ZoteroError(Exception):
    """Any Zotero API communication failure."""


@dataclass
class CollectionInfo:
    key: str
    name: str
    num_items: int = 0
    num_collections: int = 0


def _default_storage_dir() -> Path:
    """Best-effort default Zotero data directory for the current platform."""
    if sys.platform == "darwin":
        return Path.home() / "Zotero" / "storage"
    elif sys.platform.startswith("linux"):
        return Path.home() / "Zotero" / "storage"
    else:
        # Windows
        return Path.home() / "Zotero" / "storage"


class ZoteroConnector:
    """Client for Zotero's local HTTP API (127.0.0.1:23119).

    Used both to verify Zotero is running and to poll for newly saved items
    after triggering the Connector extension via a keyboard shortcut.
    """

    def __init__(self, cfg: Optional[ZoteroConfig] = None, *, logger=None):
        self.cfg = cfg or ZoteroConfig()
        self.base_url = self.cfg.base_url.rstrip("/")
        self.log = logger or (lambda *a, **k: None)
        self._client = httpx.Client(timeout=10.0)
        self._storage_dir: Optional[Path] = None

    def __enter__(self) -> "ZoteroConnector":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:
            pass

    @property
    def storage_dir(self) -> Path:
        """Resolved Zotero storage directory."""
        if self._storage_dir is None:
            if self.cfg.storage_dir:
                self._storage_dir = Path(self.cfg.storage_dir).expanduser().resolve()
            else:
                self._storage_dir = _default_storage_dir()
        return self._storage_dir

    # -- connectivity --------------------------------------------------------

    def is_running(self) -> bool:
        """Check whether Zotero desktop is reachable."""
        try:
            r = self._client.get(f"{self.base_url}/connector/ping")
            return r.status_code == 200
        except Exception:
            return False

    def ensure_running(self) -> bool:
        """Verify Zotero is reachable; log a helpful message if not."""
        if self.is_running():
            return True
        self.log("    [zotero] Zotero is not running or unreachable at "
                 f"{self.base_url}. Ensure Zotero is open and the local API is "
                 "enabled (Settings -> Advanced -> Allow other applications).")
        return False

    # -- collections ---------------------------------------------------------

    def list_collections(self) -> list[CollectionInfo]:
        """List all top-level collections in the user's library."""
        r = self._client.get(f"{self.base_url}/api/users/0/collections")
        if r.status_code == 403:
            raise ZoteroError(
                "Zotero local API is not enabled. Go to Zotero Settings -> "
                "Advanced -> check 'Allow other applications on this computer "
                "to communicate with Zotero'."
            )
        r.raise_for_status()
        out: list[CollectionInfo] = []
        for item in r.json():
            data = item.get("data", {})
            meta = item.get("meta", {})
            out.append(CollectionInfo(
                key=data.get("key", ""),
                name=data.get("name", ""),
                num_items=meta.get("numItems", 0),
                num_collections=meta.get("numCollections", 0),
            ))
        return out

    def validate_collection_key(self, key: str) -> bool:
        """Check that a collection key exists."""
        try:
            cols = self.list_collections()
        except Exception:
            return False
        return any(c.key == key for c in cols)

    def create_collection(self, name: str) -> CollectionInfo:
        """Create an empty top-level collection through Zotero Connector.

        Zotero's local ``/api`` endpoints are read-only.  The Connector import
        endpoint is writable, however, and its bundled BibTeX translator
        supports JabRef collection metadata.  Importing a collection-only
        payload creates the collection without adding a placeholder item.
        """
        normalized = name.strip()
        if not normalized:
            raise ZoteroError("Collection name cannot be empty")
        if len(normalized) > 255:
            raise ZoteroError("Collection name must be 255 characters or fewer")
        if any(ord(char) < 32 for char in normalized) or any(
            char in "{}" for char in normalized
        ):
            raise ZoteroError("Collection name cannot contain control characters or braces")

        before = self.list_collections()
        if any(collection.name.casefold() == normalized.casefold() for collection in before):
            raise ZoteroError(f'A Zotero collection named "{normalized}" already exists')

        def jabref_escape(value: str) -> str:
            return value.replace("\\", "\\\\").replace(";", "\\;")

        # JabRef group records are parsed twice: once into records, then into
        # fields. Escape at both levels so punctuation in the name survives.
        record = f"1 ExplicitGroup:{jabref_escape(normalized)};0;"
        encoded_record = jabref_escape(record)
        payload = (
            "@comment{jabref-meta: groupsversion:3;}\n"
            f"@comment{{jabref-meta: groupstree:0 AllEntriesGroup:;{encoded_record};}}\n"
        )
        response = self._client.post(
            f"{self.base_url}/connector/import",
            params={"session": f"paper-dl-{uuid.uuid4().hex}"},
            content=payload.encode("utf-8"),
            headers={"Content-Type": "application/x-bibtex; charset=utf-8"},
        )
        if response.status_code == 403:
            raise ZoteroError(
                "Zotero Connector access is disabled. In Zotero Settings -> "
                "Advanced, enable communication with other applications."
            )
        if response.status_code != 201:
            detail = response.text.strip()
            suffix = f": {detail}" if detail else ""
            raise ZoteroError(
                f"Zotero could not create the collection (HTTP {response.status_code}){suffix}"
            )

        previous_keys = {collection.key for collection in before}
        for collection in self.list_collections():
            if collection.key not in previous_keys and collection.name == normalized:
                return collection
        raise ZoteroError(
            "Zotero accepted the collection import, but the new collection was not found"
        )

    # -- item queries --------------------------------------------------------

    def get_library_version(self) -> int:
        """Get the current library version number (monotonically increasing)."""
        try:
            r = self._client.get(f"{self.base_url}/api/users/0/items",
                                 params={"limit": 1, "format": "json"})
            # The library version is in the Last-Modified-Version header.
            return int(r.headers.get("Last-Modified-Version", "0"))
        except Exception:
            return 0

    def find_item_by_doi(self, doi: str) -> Optional[dict]:
        """Search for an item by DOI in the local library."""
        try:
            r = self._client.get(
                f"{self.base_url}/api/users/0/items",
                params={"q": doi, "qmode": "everything", "format": "json",
                        "limit": 10, "sort": "dateAdded", "direction": "desc"},
            )
            r.raise_for_status()
            items = r.json()
            for item in items:
                data = item.get("data", {})
                if data.get("DOI", "").lower() == doi.lower():
                    return item
                # Also check the extra field for DOI
                extra = data.get("extra", "")
                if f"DOI: {doi}" in extra:
                    return item
            return None
        except Exception:
            return None

    def get_item(self, item_key: str) -> Optional[dict]:
        """Fetch a single item by key (includes its current version + collections)."""
        try:
            r = self._client.get(
                f"{self.base_url}/api/users/0/items/{item_key}",
                params={"format": "json"},
            )
            r.raise_for_status()
            return r.json()
        except Exception:
            return None

    def add_item_to_collection(self, item_key: str, collection_key: str,
                               *, move: bool = True) -> bool:
        """Verify an existing item is in ``collection_key``.

        The Zotero local ``/api`` is read-only (PATCH returns HTTP 501), so we
        cannot move items that were NOT saved in a session we own.  For items
        saved via ``save_item_direct`` the collection is set at save-time using
        ``/connector/updateSession``.  This method now only *checks* whether the
        item is already in the target collection (best-effort confirmation).

        Returns True when the item is already in the target collection, False
        otherwise (with an informative log).
        """
        if not item_key or not collection_key:
            return False
        item = self.get_item(item_key)
        if item is None:
            self.log(f"    [zotero] could not fetch item {item_key} to verify collection")
            return False
        data = item.get("data", {})
        current = list(data.get("collections", []) or [])
        if collection_key in current:
            self.log(f"    [zotero] item {item_key} confirmed in collection {collection_key}")
            return True
        # Cannot move via local API (read-only).
        self.log(f"    [zotero] item {item_key} is not in collection {collection_key}; "
                 "the local API is read-only \u2014 item stays where the Connector placed it")
        return False

    def get_item_attachments(self, item_key: str) -> list[dict]:
        """Get child attachments for a parent item."""
        try:
            r = self._client.get(
                f"{self.base_url}/api/users/0/items/{item_key}/children",
                params={"format": "json"},
            )
            r.raise_for_status()
            children = r.json()
            return [c for c in children
                    if c.get("data", {}).get("itemType") == "attachment"]
        except Exception:
            return []

    def get_attachment_pdf_path(self, attachment: dict) -> Optional[Path]:
        """Locate the PDF file on disk for a given attachment item.

        Zotero stores files as: <storage_dir>/<8-char-key>/<filename>
        The attachment data may have:
          - 'path' field like 'storage:<filename>' (imported_file / linked_file)
          - 'filename' field (imported_url mode, used by Connector saves)
        The item 'key' is the directory name under the storage dir.
        """
        data = attachment.get("data", {})
        att_key = data.get("key", "")
        path_field = data.get("path", "")
        filename_field = data.get("filename", "")
        content_type = data.get("contentType", "")

        # Must be a PDF attachment.
        if "application/pdf" not in content_type:
            if not path_field.endswith(".pdf") and not filename_field.endswith(".pdf"):
                return None

        # Determine the filename from either 'path' or 'filename' field.
        filename = ""
        if path_field.startswith("storage:"):
            filename = path_field[len("storage:"):]
        elif path_field:
            filename = path_field
        elif filename_field:
            # imported_url mode (Zotero Connector saves): uses 'filename' directly.
            filename = filename_field

        if not att_key or not filename:
            return None

        pdf_path = self.storage_dir / att_key / filename
        if pdf_path.exists():
            return pdf_path
        return None

    # -- high-level: wait for Zotero to finish saving -----------------------

    def wait_for_item(self, doi: str, *, baseline_version: int = 0,
                      cancel_fn=None) -> Optional[dict]:
        """Poll until a matching item appears in the library.

        Returns the item dict, or None if the timeout is reached.
        """
        budget = clamp_seconds(self.cfg.save_timeout_s)
        deadline = time.time() + budget
        self.log(f"    [zotero] waiting for item with DOI={doi} to appear "
                 f"(timeout={budget:.1f}s)...")
        while time.time() < deadline:
            if cancel_fn is not None and cancel_fn():
                self.log("    [zotero] item wait cancelled (paper skipped)")
                return None
            item = self.find_item_by_doi(doi)
            if item is not None:
                version = item.get("version", (item.get("data") or {}).get("version", 0))
                try:
                    is_new = int(version or 0) > int(baseline_version or 0)
                except (TypeError, ValueError):
                    is_new = baseline_version <= 0
                if baseline_version > 0 and not is_new:
                    deadline_sleep(self.cfg.poll_interval_s)
                    continue
                self.log(f"    [zotero] found item: key={item.get('key', '?')}")
                return item
            deadline_sleep(self.cfg.poll_interval_s)
        self.log("    [zotero] timeout waiting for item to appear")
        return None

    def wait_for_pdf(self, item_key: str, *, timeout_s: Optional[float] = None,
                     cancel_fn=None) -> Optional[Path]:
        """Poll until a PDF attachment appears and the file exists on disk.

        ``timeout_s`` overrides the default ``save_timeout_s`` budget — pass a
        small value (e.g. 2s) for a pre-check of an item that already exists, so
        we don't block the batch waiting for a PDF that is not (and won't be)
        there. Returns the path to the PDF, or None if timeout.
        """
        budget = self.cfg.save_timeout_s if timeout_s is None else timeout_s
        budget = clamp_seconds(budget)
        deadline = time.time() + budget
        # Fast-failure: if Zotero never even registers a PDF *attachment* on the
        # item, the translator did a metadata-only save (gated publisher / no OA
        # copy) and a file will NEVER land. Detecting that early lets the caller
        # fall back to the browser instead of polling the whole budget. Once a
        # PDF attachment IS registered we keep waiting the full budget for its
        # file to finish downloading (a large PDF can be slow).
        grace_deadline = time.time() + min(budget, self.cfg.pdf_grace_s)
        saw_pdf_attachment = False
        self.log(f"    [zotero] waiting for PDF attachment on item {item_key}...")
        while time.time() < deadline:
            if cancel_fn is not None and cancel_fn():
                self.log("    [zotero] PDF wait cancelled (paper skipped)")
                return None
            attachments = self.get_item_attachments(item_key)
            for att in attachments:
                data = att.get("data", {})
                if ("application/pdf" in data.get("contentType", "")
                        or data.get("filename", "").endswith(".pdf")
                        or data.get("path", "").endswith(".pdf")):
                    saw_pdf_attachment = True
                pdf_path = self.get_attachment_pdf_path(att)
                if pdf_path is not None:
                    # Verify the file is complete (non-empty and valid PDF header)
                    try:
                        data_bytes = pdf_path.read_bytes()
                        if is_pdf_bytes(data_bytes) and len(data_bytes) > 1024:
                            self.log(f"    [zotero] PDF found: {pdf_path}")
                            return pdf_path
                    except OSError:
                        pass
            if not saw_pdf_attachment and time.time() >= grace_deadline:
                self.log("    [zotero] no PDF attachment registered within "
                         f"{min(budget, self.cfg.pdf_grace_s):.0f}s (metadata-only "
                         "save) — giving up early")
                return None
            deadline_sleep(self.cfg.poll_interval_s)
        self.log("    [zotero] timeout waiting for PDF attachment")
        return None

    # -- Connector collection filing via updateSession ----------------------

    def _get_connector_targets(self) -> list[dict]:
        """Fetch the Connector's target list (libraries + collections with treeViewIDs).

        Returns a list of ``{"id": "C59", "name": "My Collection", ...}``.
        Cached for the lifetime of this connector instance.
        """
        if hasattr(self, "_targets_cache"):
            return self._targets_cache
        try:
            r = self._client.post(
                f"{self.base_url}/connector/getSelectedCollection",
                json={},
                headers={"Content-Type": "application/json",
                         "X-Zotero-Connector-API-Version": "3"},
            )
            r.raise_for_status()
            self._targets_cache: list[dict] = r.json().get("targets", [])
        except Exception:
            self._targets_cache = []
        return self._targets_cache

    def resolve_collection_target(self, collection_key: str) -> Optional[str]:
        """Map a collection key (e.g. ``4JILE6II``) to a Connector treeViewID (e.g. ``C59``).

        Bridge: list_collections (key→name) + getSelectedCollection (name→treeViewID).
        Returns the treeViewID string or None if it cannot be resolved.
        """
        # Step 1: key → name via local read API.
        try:
            cols = self.list_collections()
        except Exception:
            return None
        name = None
        for c in cols:
            if c.key == collection_key:
                name = c.name
                break
        if name is None:
            self.log(f"    [zotero] collection key {collection_key!r} not found in library")
            return None

        # Step 2: name → treeViewID via Connector targets.
        targets = self._get_connector_targets()
        matches = [t for t in targets if t.get("name") == name
                   and str(t.get("id", "")).startswith("C")]
        if len(matches) == 1:
            return matches[0]["id"]
        if len(matches) > 1:
            self.log(f"    [zotero] ambiguous: {len(matches)} collections named "
                     f"{name!r}; cannot auto-resolve target")
            return None
        self.log(f"    [zotero] could not find treeViewID for collection {name!r}")
        return None

    def file_session_into_collection(self, session_id: str, collection_key: str) -> bool:
        """File items saved in ``session_id`` into ``collection_key`` via updateSession.

        This is the correct write path: ``/connector/updateSession`` sets the
        target collection for the session (the same mechanism the browser
        extension's collection-picker uses).  Must be called after saveItems.
        """
        if not session_id or not collection_key:
            return False
        target = self.resolve_collection_target(collection_key)
        if target is None:
            return False
        try:
            r = self._client.post(
                f"{self.base_url}/connector/updateSession",
                json={"sessionID": session_id, "target": target, "tags": ""},
                headers={"Content-Type": "application/json",
                         "X-Zotero-Connector-API-Version": "3"},
            )
            if r.status_code == 200:
                self.log(f"    [zotero] filed session into collection "
                         f"{collection_key} (target={target})")
                return True
            self.log(f"    [zotero] updateSession failed: HTTP {r.status_code}")
            return False
        except Exception as e:
            self.log(f"    [zotero] updateSession error: {type(e).__name__}: {e}")
            return False

    # -- direct save (when we already have pdf_bytes) -----------------------

    def save_item_direct(
        self,
        *,
        doi: Optional[str] = None,
        title: Optional[str] = None,
        source_url: Optional[str] = None,
        pdf_bytes: bytes,
        collection_key: Optional[str] = None,
        pdf_filename: str = "paper.pdf",
    ) -> ZoteroResult:
        """Create a Zotero item + PDF attachment for a PDF we downloaded ourselves.

        Zotero's local *data* API (``/api``) is READ-ONLY, so writes must go
        through the Connector server (``/connector``) — the same channel the
        browser extension uses. This mirrors the extension's save handshake:

          1. POST ``/connector/saveItems`` to create the parent item and register
             a pending attachment inside a Connector *session*.
          1b. POST ``/connector/updateSession`` to file the session directly into
             the configured collection (the Connector ignores the item's
             ``collections`` field, and the read-only ``/api`` cannot move it).
          2. POST ``/connector/saveAttachment`` with the raw PDF bytes (matched by
             the same session + attachment id) so Zotero imports OUR exact file
             rather than re-downloading it (which fails on paywalled hosts).

        Used when we successfully fetch the PDF ourselves (e.g. after
        de-watermarking) and want it filed in Zotero alongside the library copy.
        """
        result = ZoteroResult()
        coll_key = collection_key or self.cfg.collection_key
        uri = source_url or (f"https://doi.org/{doi}" if doi else "about:blank")
        session_id = uuid.uuid4().hex
        base_headers = {
            "X-Zotero-Connector-API-Version": "3",
            "User-Agent": "Zotero",
        }

        try:
            # 1) Create the parent item and register the pending attachment.
            item = {
                "id": "item0",
                "itemType": "journalArticle",
                "title": title or "Untitled",
                "DOI": doi or "",
                "url": source_url or "",
                "attachments": [{
                    "id": "att0",
                    "title": pdf_filename,
                    "mimeType": "application/pdf",
                    "url": uri,
                }],
            }
            if coll_key:
                item["collections"] = [coll_key]
            payload = {"sessionID": session_id, "uri": uri, "items": [item]}
            r = self._client.post(
                f"{self.base_url}/connector/saveItems",
                json=payload, headers=base_headers)
            r.raise_for_status()

            # 1b) File the session directly into the target collection. The
            # Connector ignores the item's ``collections`` field (it saves into
            # the UI's last-used collection), so we set the target explicitly
            # via updateSession — the same mechanism the extension's collection
            # picker uses. This lands the item in the right place at save-time
            # (no read-only /api PATCH — which returns HTTP 501).
            if coll_key:
                self.file_session_into_collection(session_id, coll_key)

            # 2) Upload the PDF bytes for the registered attachment.
            meta = {
                "sessionID": session_id,
                "id": "att0",
                "parentItemID": "item0",
                "url": uri,
                "contentType": "application/pdf",
                "title": pdf_filename,
            }
            att_headers = {
                **base_headers,
                "Content-Type": "application/pdf",
                "X-Metadata": json.dumps(meta),
            }
            ra = self._client.post(
                f"{self.base_url}/connector/saveAttachment",
                content=pdf_bytes, headers=att_headers)
            ra.raise_for_status()

            result.saved = True
            result.collection_key = coll_key

            # Resolve the new item key + on-disk path (best-effort).
            if doi:
                item_rec = self.find_item_by_doi(doi)
                if item_rec is not None:
                    result.item_key = item_rec.get("key", "")
                    for att in self.get_item_attachments(result.item_key):
                        result.attachment_key = att.get("data", {}).get("key", "")
                        pdf_path = self.get_attachment_pdf_path(att)
                        if pdf_path is not None:
                            result.linked_file = str(pdf_path)
                            break

        except Exception as e:
            result.error = f"{type(e).__name__}: {e}"

        return result
