"""Parse and normalize input identifiers: DOI, arXiv id, or URL."""

from __future__ import annotations

import re
from urllib.parse import urlparse, unquote

from .models import Identifier, IdentifierKind

# DOI: 10.xxxx/suffix  (suffix is permissive but we trim trailing junk)
_DOI_CORE = r"10\.\d{4,9}/[^\s\"'<>]+"
_DOI_RE = re.compile(_DOI_CORE)
_DOI_ANCHORED = re.compile(r"^(?:doi:)?(?:https?://(?:dx\.)?doi\.org/)?(" + _DOI_CORE + r")$", re.I)

# arXiv new style: 2401.01234 or 2401.01234v2  (4-digit YYMM . 4-5 digits)
_ARXIV_NEW = r"\d{4}\.\d{4,5}(?:v\d+)?"
# arXiv old style: math.OC/0309136 , hep-th/9901001 , cs.AI/0312345
_ARXIV_OLD = r"[a-z][a-z\-]+(?:\.[A-Za-z]{2})?/\d{7}(?:v\d+)?"
_ARXIV_RE = re.compile(
    r"^(?:arxiv:)?(" + _ARXIV_NEW + r"|" + _ARXIV_OLD + r")$", re.I
)
_ARXIV_IN_URL = re.compile(r"arxiv\.org/(?:abs|pdf)/(" + _ARXIV_NEW + r"|" + _ARXIV_OLD + r")", re.I)


def _clean_doi(doi: str, *, url_form: bool = False) -> str:
    doi = doi.strip()
    # drop a trailing query/fragment if a URL form leaked in
    doi = doi.split("#", 1)[0]
    if url_form:
        doi = doi.split("?", 1)[0]
    # strip common trailing punctuation that gets glued onto DOIs in prose/URLs
    doi = doi.rstrip(").,;]>?/")
    return doi


def classify(raw: str) -> Identifier:
    """Classify a single raw string into a normalized Identifier."""
    original = raw
    s = raw.strip()
    if not s:
        return Identifier(IdentifierKind.UNKNOWN, "", original)

    low = s.lower()

    # 1) Explicit arXiv id (with or without arxiv: prefix), no scheme.
    m = _ARXIV_RE.match(s)
    if m:
        return Identifier(IdentifierKind.ARXIV, m.group(1), original)

    # 2) Explicit DOI (bare, doi:, or doi.org URL).
    m = _DOI_ANCHORED.match(s)
    if m:
        is_doi_url = low.startswith(("http://doi.org/", "https://doi.org/",
                                     "http://dx.doi.org/", "https://dx.doi.org/"))
        return Identifier(
            IdentifierKind.DOI,
            _clean_doi(m.group(1), url_form=is_doi_url),
            original,
        )

    # 3) A URL — but inspect it for an embedded arXiv id or DOI first.
    if low.startswith(("http://", "https://")) or _looks_like_bare_url(low):
        url = s if low.startswith(("http://", "https://")) else "https://" + s
        m = _ARXIV_IN_URL.search(url)
        if m:
            return Identifier(IdentifierKind.ARXIV, m.group(1), original)
        # doi embedded in the URL path (preferred) or query string
        parsed = urlparse(url)
        for part in (unquote(parsed.path), unquote(parsed.query)):
            m = _DOI_RE.search(part)
            if m:
                return Identifier(IdentifierKind.DOI, _clean_doi(m.group(0)), original)
        return Identifier(IdentifierKind.URL, url, original)

    # 4) DOI appearing somewhere in a longer string (e.g. pasted citation).
    m = _DOI_RE.search(s)
    if m:
        return Identifier(IdentifierKind.DOI, _clean_doi(m.group(0)), original)

    return Identifier(IdentifierKind.UNKNOWN, s, original)


def _looks_like_bare_url(low: str) -> bool:
    # e.g. "www.nature.com/articles/..." or "ieeexplore.ieee.org/document/123"
    return bool(re.match(r"^(www\.)?[a-z0-9.\-]+\.[a-z]{2,}/", low))


def parse_many(items: list[str] | str) -> list[Identifier]:
    """Parse a list (or newline/comma-separated string) into Identifiers."""
    def split_one(value: str) -> list[str]:
        stripped = value.strip()
        # A comma is legal inside a DOI suffix. Preserve a whole explicit DOI,
        # while retaining comma-separated convenience input for mixed values.
        if "\n" not in stripped and "\r" not in stripped:
            if _DOI_ANCHORED.fullmatch(stripped) or _ARXIV_RE.fullmatch(stripped):
                return [stripped]
            low = stripped.lower()
            if ((low.startswith(("http://", "https://"))
                    or _looks_like_bare_url(low)) and " " not in stripped):
                return [stripped]
        return re.split(r"[\r\n,]+", value)

    if isinstance(items, str):
        parts = split_one(items)
    else:
        parts = []
        for it in items:
            parts.extend(split_one(it))
    return [classify(p) for p in (p.strip() for p in parts) if p.strip()]


def lines_from_input_text(text: str) -> list[str]:
    """Identifier strings from a ``--input`` file body.

    Ignores blank lines and ``#`` comments — whether the ``#`` starts the line or
    follows an identifier inline (``10.1/x  # note`` -> ``10.1/x``). Everything
    from the first ``#`` to end-of-line is dropped, then surrounding whitespace is
    trimmed; only non-empty remainders are kept.
    """
    out: list[str] = []
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if line:
            out.append(line)
    return out
