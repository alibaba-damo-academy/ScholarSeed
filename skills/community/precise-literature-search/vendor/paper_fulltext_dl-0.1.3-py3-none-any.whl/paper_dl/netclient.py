"""Shared HTTP client for the metadata-discovery APIs (Unpaywall, NCBI id-converter,
Semantic Scholar, OpenAlex).

These are small JSON lookups that decide whether a free open-access copy exists. A
transient 429/503 used to silently drop the OA candidate for a DOI — each call was
a bare ``httpx.get`` wrapped in ``except: return None``. This centralizes them:

  * one lazily-built **keep-alive client** (connection reuse across a batch),
  * a **bounded retry** on 429/5xx + transport errors (tenacity), capped well under
    the per-item time budget so it can't starve the browser attempt, and
  * a clear ``(status, json)`` return so callers keep their 404-vs-error nuance.

API-ONLY: never route a publisher PDF fetch or the EZproxy path through here — that
stays in :mod:`paper_dl.http_fallback` with its proxy / referer / hostname-rewrite
behavior. This client deliberately knows nothing about EZproxy or stealth.
"""

from __future__ import annotations

from typing import Optional

import httpx
from tenacity import (
    RetryError,
    retry,
    retry_if_exception_type,
    retry_if_result,
    stop_after_attempt,
    stop_after_delay,
    wait_exponential_jitter,
)

from .deadline import (
    check as check_item_deadline,
    clamp_seconds,
    sleep as deadline_sleep,
)

_RETRY_STATUSES = {429, 500, 502, 503, 504}
_UA = "paper-dl/0.1 (academic full-text fetcher)"

_client: Optional[httpx.Client] = None


def get_client() -> httpx.Client:
    """The lazily-built, reused keep-alive client for the metadata APIs."""
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.Client(
            follow_redirects=True,
            timeout=httpx.Timeout(15.0, connect=10.0),
            headers={"User-Agent": _UA},
        )
    return _client


def close() -> None:
    """Close the shared client (optional; process exit also releases it)."""
    global _client
    if _client is not None and not _client.is_closed:
        try:
            _client.close()
        except Exception:
            pass
    _client = None


def _retryable_response(r: Optional[httpx.Response]) -> bool:
    return isinstance(r, httpx.Response) and r.status_code in _RETRY_STATUSES


@retry(
    stop=(stop_after_attempt(3) | stop_after_delay(6.0)),
    wait=wait_exponential_jitter(initial=0.5, max=3.0),
    retry=(retry_if_exception_type(httpx.TransportError) | retry_if_result(_retryable_response)),
    sleep=deadline_sleep,
)
def _get(url: str, params: dict, *, transport=None) -> httpx.Response:
    check_item_deadline()
    budget = clamp_seconds(15.0)
    timeout = httpx.Timeout(budget, connect=min(10.0, budget))
    if transport is not None:               # tests inject an httpx.MockTransport
        with httpx.Client(
            transport=transport, follow_redirects=True, timeout=timeout
        ) as c:
            return c.get(url, params=params)
    return get_client().get(url, params=params, timeout=timeout)


def request_json(url: str, params: Optional[dict] = None, *, transport=None):
    """GET JSON with a bounded retry on 429/5xx + transport errors.

    Returns ``(status_code, parsed_json_or_None)``. ``status_code`` is 0 on a
    transport failure / exhausted retries with no response. A 404 is NOT retried
    (callers treat it as 'not indexed'). Never raises.
    """
    try:
        r = _get(url, params or {}, transport=transport)
    except RetryError as e:
        try:
            r = e.last_attempt.result()      # the last response for a retryable status
        except Exception:
            return 0, None
    except Exception:
        return 0, None
    if r.status_code == 200:
        try:
            return 200, r.json()
        except Exception:
            return 200, None
    return r.status_code, None
