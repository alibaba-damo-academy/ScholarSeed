"""Shared strict work-identity normalization for metadata records and PDFs."""

from __future__ import annotations

import html
import re
import unicodedata


def identity_tokens(value: str | None) -> list[str]:
    """Return Unicode-normalized alphanumeric tokens with boundaries intact."""
    decomposed = unicodedata.normalize("NFKD", html.unescape(value or "")).casefold()
    tokens: list[str] = []
    current: list[str] = []
    for character in decomposed:
        if character.isalnum() and not unicodedata.combining(character):
            current.append(character)
        elif current:
            tokens.append("".join(current))
            current = []
    if current:
        tokens.append("".join(current))
    return tokens


def normalize_identity(value: str | None) -> str:
    """Return Unicode/markup-insensitive text for exact containment checks."""
    raw = re.sub(r"<[^>]+>", " ", html.unescape(value or ""))
    decomposed = unicodedata.normalize("NFKD", raw).casefold()
    return "".join(
        character for character in decomposed
        if character.isalnum() and not unicodedata.combining(character)
    )


def author_variants(value: str) -> set[str]:
    """Return conservative full/family variants for a person or group name."""
    words = identity_tokens(value)
    if not words:
        return set()
    variants = {"".join(words), words[-1]}
    has_cjk = any(
        "\u3400" <= character <= "\u9fff" or "\uf900" <= character <= "\ufaff"
        for character in value
    )
    if has_cjk:
        variants.add(words[0])
        if len(words) == 1 and 2 <= len(words[0]) <= 4 and _is_han(words[0]):
            variants.add(words[0][:1])
            if len(words[0]) >= 3:
                variants.add(words[0][:2])
    return variants - {""}


def matched_author_names(
    source: tuple[str, ...],
    candidate: tuple[str, ...],
) -> tuple[tuple[str, ...], int]:
    """Return one-to-one matched source names and the smaller author count."""
    source_entries = [
        (name, author_variants(name)) for name in dict.fromkeys(source)
    ]
    source_entries = [entry for entry in source_entries if entry[1]]
    source_names = [entry[0] for entry in source_entries]
    source_variants = [entry[1] for entry in source_entries]
    candidate_variants = [author_variants(name) for name in dict.fromkeys(candidate)]
    candidate_variants = [variants for variants in candidate_variants if variants]
    m = min(len(source_variants), len(candidate_variants))
    if m == 0:
        return (), 0
    matched_source: dict[int, int] = {}

    def assign(candidate_index: int, visited: set[int]) -> bool:
        for source_index, variants in enumerate(source_variants):
            if source_index in visited:
                continue
            if not (candidate_variants[candidate_index] & variants):
                continue
            visited.add(source_index)
            previous = matched_source.get(source_index)
            if previous is None or assign(previous, visited):
                matched_source[source_index] = candidate_index
                return True
        return False

    for index in range(len(candidate_variants)):
        assign(index, set())
    matched_names = tuple(
        source_names[index] for index in sorted(matched_source)[:m]
    )
    return matched_names, m


def author_overlap(source: tuple[str, ...], candidate: tuple[str, ...]) -> tuple[int, int]:
    """Maximum one-to-one overlap count and the smaller unique author count."""
    names, m = matched_author_names(source, candidate)
    return len(names), m


def _is_han(value: str) -> bool:
    return bool(value) and all(
        "\u3400" <= character <= "\u9fff" or "\uf900" <= character <= "\ufaff"
        for character in value
    )


def strict_pdf_author_matches(
    text: str,
    expected_authors: tuple[str, ...],
) -> tuple[int, int]:
    """Count boundary-safe author evidence in extracted PDF text."""
    unique_authors = tuple(dict.fromkeys(
        author for author in expected_authors if identity_tokens(author)
    ))
    if not unique_authors:
        return 0, 0
    text_tokens = identity_tokens(text)
    bounded_text_names = set(text_tokens)
    for width in range(2, min(8, len(text_tokens)) + 1):
        bounded_text_names.update(
            "".join(text_tokens[index:index + width])
            for index in range(len(text_tokens) - width + 1)
        )

    matched = 0
    for author in unique_authors:
        author_tokens = identity_tokens(author)
        evidence = "".join(author_tokens)
        if evidence in bounded_text_names:
            matched += 1
            continue
        # Chinese family-only metadata is commonly one Han character (or a
        # two-character compound surname), while PDF extraction keeps 王伟 as one
        # token. Accept only a prefix of a plausible 2–4 Han-character name;
        # never a middle substring such as 王 in 李王伟.
        if (len(author_tokens) == 1 and 1 <= len(evidence) <= 2
                and _is_han(evidence)
                and any(
                    2 <= len(token) <= 4 and _is_han(token)
                    and token.startswith(evidence)
                    for token in text_tokens
                )):
            matched += 1
    return matched, len(unique_authors)
