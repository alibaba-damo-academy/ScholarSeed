"""Killable, persistent process boundary for per-paper acquisition.

Playwright's synchronous API is implemented with greenlets.  A native/driver call
can therefore keep switching inside the sync bridge without returning control to
Python, which means a signal-based deadline and a cooperative skip flag cannot
always stop it.  This module puts the whole acquisition in a child process.  The
child remains alive between healthy papers (and owns one persistent browser), but
the parent can terminate its process group when a paper ignores its deadline.
"""

from __future__ import annotations

from dataclasses import dataclass
import multiprocessing
from multiprocessing.connection import Connection
import os
import signal
import time
from typing import Any, Callable, Optional


class WorkerFailure(RuntimeError):
    """The acquisition worker exited or rejected a command."""


class _WorkerStartTimeout(WorkerFailure):
    pass


class _WorkerStartSkipped(WorkerFailure):
    pass


@dataclass(frozen=True)
class WorkerReply:
    value: Any = None
    timed_out: bool = False
    skipped: bool = False
    # Bounded request-local breadcrumbs survive a forced worker termination so
    # the parent can report the page/challenge that consumed the hard deadline.
    recent_logs: tuple[str, ...] = ()


@dataclass(frozen=True)
class WorkerPageHandle:
    """Opaque reference to a login-assist page owned by the child process."""

    token: int


def _safe_send(conn: Connection, message: dict[str, Any]) -> bool:
    try:
        conn.send(message)
        return True
    except (BrokenPipeError, EOFError, OSError):
        return False


def _worker_main(conn: Connection, cfg) -> None:
    # Give the worker and every browser/driver it launches their own process
    # group.  A forced timeout can then remove the entire hung tree without
    # touching an externally managed Chrome reached through --connect-cdp.
    if os.name == "posix":
        try:
            os.setsid()
        except OSError:
            pass

    from .service import PaperDownloadService

    def emit(message) -> None:
        _safe_send(conn, {"kind": "log", "message": str(message)})

    service = PaperDownloadService(cfg, logger=emit)
    pages: dict[int, Any] = {}
    next_page_token = 1
    if not _safe_send(conn, {"kind": "ready"}):
        return

    try:
        while True:
            try:
                request = conn.recv()
            except (EOFError, OSError):
                break
            request_id = request.get("id")
            command = request.get("command")
            try:
                if command == "close":
                    service.close()
                    _safe_send(conn, {
                        "kind": "reply", "id": request_id, "value": None,
                    })
                    break
                if command == "restart_engine":
                    pages.clear()
                    service.restart_engine()
                    value = None
                elif command == "download":
                    ident = request["ident"]
                    # Parent-side login assistance may have changed durable access
                    # state since the previous command; refresh before deciding
                    # whether publisher candidates should be gated.
                    service._institution_access_memory.load_if_changed()
                    value = service._download_one(
                        ident,
                        previous=request.get("previous"),
                        bypass_institution_login_gate=bool(
                            request.get("bypass_institution_login_gate", False)
                        ),
                    )
                elif command == "open_login":
                    page = service.open_institution_login_page(request["result"])
                    token = next_page_token
                    next_page_token += 1
                    pages[token] = page
                    value = token
                elif command == "close_login":
                    token = int(request["token"])
                    page = pages.pop(token, None)
                    if page is not None:
                        service.close_institution_login_page(page)
                    value = None
                else:
                    raise ValueError(f"unknown worker command: {command!r}")
                if not _safe_send(conn, {
                    "kind": "reply", "id": request_id, "value": value,
                }):
                    break
            except BaseException as exc:  # the next paper may still be recoverable
                if not _safe_send(conn, {
                    "kind": "error",
                    "id": request_id,
                    "error_type": type(exc).__name__,
                    "message": str(exc)[:1000],
                }):
                    break
    finally:
        try:
            service.close()
        except BaseException:
            pass
        try:
            conn.close()
        except OSError:
            pass


class PersistentItemWorker:
    """One reusable service process with a parent-enforced wall-clock boundary."""

    def __init__(
        self,
        cfg,
        *,
        logger: Callable[[str], None],
        _target: Callable[..., None] = _worker_main,
    ) -> None:
        self._cfg = cfg
        self._log = logger
        self._ctx = multiprocessing.get_context("spawn")
        self._process: Optional[multiprocessing.Process] = None
        self._conn: Optional[Connection] = None
        self._request_id = 0
        self._target = _target

    @property
    def pid(self) -> Optional[int]:
        return self._process.pid if self._process is not None else None

    def _start(
        self,
        timeout_s: float,
        skip_check: Optional[Callable[[], bool]] = None,
    ) -> None:
        if self._process is not None and self._process.is_alive():
            return
        self._dispose_handles()
        parent_conn, child_conn = self._ctx.Pipe(duplex=True)
        process = self._ctx.Process(
            target=self._target,
            args=(child_conn, self._cfg),
            name="paper-dl-item-worker",
        )
        process.start()
        child_conn.close()
        self._process = process
        self._conn = parent_conn
        deadline = time.monotonic() + max(0.001, timeout_s)
        while time.monotonic() < deadline:
            if skip_check is not None and skip_check():
                self.abort()
                raise _WorkerStartSkipped("worker startup skipped by user")
            if not process.is_alive():
                self._dispose_handles()
                raise WorkerFailure(
                    f"acquisition worker exited during startup (exit code {process.exitcode})"
                )
            if parent_conn.poll(min(0.1, max(0.0, deadline - time.monotonic()))):
                message = parent_conn.recv()
                if message.get("kind") == "ready":
                    return
                if message.get("kind") == "log":
                    self._log(message.get("message", ""))
        self.abort()
        raise _WorkerStartTimeout(
            "acquisition worker did not start before its deadline"
        )

    def request(
        self,
        command: str,
        *,
        timeout_s: float,
        skip_check: Optional[Callable[[], bool]] = None,
        **payload,
    ) -> WorkerReply:
        started = time.monotonic()
        try:
            self._start(timeout_s, skip_check=skip_check)
        except _WorkerStartSkipped:
            return WorkerReply(skipped=True)
        except _WorkerStartTimeout:
            return WorkerReply(timed_out=True)
        remaining = timeout_s - (time.monotonic() - started)
        if remaining <= 0:
            self.abort()
            return WorkerReply(timed_out=True)
        assert self._conn is not None
        assert self._process is not None
        self._request_id += 1
        request_id = self._request_id
        try:
            self._conn.send({
                "id": request_id,
                "command": command,
                **payload,
            })
        except (BrokenPipeError, EOFError, OSError) as exc:
            exitcode = self._process.exitcode
            self.abort()
            raise WorkerFailure(
                f"could not contact acquisition worker (exit code {exitcode})"
            ) from exc

        deadline = started + timeout_s
        recent_logs: list[str] = []
        while True:
            if skip_check is not None and skip_check():
                self.abort()
                return WorkerReply(skipped=True, recent_logs=tuple(recent_logs))
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self.abort()
                return WorkerReply(
                    timed_out=True, recent_logs=tuple(recent_logs),
                )
            if not self._process.is_alive():
                exitcode = self._process.exitcode
                self.abort()
                raise WorkerFailure(
                    f"acquisition worker exited unexpectedly (exit code {exitcode})"
                )
            try:
                available = self._conn.poll(min(0.1, remaining))
            except (EOFError, OSError) as exc:
                self.abort()
                raise WorkerFailure("connection to acquisition worker was lost") from exc
            if not available:
                continue
            try:
                message = self._conn.recv()
            except (EOFError, OSError) as exc:
                self.abort()
                raise WorkerFailure("connection to acquisition worker was lost") from exc
            kind = message.get("kind")
            if kind == "log":
                log_message = str(message.get("message", ""))
                recent_logs.append(log_message)
                if len(recent_logs) > 64:
                    del recent_logs[:-64]
                self._log(log_message)
                continue
            if message.get("id") != request_id:
                self.abort()
                raise WorkerFailure("acquisition worker returned a mismatched response")
            if kind == "reply":
                return WorkerReply(
                    value=message.get("value"),
                    recent_logs=tuple(recent_logs),
                )
            if kind == "error":
                raise WorkerFailure(
                    f"{message.get('error_type', 'WorkerError')}: "
                    f"{message.get('message', 'worker command failed')}"
                )
            self.abort()
            raise WorkerFailure("acquisition worker returned an invalid response")

    def restart_engine(self, timeout_s: float) -> None:
        reply = self.request("restart_engine", timeout_s=timeout_s)
        if reply.timed_out:
            raise WorkerFailure("browser restart exceeded its deadline")

    def close(self, grace_s: float = 5.0) -> None:
        process = self._process
        if process is None:
            return
        if process.is_alive() and self._conn is not None:
            try:
                self._request_id += 1
                request_id = self._request_id
                self._conn.send({"id": request_id, "command": "close"})
                deadline = time.monotonic() + max(0.0, grace_s)
                while process.is_alive() and time.monotonic() < deadline:
                    if self._conn.poll(min(0.1, deadline - time.monotonic())):
                        message = self._conn.recv()
                        if message.get("kind") == "log":
                            self._log(message.get("message", ""))
                        elif (message.get("kind") == "reply"
                              and message.get("id") == request_id):
                            break
                process.join(timeout=max(0.0, deadline - time.monotonic()))
            except (BrokenPipeError, EOFError, OSError):
                pass
        if process.is_alive():
            self.abort()
        else:
            self._dispose_handles()

    def abort(self) -> None:
        """Force-stop the worker and descendants; external CDP Chrome is untouched."""
        process = self._process
        if process is None:
            self._dispose_handles()
            return
        if process.is_alive():
            killed_group = False
            if os.name == "posix" and process.pid is not None:
                try:
                    pgid = os.getpgid(process.pid)
                    if pgid == process.pid:
                        os.killpg(pgid, signal.SIGTERM)
                        killed_group = True
                except (ProcessLookupError, PermissionError, OSError):
                    pass
            if not killed_group:
                process.terminate()
            process.join(timeout=1.0)
        if process.is_alive():
            if os.name == "posix" and process.pid is not None:
                try:
                    pgid = os.getpgid(process.pid)
                    if pgid == process.pid:
                        os.killpg(pgid, signal.SIGKILL)
                    else:
                        process.kill()
                except (ProcessLookupError, PermissionError, OSError):
                    process.kill()
            else:
                process.kill()
            process.join(timeout=1.0)
        self._dispose_handles()

    def _dispose_handles(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except OSError:
                pass
        self._conn = None
        self._process = None
