"""Non-blocking terminal hotkey for skipping the currently running paper."""

from __future__ import annotations

import os
import select
import sys
import threading
from typing import Callable, Optional


class KeyboardSkipController:
    """Watch stdin for a single ``s`` key while one batch item is active.

    Unix terminals are temporarily put in cbreak mode so Enter is unnecessary.
    ``Ctrl+S`` is intentionally avoided because terminals commonly reserve it for
    XON/XOFF flow control. Non-interactive stdin simply disables the watcher.
    """

    def __init__(
        self,
        output_fn: Optional[Callable[[str], None]] = None,
        *,
        queue_when_inactive: bool = False,
    ):
        self.output = output_fn or (lambda _message: None)
        self._queue_when_inactive = queue_when_inactive
        self._requested = threading.Event()
        self._stop = threading.Event()
        self._active = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._fd: Optional[int] = None
        self._termios = None
        self._old_attrs = None
        self.enabled = False

    def __enter__(self):
        try:
            self._stop.clear()
            self._requested.clear()
            self._active.clear()
            self._thread = None
            if not sys.stdin.isatty():
                return self
            self._fd = sys.stdin.fileno()
            if os.name != "nt":
                import termios
                import tty
                self._termios = termios
                self._old_attrs = termios.tcgetattr(self._fd)
                tty.setcbreak(self._fd)
            self.enabled = True
            self._thread = threading.Thread(target=self._watch, daemon=True,
                                            name="paper-dl-skip-key")
            self._thread.start()
        except Exception:
            self.enabled = False
            self._restore_terminal()
        return self

    def __exit__(self, *_exc):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=0.5)
        self._restore_terminal()
        self.enabled = False

    def begin_item(self, label: str = "") -> None:
        if not self._queue_when_inactive:
            self._requested.clear()
        self._active.set()

    def end_item(self) -> None:
        self._active.clear()
        self._requested.clear()

    def is_requested(self) -> bool:
        return self._requested.is_set()

    def request_skip(self) -> bool:
        """Programmatic equivalent of pressing s (also useful to API callers/tests)."""
        if (
            (self._active.is_set() or self._queue_when_inactive)
            and not self._requested.is_set()
        ):
            self._requested.set()
            self.output("\n[yellow]Skip requested — stopping the current paper…[/yellow]")
            return True
        return False

    def _watch(self) -> None:
        if os.name == "nt":
            self._watch_windows()
            return
        assert self._fd is not None
        while not self._stop.is_set():
            try:
                ready, _, _ = select.select([self._fd], [], [], 0.1)
                if not ready:
                    continue
                char = os.read(self._fd, 1).decode("utf-8", "ignore").lower()
                if char == "s":
                    self.request_skip()
            except Exception:
                return

    def _watch_windows(self) -> None:
        try:
            import msvcrt
        except ImportError:
            return
        while not self._stop.wait(0.05):
            try:
                if msvcrt.kbhit() and msvcrt.getwch().lower() == "s":
                    self.request_skip()
            except Exception:
                return

    def _restore_terminal(self) -> None:
        if self._termios is not None and self._old_attrs is not None and self._fd is not None:
            try:
                self._termios.tcsetattr(self._fd, self._termios.TCSADRAIN, self._old_attrs)
            except Exception:
                pass
        self._old_attrs = None
