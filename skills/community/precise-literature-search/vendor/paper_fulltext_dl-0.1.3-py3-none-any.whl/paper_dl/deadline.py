"""Absolute per-paper deadline support.

The downloader is mostly synchronous and several individual operations (browser
navigation, a human captcha wait, a streaming HTTP response)
can each outlive the old between-candidate budget check.  This module provides a
context-local absolute deadline plus a POSIX main-thread watchdog that can
interrupt an operation already in progress.

The context-local helpers are also used to clamp cooperative waits.  That keeps
the behavior correct when the service is embedded in a worker thread or on a
platform without ``setitimer``; the watchdog makes the normal macOS/Linux CLI
path a genuine wall-clock cap.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
import math
import signal
import threading
import time
from typing import Iterator, Optional


@dataclass(frozen=True)
class DeadlineStage:
    """Acquisition stage active when a per-paper deadline expires."""

    method: str
    url: str
    started_monotonic: float


_current_deadline: ContextVar[Optional[float]] = ContextVar(
    "paper_dl_item_deadline", default=None
)
_current_stage: ContextVar[Optional[DeadlineStage]] = ContextVar(
    "paper_dl_deadline_stage", default=None
)


class ItemDeadlineExceeded(BaseException):
    """Internal control-flow signal for an expired per-paper deadline.

    This deliberately derives from :class:`BaseException`: browser and network
    layers contain broad ``except Exception`` recovery blocks which must not turn
    a hard deadline into an ordinary failed candidate and continue running.
    """

    def __init__(self) -> None:
        self.stage = _current_stage.get()
        super().__init__("hard per-paper deadline exceeded")


def remaining_seconds() -> Optional[float]:
    """Seconds remaining in the active item, or ``None`` outside an item."""

    absolute = _current_deadline.get()
    if absolute is None:
        return None
    return max(0.0, absolute - time.monotonic())


def check() -> None:
    """Raise immediately if the active item's absolute deadline has expired."""

    remaining = remaining_seconds()
    if remaining is not None and remaining <= 0.0:
        raise ItemDeadlineExceeded()


def clamp_seconds(seconds: float, *, minimum: float = 0.001) -> float:
    """Clamp an operation-specific timeout to the current item remainder."""

    check()
    configured = max(0.0, float(seconds))
    remaining = remaining_seconds()
    if remaining is not None:
        configured = min(configured, remaining)
    return max(minimum, configured)


def clamp_milliseconds(milliseconds: int | float) -> int:
    """Millisecond form of :func:`clamp_seconds`, suitable for Playwright."""

    seconds = clamp_seconds(float(milliseconds) / 1000.0)
    return max(1, int(math.ceil(seconds * 1000.0)))


def sleep(seconds: float) -> None:
    """Sleep no longer than the active item remainder, then enforce expiry."""

    duration = max(0.0, float(seconds))
    remaining = remaining_seconds()
    if remaining is not None:
        duration = min(duration, remaining)
    time.sleep(duration)
    check()


@contextmanager
def acquisition_stage(method: str, url: str = "") -> Iterator[None]:
    """Annotate the acquisition stage to preserve its partial elapsed time."""

    token = _current_stage.set(DeadlineStage(
        method=method,
        url=url,
        started_monotonic=time.monotonic(),
    ))
    try:
        check()
        yield
    finally:
        _current_stage.reset(token)


def hard_watchdog_available() -> bool:
    """Whether this thread/platform supports asynchronous wall-clock expiry."""

    return (
        threading.current_thread() is threading.main_thread()
        and hasattr(signal, "SIGALRM")
        and hasattr(signal, "setitimer")
        and hasattr(signal, "ITIMER_REAL")
    )


@contextmanager
def paper_deadline(seconds: float) -> Iterator[float]:
    """Enforce one absolute wall-clock deadline around a paper attempt.

    On the normal macOS/Linux CLI path, ``SIGALRM`` interrupts even a currently
    blocked third-party call.  If another component already owns the process's
    real-time interval timer, we leave it untouched and retain cooperative
    deadline enforcement instead of clobbering the caller's signal state.
    """

    budget = float(seconds)
    if not math.isfinite(budget) or budget <= 0.0:
        raise ValueError("per_request_timeout_s must be a finite number greater than 0")

    started = time.monotonic()
    absolute = started + budget
    parent = _current_deadline.get()
    if parent is not None:
        absolute = min(absolute, parent)
    token = _current_deadline.set(absolute)

    watchdog = False
    handler_changed = False
    previous_handler = None
    try:
        if hard_watchdog_available():
            try:
                # Respect a timer installed by an embedding application or test
                # harness. Nested paper_deadline contexts are covered by that timer
                # plus the cooperative absolute deadline above.
                existing_delay, _ = signal.getitimer(signal.ITIMER_REAL)
                if existing_delay <= 0.0:
                    previous_handler = signal.getsignal(signal.SIGALRM)

                    def _expire(_signum, _frame):
                        raise ItemDeadlineExceeded()

                    signal.signal(signal.SIGALRM, _expire)
                    handler_changed = True
                    signal.setitimer(
                        signal.ITIMER_REAL,
                        max(0.000001, absolute - time.monotonic()),
                    )
                    watchdog = True
            except (OSError, RuntimeError, ValueError):
                watchdog = False
        check()
        yield absolute
        # Important for worker-thread/non-POSIX use: an operation that returned
        # after the deadline is still converted to a timeout before it can win.
        check()
    finally:
        if watchdog:
            try:
                signal.setitimer(signal.ITIMER_REAL, 0.0)
            finally:
                signal.signal(signal.SIGALRM, previous_handler)
        elif handler_changed:
            # setitimer itself may have failed after the handler was swapped.
            signal.signal(signal.SIGALRM, previous_handler)
        _current_deadline.reset(token)
