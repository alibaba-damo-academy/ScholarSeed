async (payload) => {
	"use strict";
	const adapterMap = new Map((payload.adapters || []).map(adapter => [adapter.id, adapter]));
	const delegateMap = payload.delegates || {};
	const supportedDelegateTypes = new Set(["web", "import", "search"]);
	const rdfTranslatorID = "5e3ad958-ac79-463d-812b-a86a9235c28f";
	const maxDelegateDepth = 4;
	const errors = [];
	const debug = [];
	const items = [];
	const tasks = [];
	const deadline = performance.now() + Math.max(
		1, Number(payload.totalTimeoutMs || payload.timeoutMs || 15000)
	);
	const targetDOI = String(payload.targetDOI || "").toLowerCase()
		.replace(/^https?:\/\/(?:dx\.)?doi\.org\//, "").replace(/^doi:\s*/, "");
	const highwirePDFs = [];
	for (const meta of document.querySelectorAll(
		'meta[name="citation_pdf_url" i], meta[property="citation_pdf_url" i], '
		+ 'meta[name="citation_abstract_pdf_url" i], meta[property="citation_abstract_pdf_url" i]'
	)) {
		const metaName = String(
			meta.getAttribute("name") || meta.getAttribute("property") || ""
		).toLowerCase();
		let pageHost = "";
		try { pageHost = new URL(payload.url || document.baseURI).hostname.toLowerCase(); }
		catch (e) {}
		if (metaName === "citation_abstract_pdf_url"
				&& pageHost !== "jmir.org" && !pageHost.endsWith(".jmir.org")) continue;
		const value = meta.getAttribute("content") || "";
		if (!value) continue;
		try {
			highwirePDFs.push({
				url: new URL(value, payload.url || document.baseURI).href,
				title: "Full Text PDF",
				mimeType: "application/pdf",
			});
		}
		catch (e) {}
	}
	for (const link of document.querySelectorAll('a[href]')) {
		const label = String(
			link.getAttribute("aria-label") || link.textContent || ""
		).trim().replace(/\s+/g, " ");
		const value = link.getAttribute("href") || "";
		if (!/^download pdf$/i.test(label) || !value || value.startsWith("#")) continue;
		try {
			highwirePDFs.push({
				url: new URL(value, payload.url || document.baseURI).href,
				title: "Full Text PDF",
				mimeType: "application/pdf",
			});
		}
		catch (e) {}
	}
	if (payload.rootID === "951c027d-74ac-47d4-a107-9c3069ab7b48" && highwirePDFs.length) {
		return {detected: true, pdfs: highwirePDFs, errors: [], debug: []};
	}

	function recordError(error) {
		errors.push(String(error && (error.stack || error.message) || error).slice(0, 1200));
	}

	function track(value) {
		// Keep a catch for fire-and-forget helpers, but return the original
		// promise so an upstream translator that awaits `translate()` can take
		// its documented fallback path when a real delegate fails.
		const promise = Promise.resolve(value);
		tasks.push(promise.catch(recordError));
		return promise;
	}

	function withinDeadline(value) {
		const remaining = Math.floor(deadline - performance.now());
		if (remaining <= 0) return Promise.reject(
			new Error("translator runtime deadline exceeded")
		);
		let timer;
		return Promise.race([
			Promise.resolve(value),
			new Promise((_, reject) => {
				timer = setTimeout(
					() => reject(new Error("translator runtime deadline exceeded")),
					remaining
				);
			}),
		]).finally(() => clearTimeout(timer));
	}

	function normalizeSelectionText(value) {
		let output = "";
		try { output = typeof value === "string" ? value : JSON.stringify(value); }
		catch (e) { output = String(value || ""); }
		try { output = decodeURIComponent(output); }
		catch (e) {}
		return output.toLowerCase().replace(/\\\//g, "/");
	}

	function selectItems(itemsToSelect) {
		const entries = Object.entries(itemsToSelect || {});
		let selected = [];
		if (targetDOI) {
			selected = entries.filter(([key, value]) =>
				(normalizeSelectionText(key) + "\n" + normalizeSelectionText(value)).includes(targetDOI)
			).slice(0, 1);
		}
		if (!selected.length && entries.length === 1) selected = entries;
		return selected.length ? Object.fromEntries(selected) : null;
	}

	function addBase(documentObject, url) {
		try {
			const base = documentObject.createElement("base");
			base.href = url;
			(documentObject.head || documentObject.documentElement).prepend(base);
		}
		catch (e) {}
		return documentObject;
	}

	async function request(url, options = {}) {
		const controller = new AbortController();
		const remaining = Math.floor(deadline - performance.now());
		if (remaining <= 0) throw new Error("translator runtime deadline exceeded");
		const timeout = Math.max(1, Math.min(
			Number(options.timeout || payload.timeoutMs || 15000),
			remaining,
			30000
		));
		const timer = setTimeout(() => controller.abort(), timeout);
		try {
			const response = await fetch(new URL(url, document.baseURI).href, {
				method: options.method || (options.body ? "POST" : "GET"),
				headers: options.headers || {},
				body: options.body,
				credentials: "include",
				redirect: "follow",
				signal: controller.signal,
			});
			if (!response.ok) throw new Error(`HTTP ${response.status} for ${url}`);
			const body = await response.text();
			return {body, status: response.status, url: response.url, headers: response.headers};
		}
		finally { clearTimeout(timer); }
	}

	async function requestText(url, options = {}) {
		return (await request(url, options)).body;
	}

	async function requestJSON(url, options = {}) {
		return JSON.parse(await requestText(url, options));
	}

	async function requestDocument(url, options = {}) {
		const response = await request(url, options);
		return addBase(new DOMParser().parseFromString(response.body, "text/html"), response.url || url);
	}

	function elementValue(kind, first, second, third, fourth) {
		let root = document, selector, attribute, index;
		if (first && typeof first.querySelectorAll === "function") {
			root = first;
			selector = second;
			attribute = kind === "attr" ? third : null;
			index = kind === "attr" ? fourth : third;
		}
		else {
			selector = first;
			attribute = kind === "attr" ? second : null;
			index = kind === "attr" ? third : second;
		}
		const node = root.querySelectorAll(selector)[Number(index || 0)];
		if (!node) return null;
		if (kind === "attr") return node.getAttribute(attribute);
		if (kind === "innerText") return node.innerText;
		return node.textContent;
	}

	function attr(...args) { return elementValue("attr", ...args); }
	function text(...args) { return elementValue("text", ...args); }
	function innerText(...args) { return elementValue("innerText", ...args); }

	function xpath(documentObject, expression, namespaces) {
		const resolver = prefix => namespaces && namespaces[prefix] || null;
		const result = documentObject.evaluate(
			expression, documentObject, resolver, XPathResult.ANY_TYPE, null
		);
		if (result.resultType === XPathResult.STRING_TYPE) return [result.stringValue];
		if (result.resultType === XPathResult.NUMBER_TYPE) return [result.numberValue];
		if (result.resultType === XPathResult.BOOLEAN_TYPE) return [result.booleanValue];
		const output = [];
		let node;
		while ((node = result.iterateNext())) output.push(node);
		return output;
	}

	function cleanAuthor(name, creatorType = "author", useComma = false) {
		name = String(name || "").trim().replace(/\s+/g, " ");
		let firstName = "", lastName = name;
		if (useComma || name.includes(",")) {
			const parts = name.split(",");
			lastName = (parts.shift() || "").trim();
			firstName = parts.join(" ").trim();
		}
		else {
			const parts = name.split(" ");
			lastName = parts.pop() || "";
			firstName = parts.join(" ");
		}
		return {firstName, lastName, creatorType};
	}

	const ZU = {
		xpath,
		xpathText(doc, expression, namespaces) {
			const value = xpath(doc, expression, namespaces)[0];
			return value && value.textContent !== undefined ? value.textContent : value;
		},
		trimInternal(value) { return String(value || "").trim().replace(/\s+/g, " "); },
		trim(value) { return String(value || "").trim(); },
		cleanAuthor,
		cleanDOI(value) {
			const match = String(value || "").match(/10\.\d{4,9}\/[^\s"<>]+/i);
			return match ? match[0].replace(/[.,;)]$/, "") : "";
		},
		cleanISBN(value) { return String(value || "").replace(/[^0-9X]/gi, ""); },
		cleanISSN(value) { return String(value || "").trim(); },
		cleanTags(value) { return String(value || "").replace(/<[^>]+>/g, ""); },
		capitalizeTitle(value) {
			return String(value || "").toLowerCase().replace(/(^|\s)\S/g, match => match.toUpperCase());
		},
		capitalizeName(value) { return this.capitalizeTitle(value); },
		unescapeHTML(value) {
			return new DOMParser().parseFromString(String(value || ""), "text/html").documentElement.textContent;
		},
		strToISO(value) {
			const date = new Date(value);
			return Number.isNaN(date.getTime()) ? String(value || "") : date.toISOString().slice(0, 10);
		},
		strToDate(value) { return {year: String(value || "").match(/\d{4}/)?.[0] || ""}; },
		removeDiacritics(value) { return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, ""); },
		superCleanString(value) { return String(value || "").replace(/[^\p{L}\p{N}\s]/gu, "").trim(); },
		lpad(value, character, length) { return String(value).padStart(length, character); },
		arrayUnique(values) { return Array.from(new Set(values || [])); },
		arrayDiff(left, right) { return (left || []).filter(value => !(right || []).includes(value)); },
		deepCopy(value) { return JSON.parse(JSON.stringify(value)); },
		fieldIsValidForType() { return true; },
		itemTypeExists() { return true; },
		getCreatorsForType() { return ["author", "editor"]; },
		ellipsize(value, length) { return String(value || "").slice(0, length); },
		quotemeta(value) { return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); },
		resolveURL(value, base) { return new URL(value, base || document.baseURI).href; },
		getPageRange(value) {
			const parts = String(value || "").split(/[-–]/);
			return [parts[0] || "", parts[1] || parts[0] || ""];
		},
		getItemArray(doc, context, urlRe) {
			const output = {};
			for (const link of (context || doc).querySelectorAll("a[href]")) {
				const href = link.href;
				if (!urlRe || urlRe.test(href)) output[href] = link.textContent.trim();
			}
			return output;
		},
		processDocuments(urls, processor, done) {
			return track((async () => {
				for (const url of (Array.isArray(urls) ? urls : [urls])) {
					processor(await requestDocument(url), url);
				}
				if (done) done();
			})());
		},
		doGet(urls, processor, done) {
			return track((async () => {
				for (const url of (Array.isArray(urls) ? urls : [urls])) {
					processor(await requestText(url), null, url);
				}
				if (done) done();
			})());
		},
		doPost(url, body, processor, headers) {
			return track(requestText(url, {method: "POST", body, headers}).then(processor));
		},
		requestText,
		requestJSON,
		requestDocument,
		HTTP: {},
	};
	ZU.HTTP.doGet = ZU.doGet;
	ZU.HTTP.doPost = ZU.doPost;

	function pdfLikeURL(value) {
		return /\.pdf(?:$|[?#])|\/pdf(?:$|[/?#])|\/epdf(?:$|[/?#])|pdfft|downloadpdf/i.test(String(value || ""));
	}

	function addImportedURL(item, value) {
		value = String(value || "").trim();
		if (!value) return;
		if (!item.url && /^https?:\/\//i.test(value)) item.url = value;
		if (pdfLikeURL(value)) {
			item.attachments.push({url: value, title: "Full Text PDF", mimeType: "application/pdf"});
		}
	}

	function parseImport(text) {
		const item = {
			itemType: "journalArticle", creators: [], tags: [], attachments: [], notes: [],
			publicationTitle: "", title: "", DOI: "", ISSN: ""
		};
		const source = String(text || "");
		const ris = /^TY\s{0,2}-/m.test(source);
		if (ris) {
			for (const line of source.split(/\r?\n/)) {
				const match = line.match(/^([A-Z0-9]{2})\s{0,2}-\s?(.*)$/);
				if (!match) continue;
				const [, tag, value] = match;
				if (["TI", "T1"].includes(tag) && !item.title) item.title = value;
				else if (tag === "DO") item.DOI = value;
				else if (["UR", "L1", "L2", "L3", "LK"].includes(tag)) addImportedURL(item, value);
			}
		}
		else {
			item.title = source.match(/title\s*=\s*[{"]([^}"]+)/i)?.[1] || "";
			item.DOI = source.match(/doi\s*=\s*[{"]([^}"]+)/i)?.[1] || "";
			item.publicationTitle = source.match(/(?:journal|booktitle)\s*=\s*[{\"]([^}\"]+)/i)?.[1] || "";
			item.ISSN = source.match(/issn\s*=\s*[{\"]([^}\"]+)/i)?.[1] || "";
			for (const url of (source.match(/https?:\/\/[^\s"}<>,]+/gi) || [])) addImportedURL(item, url);
			try {
				const parsed = JSON.parse(source);
				const record = Array.isArray(parsed) ? parsed[0] : parsed;
				if (record && typeof record === "object") {
					item.DOI ||= record.DOI || record.doi || "";
					item.title ||= record.title || "";
					for (const value of [record.URL, record.url, record.pdf, record.pdf_url, record.pdfUrl]) addImportedURL(item, value);
					const links = record.link || record.links || [];
					for (const link of (Array.isArray(links) ? links : [links])) {
						addImportedURL(item, typeof link === "string" ? link : link.URL || link.url || link.href);
					}
				}
			}
			catch (e) {}
		}
		return item;
	}

	function translatorIDFrom(value) {
		if (Array.isArray(value)) {
			for (const candidate of value) {
				const id = translatorIDFrom(candidate);
				if (id) return id;
			}
			return "";
		}
		if (value && typeof value === "object") {
			return String(value.translatorID || value.id || "").toLowerCase();
		}
		return String(value || "").toLowerCase();
	}

	function delegateChoices(type) {
		return supportedDelegateTypes.has(type) && Array.isArray(delegateMap[type])
			? delegateMap[type] : [];
	}

	function lightweightSearchItem(search, Item) {
		const source = search && typeof search === "object" ? search : {};
		const item = new Item(source.itemType || "journalArticle");
		item.DOI = source.DOI || source.doi || targetDOI || "";
		for (const field of ["ISBN", "ISSN", "PMID", "arXiv", "arXivID", "reportNumber"]) {
			if (source[field] != null) item[field] = source[field];
		}
		item.title = source.title || "";
		item.url = source.url || source.URL || payload.url || "";
		if (pdfLikeURL(item.url)) {
			item.attachments.push({url: item.url, title: "Full Text PDF", mimeType: "application/pdf"});
		}
		return item;
	}

	function makeEnvironment(onComplete, state) {
		class Item {
			constructor(itemType) {
				this.itemType = itemType || "journalArticle";
				this.creators = [];
				this.tags = [];
				this.attachments = [];
				this.notes = [];
				this.seeAlso = [];
			}
			complete() { onComplete(this); }
		}

		function loadTranslator(type) {
			type = String(type || "").toLowerCase();
			let translatorID = "";
			let translatorDocument = document;
			let translatorString = "";
			let search = null;
			const handlers = {};
			function rdfImportObject() {
				const statements = [];
				const exported = {
					Zotero: {
						RDF: {
							addStatement(subject, predicate, object, literal) {
								statements.push({subject, predicate, object, literal});
							},
						},
					},
					defaultUnknownType: false,
					itemType: "",
					getNodes() {
						return Array.from(new Set(statements.map(statement => statement.subject)));
					},
					detectType() {
						return this.itemType || this.defaultUnknownType || "webpage";
					},
					doImport() {
						const itemType = this.itemType || this.defaultUnknownType || "webpage";
						nestedComplete(new Item(itemType));
					},
				};
				return exported;
			}
			const loader = {
				setTranslator(value) { translatorID = translatorIDFrom(value); },
				setDocument(value) { translatorDocument = value || document; },
				setString(value) { translatorString = String(value || ""); },
				setSearch(value) { search = value; },
				setHandler(name, handler) { handlers[name] = handler; },
				setTranslatorProvider() {},
				getTranslators() {
					const list = delegateChoices(type);
					if (handlers.translators) handlers.translators(loader, list);
					return Promise.resolve(list);
				},
				getTranslatorObject(callback) {
					// Important web translators call doImport() on BibTeX/RIS instead
					// of translate(). Import source stays out of the browser bundle, so
					// expose our PDF-path parser with the configuration hooks they use.
					const exported = type === "import" && translatorID === rdfTranslatorID
						? rdfImportObject()
						: type === "import" ? {
						setKeywordSplitOnSpace() {},
						setKeywordDelimRe() {},
						doImport() {
							nestedComplete(Object.assign(
								new Item("journalArticle"), parseImport(translatorString)
							));
						},
					} : buildAdapter(translatorID, nestedComplete, state).exported;
					if (callback) callback(exported);
					return exported;
				},
				translate() {
					const operation = (async () => {
						if (!supportedDelegateTypes.has(type)) {
							throw new Error(`unsupported translator delegate type: ${type}`);
						}
						if (type === "import") {
							nestedComplete(Object.assign(new Item("journalArticle"), parseImport(translatorString)));
							if (handlers.done) handlers.done(loader, true);
							return;
						}
						if (!translatorID) {
							translatorID = translatorIDFrom(delegateChoices(type)[0]);
						}
						const selected = delegateChoices(type).find(
							candidate => translatorIDFrom(candidate) === translatorID
						);
						if (type === "search" && !(selected && selected.pdfCapable && adapterMap.has(translatorID))) {
							// Crossref/DOI/PubMed-style delegates enrich bibliographic
							// data only. Preserve the parent hook without spending the
							// item deadline on a network lookup that cannot yield a PDF.
							nestedComplete(lightweightSearchItem(search, Item));
						}
						else {
							await executeDelegate(
								translatorID, type, translatorDocument, search, nestedComplete, state
							);
						}
						if (handlers.done) handlers.done(loader, true);
					})();
					return track(operation);
				},
			};
			function nestedComplete(item) {
				item.complete = () => onComplete(item);
				if (handlers.itemDone) handlers.itemDone(loader, item);
				else onComplete(item);
			}
			return loader;
		}

		const Zotero = {
			Item,
			Utilities: ZU,
			loadTranslator,
			debug(value) { if (debug.length < 100) debug.push(String(value).slice(0, 500)); },
			selectItems(values, callback) {
				const selected = selectItems(values);
				if (callback) callback(selected);
				return Promise.resolve(selected);
			},
			done() {}, wait() {}, monitorDOMChanges() {}, setProgress() {},
			getOption() { return false; }, getHiddenPref() { return false; },
			getXML(value) { return new DOMParser().parseFromString(value, "text/xml"); },
			isBookmarklet: false, isServer: false,
		};
		return {Zotero, loadTranslator};
	}

	function buildAdapter(id, onComplete, state) {
		const adapter = adapterMap.get(translatorIDFrom(id));
		if (!adapter) throw new Error(`translator dependency not bundled: ${id}`);
		const environment = makeEnvironment(onComplete, state);
		const moduleExports = {};
		const suffix = `\nreturn {\n`
			+ `detectWeb: typeof detectWeb === 'function' ? detectWeb : null,\n`
			+ `doWeb: typeof doWeb === 'function' ? doWeb : null,\n`
			+ `doSearch: typeof doSearch === 'function' ? doSearch : null,\n`
			+ `exports: typeof exports === 'object' ? exports : {}\n};`;
		const factory = new Function(
			"Zotero", "ZU", "Z", "request", "requestText", "requestJSON",
			"requestDocument", "exports", "XPathResult", "attr", "text", "innerText",
			adapter.source + suffix
		);
		const exported = factory(
			environment.Zotero, ZU, environment.Zotero, request, requestText,
			requestJSON, requestDocument, moduleExports, XPathResult, attr, text, innerText
		);
		Object.assign(exported, exported.exports || {});
		return {adapter, exported};
	}

	async function executeDelegate(id, type, translatorDocument, search, onComplete, state) {
		id = translatorIDFrom(id);
		if (!id || !adapterMap.has(id)) throw new Error(`translator dependency not bundled: ${id}`);
		if (state.depth >= maxDelegateDepth) {
			throw new Error(`translator delegate depth exceeded at ${id}`);
		}
		if (state.active.has(id)) {
			throw new Error(`translator delegation cycle: ${id}`);
		}
		state.active.add(id);
		state.depth += 1;
		try {
			const built = buildAdapter(id, onComplete, state);
			if (type === "web" && built.exported.doWeb) {
				await withinDeadline(built.exported.doWeb(
					translatorDocument, translatorDocument.URL || payload.url
				));
			}
			else if (type === "search" && built.exported.doSearch) {
				await withinDeadline(built.exported.doSearch(search || {}));
			}
			else {
				throw new Error(`translator has no supported ${type} entry point: ${id}`);
			}
		}
		finally {
			state.depth -= 1;
			state.active.delete(id);
		}
	}

	function topLevelComplete(item) {
		if (!items.includes(item)) items.push(item);
	}

	try {
		const state = {
			active: new Set([translatorIDFrom(payload.rootID)]),
			depth: 0,
		};
		const built = buildAdapter(payload.rootID, topLevelComplete, state);
		let detected = true;
		if (built.exported.detectWeb) {
			try { detected = await withinDeadline(built.exported.detectWeb(document, payload.url)); }
			catch (error) { recordError(`detectWeb: ${error}`); detected = false; }
		}
		const generic = payload.rootID === "951c027d-74ac-47d4-a107-9c3069ab7b48";
		if ((detected || generic) && built.exported.doWeb) {
			await withinDeadline(built.exported.doWeb(document, payload.url));
		}
		else if (!detected) {
			return {detected: false, pdfs: [], errors, debug};
		}
		for (let pass = 0; pass < 20; pass++) {
			const count = tasks.length;
			await withinDeadline(Promise.allSettled(tasks.slice(0, count)));
			if (tasks.length === count) break;
		}
		await new Promise(resolve => setTimeout(resolve, 50));
	}
	catch (error) { recordError(error); }

	const pdfs = [];
	const seen = new Set();
	// Highwire metadata is the most common Zotero PDF signal. Keep this small
	// independent fallback so an adapter that only needs an unsupported metadata
	// import helper can still contribute its PDF without recreating Zotero RDF.
	for (const candidate of highwirePDFs) {
		if (!seen.has(candidate.url)) {
			seen.add(candidate.url);
			pdfs.push(candidate);
		}
	}
	for (const item of items) {
		for (const attachment of (item.attachments || [])) {
			let url = attachment && attachment.url;
			if (url && typeof url === "object" && url.href) url = url.href;
			if (typeof url !== "string" || !url.trim()) continue;
			try { url = new URL(url, payload.url || document.baseURI).href; }
			catch (e) { continue; }
			const mimeType = String(attachment.mimeType || attachment.contentType || "");
			const title = String(attachment.title || "");
			const lowerURL = url.toLowerCase();
			const looksPDF = /pdf/i.test(mimeType) || /pdf|full\s*text/i.test(title)
				|| /\.pdf(?:$|[?#])|\/pdf(?:$|[/?#])|\/epdf(?:$|[/?#])|pdfft|downloadpdf/i.test(lowerURL);
			if (!looksPDF || seen.has(url)) continue;
			seen.add(url);
			pdfs.push({url, title, mimeType});
		}
	}
	return {detected: true, pdfs, errors, debug};
}
