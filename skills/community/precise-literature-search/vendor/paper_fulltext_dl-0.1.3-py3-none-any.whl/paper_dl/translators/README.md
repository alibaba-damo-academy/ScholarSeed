# Repository-owned web translators

`adapters/` is generated one-to-one from every JavaScript file in
[`zotero/translators`](https://github.com/zotero/translators). The generated
adapter removes Zotero's non-JavaScript metadata preamble and test fixtures,
then stores the executable body and metadata in JSON. `runtime.js` supplies the
small Zotero API subset needed to recognize the current article and emit PDF
attachment URLs inside Patchright/Playwright.

The runtime intentionally does **not** create Zotero items, collections, or
snapshots. It keeps only attachments that look like a PDF. This makes the
translator library useful without Zotero Desktop or the Connector extension.

Dynamic `Zotero.loadTranslator()` delegation is deliberately PDF-oriented:

- `web` executes an explicitly referenced web dependency or Embedded Metadata;
- `import` extracts DOI, landing URLs, and PDF URLs locally from RIS, BibTeX,
  and simple JSON instead of running bibliographic import machinery; both
  `translate()` and the `getTranslatorObject().doImport()` form used by IEEE,
  Frontiers, Wiley, Nature, and Cambridge share this local bridge;
- metadata-only `search` calls receive a zero-network identifier item so the
  parent translator can add its known PDF. The generated manifest approves a
  search translator only when its executable source directly creates a PDF
  attachment **and** an upstream search test expects a primary-document PDF.

Supplementary files, supporting information, covers, and table-of-contents PDFs
are discarded before browser acquisition. The evidence and rejection reason for
every search translator live in its manifest row under `pdfSearchCapability`.
This deliberately rejects catalog/TOC PDFs and translators whose PDF depends on
Zotero import machinery that paper-dl does not execute.

## Bundled snapshot

The pinned adapters are part of the download runtime. The manifest records the
upstream revision and source hashes. The core distribution ships the generated
adapters and runtime only; source synchronization and maintenance commands are
not included. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for attribution
and the bundled license.
