# Optional user-installed web translators

User-installed adapters are generated one-to-one from every JavaScript file in
[`zotero/translators`](https://github.com/zotero/translators). The generated
adapter removes Zotero's non-JavaScript metadata preamble and test fixtures,
then stores the executable body and metadata in JSON. `runtime.js` supplies the
small Zotero API subset needed to recognize the current article and emit PDF
attachment URLs inside Patchright/Playwright.

No upstream translators or generated adapters ship with paper-dl. Normal CDP
downloads skip this step. Use `python -m paper_dl.translators.sync --source SOURCE
--output ADAPTERS` to convert a separately downloaded checkout, then supply
`paper-dl --translators-dir ADAPTERS` (or YAML `browser.translators_dir`). See the
[main guide](../../README.md#optional-user-installed-translators) for complete
download and conversion commands. `--no-translators` overrides the YAML path.
Only enable trusted source code; it runs in the active browser page.

`--zotero-save` and `--no-zotero` independently control the user's separately
installed Zotero Desktop/Connector fallback, not this runtime.

The runtime intentionally does **not** create Zotero items, collections, or
snapshots. It keeps only attachments that look like a PDF. This makes the
translator library useful without Zotero Desktop or the Connector extension.

Dynamic `Zotero.loadTranslator()` delegation is deliberately PDF-oriented:

- `web` executes an explicitly referenced web dependency or Embedded Metadata;
- `import` extracts DOI, landing URLs, and PDF URLs locally from RIS, BibTeX,
  and simple JSON instead of running bibliographic import machinery; both
  `translate()` and the `getTranslatorObject().doImport()` form used by IEEE,
  Frontiers, Wiley, Nature, and Cambridge share this local bridge;
- metadata-only `search` calls receive a zero-network identifier item so the
  parent translator can add its known PDF. The generated manifest approves a
  search translator only when its executable source directly creates a PDF
  attachment **and** an upstream search test expects a primary-document PDF.

Supplementary files, supporting information, covers, and table-of-contents PDFs
are discarded before browser acquisition. The evidence and rejection reason for
every search translator live in its manifest row under `pdfSearchCapability`.
This deliberately rejects catalog/TOC PDFs and translators whose PDF depends on
Zotero import machinery that paper-dl does not execute.

## Local snapshot

The manifest records the upstream revision and source hashes. The distribution
ships the converter and runtime, without a default adapter directory. Keep
generated files outside the project and do not commit or redistribute them as
part of paper-dl. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for licensing
information. Downloading separately does not relicense the translators.
