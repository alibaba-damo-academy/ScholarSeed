"""Deterministic review report for a proposed Zotero translator update."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


_SUPPORTED_ZOTERO_APIS = {
    "Item",
    "Utilities",
    "debug",
    "done",
    "getHiddenPref",
    "getOption",
    "getXML",
    "isBookmarklet",
    "isServer",
    "loadTranslator",
    "monitorDOMChanges",
    "selectItems",
    "setProgress",
    "wait",
}
_SUPPORTED_ZU_APIS = {
    "HTTP",
    "arrayDiff",
    "arrayUnique",
    "capitalizeName",
    "capitalizeTitle",
    "cleanAuthor",
    "cleanDOI",
    "cleanISBN",
    "cleanISSN",
    "cleanTags",
    "deepCopy",
    "doGet",
    "doPost",
    "ellipsize",
    "fieldIsValidForType",
    "getCreatorsForType",
    "getItemArray",
    "getPageRange",
    "itemTypeExists",
    "lpad",
    "processDocuments",
    "quotemeta",
    "removeDiacritics",
    "requestDocument",
    "requestJSON",
    "requestText",
    "resolveURL",
    "strToDate",
    "strToISO",
    "superCleanString",
    "trim",
    "trimInternal",
    "unescapeHTML",
    "xpath",
    "xpathText",
}
_API_RE = re.compile(r"\b(Zotero|ZU|Z)\.([A-Za-z_$][A-Za-z0-9_$]*)")
_COMPARE_FIELDS = (
    "label",
    "target",
    "translatorType",
    "priority",
    "browserSupport",
    "lastUpdated",
    "sourceSHA256",
    "dependencies",
    "pdfSearchCapability",
)
_APPROVAL_FIELDS = {
    "target",
    "translatorType",
    "priority",
    "browserSupport",
    "dependencies",
    "pdfSearchCapability",
}


def unsupported_runtime_apis(source: str) -> list[str]:
    """Return top-level Zotero/ZU APIs absent from the bundled runtime shim."""
    unsupported: set[str] = set()
    for namespace, name in _API_RE.findall(source):
        supported = _SUPPORTED_ZU_APIS if namespace == "ZU" else _SUPPORTED_ZOTERO_APIS
        if name not in supported:
            unsupported.add(f"{namespace}.{name}")
    return sorted(unsupported)


def _load_manifest(adapter_dir: Path) -> dict[str, Any]:
    return json.loads((adapter_dir / "manifest.json").read_text(encoding="utf-8"))


def _rows(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        str(row["translatorID"]).lower(): row
        for row in manifest.get("adapters", [])
    }


def _adapter_source(adapter_dir: Path, row: dict[str, Any]) -> str:
    path = adapter_dir / str(row.get("adapterFile", ""))
    if not path.is_file():
        return ""
    return str(json.loads(path.read_text(encoding="utf-8")).get("source", ""))


def compare_adapter_directories(current_dir: Path, proposed_dir: Path) -> dict[str, Any]:
    """Compare generated adapter trees without mutating either directory."""
    current_manifest = _load_manifest(current_dir)
    proposed_manifest = _load_manifest(proposed_dir)
    current = _rows(current_manifest)
    proposed = _rows(proposed_manifest)
    added_ids = sorted(proposed.keys() - current.keys())
    removed_ids = sorted(current.keys() - proposed.keys())
    changed: list[dict[str, Any]] = []
    approval_reasons: list[str] = []

    if added_ids:
        approval_reasons.append("translator-added")
    if removed_ids:
        approval_reasons.append("translator-removed")

    for translator_id in sorted(current.keys() & proposed.keys()):
        before = current[translator_id]
        after = proposed[translator_id]
        fields = [field for field in _COMPARE_FIELDS if before.get(field) != after.get(field)]
        if not fields:
            continue
        before_unsupported = set(
            unsupported_runtime_apis(_adapter_source(current_dir, before))
        )
        unsupported = unsupported_runtime_apis(_adapter_source(proposed_dir, after))
        new_unsupported = sorted(set(unsupported) - before_unsupported)
        changed.append({
            "translatorID": translator_id,
            "label": after.get("label", translator_id),
            "changedFields": fields,
            "unsupportedRuntimeAPIs": unsupported,
            "newUnsupportedRuntimeAPIs": new_unsupported,
        })
        if _APPROVAL_FIELDS.intersection(fields):
            approval_reasons.append(f"capability-metadata-changed:{translator_id}")
        if new_unsupported:
            approval_reasons.append(f"unsupported-runtime-api:{translator_id}")

    added: list[dict[str, Any]] = []
    for translator_id in added_ids:
        row = proposed[translator_id]
        unsupported = unsupported_runtime_apis(_adapter_source(proposed_dir, row))
        added.append({
            "translatorID": translator_id,
            "label": row.get("label", translator_id),
            "unsupportedRuntimeAPIs": unsupported,
        })
        if unsupported:
            approval_reasons.append(f"unsupported-runtime-api:{translator_id}")

    return {
        "schemaVersion": 1,
        "currentRevision": current_manifest.get("upstreamRevision"),
        "proposedRevision": proposed_manifest.get("upstreamRevision"),
        "currentTranslatorCount": current_manifest.get("translatorCount", len(current)),
        "proposedTranslatorCount": proposed_manifest.get("translatorCount", len(proposed)),
        "currentCapabilityDigest": current_manifest.get("pdfSearchCapabilityDigest"),
        "proposedCapabilityDigest": proposed_manifest.get("pdfSearchCapabilityDigest"),
        "added": added,
        "removed": [
            {"translatorID": translator_id, "label": current[translator_id].get("label", translator_id)}
            for translator_id in removed_ids
        ],
        "changed": changed,
        "approvalRequired": bool(approval_reasons),
        "approvalReasons": sorted(set(approval_reasons)),
    }


def render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Zotero translator update audit",
        "",
        f"- Current revision: `{report.get('currentRevision')}`",
        f"- Proposed revision: `{report.get('proposedRevision')}`",
        f"- Translators: {report.get('currentTranslatorCount')} → {report.get('proposedTranslatorCount')}",
        f"- Human approval required: **{'yes' if report.get('approvalRequired') else 'no'}**",
        "",
    ]
    for title, key in (("Added", "added"), ("Removed", "removed"), ("Changed", "changed")):
        rows = report.get(key) or []
        lines.append(f"## {title} ({len(rows)})")
        lines.append("")
        if not rows:
            lines.append("- None")
        for row in rows:
            detail = ", ".join(row.get("changedFields", []))
            unsupported = ", ".join(row.get("unsupportedRuntimeAPIs", []))
            suffix = f" — {detail}" if detail else ""
            if unsupported:
                suffix += f"; unsupported runtime APIs: {unsupported}"
            lines.append(f"- `{row['translatorID']}` {row.get('label', '')}{suffix}")
        lines.append("")
    if report.get("approvalReasons"):
        lines.extend(["## Approval reasons", ""])
        lines.extend(f"- {reason}" for reason in report["approvalReasons"])
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"
