"""Select and execute user-installed web translators in a live browser page."""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Optional
from urllib.parse import unquote, urlsplit, urlunsplit

from ..discovery import is_supplement_url


RUNTIME_PATH = Path(__file__).with_name("runtime.js")
EMBEDDED_METADATA_ID = "951c027d-74ac-47d4-a107-9c3069ab7b48"
RIS_ID = "32d59d2d-b65a-4da4-b0a3-bdd3cfb979e7"
BIBTEX_ID = "9cb70025-a888-4a29-a210-93ec52da40d4"

TYPE_BITS = {"import": 1, "web": 4, "search": 8}
SEARCH_STUB_ID = "__paper_dl_search_stub__"
_SUPPLEMENT_ATTACHMENT_TITLE_RE = re.compile(
    r"\b(?:supplement(?:ary|al)?|supporting\s+(?:information|material)"
    r"|table\s+of\s+contents|\btoc\b|cover)\b",
    flags=re.IGNORECASE,
)
_PRIMARY_ATTACHMENT_TITLE_RE = re.compile(
    r"\b(?:full\s*text|article|main|preprint)\b", flags=re.IGNORECASE
)


def _normalize_pdf_candidate_url(url: str) -> str:
    """Repair deterministic publisher URL variants emitted by translators."""
    try:
        parts = urlsplit(url)
    except ValueError:
        return url
    if parts.hostname and parts.hostname.lower().endswith("sciencedirect.com"):
        path = re.sub(
            r"^/science/article/(?:abs|abstract)/pii/",
            "/science/article/pii/",
            parts.path,
            flags=re.IGNORECASE,
        )
        if path != parts.path:
            return urlunsplit(parts._replace(path=path))
    return url


@dataclass(frozen=True)
class PDFCandidate:
    url: str
    title: str = ""
    mime_type: str = ""
    translator: str = ""


@dataclass
class TranslationReport:
    candidates: list[PDFCandidate] = field(default_factory=list)
    attempted: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class TranslatorRegistry:
    """A deterministic registry compiled from ``zotero/translators``.

    Only web translators are selected at runtime. Import/export/search adapters
    remain in the user-converted directory so synchronization is one-to-one and delegated
    translators can be resolved, but paper-dl only retains PDF attachments.
    """

    def __init__(self, adapter_dir: Path):
        self.adapter_dir = Path(adapter_dir).expanduser().resolve()
        manifest_path = self.adapter_dir / "manifest.json"
        if not manifest_path.is_file():
            raise ValueError(
                "Translator manifest.json is missing. Download Zotero translators "
                "and convert them with python -m paper_dl.translators.sync "
                "--source SOURCE --output ADAPTERS, then use --translators-dir ADAPTERS. "
                "Use --no-translators to skip this optional step."
            )
        self.manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        self._rows = {
            row["translatorID"].lower(): row
            for row in self.manifest.get("adapters", [])
        }

    @property
    def count(self) -> int:
        return int(self.manifest.get("translatorCount", 0))

    @property
    def upstream_revision(self) -> str:
        return str(self.manifest.get("upstreamRevision", "unknown"))

    @staticmethod
    def _pdf_search_capable(row: dict[str, Any]) -> bool:
        capability = row.get("pdfSearchCapability")
        return (
            isinstance(capability, dict)
            and capability.get("decision") == "approved"
        )

    @staticmethod
    def _target_matches(target: str, url: str) -> bool:
        if not target:
            return False
        try:
            return re.search(target, url, flags=re.IGNORECASE) is not None
        except re.error:
            # Zotero targets use JavaScript regex syntax. Most are also valid in
            # Python; the few that are not are safely left to generic metadata.
            return False

    def matching(self, url: str, *, limit: int = 8) -> list[dict[str, Any]]:
        rows = [
            row for row in self._rows.values()
            if int(row.get("translatorType", 0)) & 4
            and self._target_matches(str(row.get("target", "")), url)
        ]
        rows.sort(key=lambda row: (int(row.get("priority", 1000)), row["label"]))
        rows = rows[:limit]
        generic = self._rows.get(EMBEDDED_METADATA_ID)
        if generic is not None and all(
            row["translatorID"] != EMBEDDED_METADATA_ID for row in rows
        ):
            rows.append(generic)
        return rows

    @lru_cache(maxsize=256)
    def _adapter(self, translator_id: str) -> dict[str, Any]:
        row = self._rows[translator_id.lower()]
        path = (self.adapter_dir / row["adapterFile"]).resolve()
        if not path.is_relative_to(self.adapter_dir):
            raise ValueError("Translator adapterFile must stay inside its adapter directory")
        return json.loads(
            path.read_text(encoding="utf-8")
        )

    def _delegate_catalog(self, translator_id: str) -> dict[str, list[dict[str, Any]]]:
        """Return small, type-aware choices for dynamic Zotero delegation.

        The full Zotero registry is deliberately *not* injected into every
        browser evaluation. Static UUID dependencies are retained as catalog
        choices; automatic web selection gets explicit dependencies plus generic
        metadata, while import/search only receive lightweight metadata
        choices. This is enough for common `getTranslators()` flows without
        turning a PDF lookup into a 748-translator metadata crawl.
        """
        root_id = translator_id.lower()
        direct: set[str] = set()
        visited: set[str] = set()

        def collect(current_id: str) -> None:
            current_id = current_id.lower()
            if current_id in visited or current_id not in self._rows:
                return
            visited.add(current_id)
            for dependency in self._adapter(current_id).get("dependencies", []):
                dependency = str(dependency).lower()
                if dependency in self._rows:
                    direct.add(dependency)
                    collect(dependency)

        collect(root_id)
        choices: dict[str, list[str]] = {
            # The root is already the best site-specific match. A nested
            # automatic web lookup should use one of its explicit web
            # dependencies or the generic Embedded Metadata translator, not a
            # second unrelated broad-target site translator.
            "web": [EMBEDDED_METADATA_ID],
            "import": [RIS_ID, BIBTEX_ID],
            "search": [],
        }
        for dependency in sorted(direct):
            row = self._rows[dependency]
            for name, bit in TYPE_BITS.items():
                if int(row.get("translatorType", 0)) & bit:
                    choices[name].insert(0, dependency)

        # PDF-producing search translators are few. Include their code only
        # when a parent explicitly declares one; automatic search is otherwise
        # satisfied by a DOI/URL item and never makes an irrelevant lookup.
        for dependency in sorted(direct):
            if (
                self._pdf_search_capable(self._rows[dependency])
                and dependency not in choices["search"]
            ):
                choices["search"].append(dependency)

        # getTranslators() consumers commonly select the first result. Prefer
        # executable primary-PDF search paths, then honor upstream priority;
        # generic Embedded Metadata remains the final web fallback.
        def delegate_order(name: str, identifier: str) -> tuple[Any, ...]:
            row = self._rows[identifier]
            return (
                name == "search" and not self._pdf_search_capable(row),
                name == "web" and identifier == EMBEDDED_METADATA_ID,
                int(row.get("priority", 1000)),
                str(row.get("label", identifier)).casefold(),
                identifier,
            )

        for name, identifiers in choices.items():
            identifiers[:] = [identifier for identifier in identifiers if identifier in self._rows]
            identifiers.sort(key=lambda identifier: delegate_order(name, identifier))

        def row_data(identifier: str) -> dict[str, Any]:
            row = self._rows[identifier]
            return {
                "translatorID": identifier,
                "label": row.get("label", identifier),
                "translatorType": int(row.get("translatorType", 0)),
                "priority": int(row.get("priority", 1000)),
                "pdfCapable": self._pdf_search_capable(row),
            }

        output: dict[str, list[dict[str, Any]]] = {}
        for name, identifiers in choices.items():
            seen: set[str] = set()
            output[name] = []
            for identifier in identifiers:
                if identifier not in self._rows or identifier in seen:
                    continue
                seen.add(identifier)
                output[name].append(row_data(identifier))
        if not output["search"]:
            # Dynamic search selection is often used only to obtain a DOI item
            # before the parent adds its own PDF attachment. Provide a local,
            # zero-network choice so that callback chain still runs.
            output["search"] = [{
                "translatorID": SEARCH_STUB_ID,
                "label": "PDF metadata bridge",
                "translatorType": TYPE_BITS["search"],
                "priority": 0,
                "pdfCapable": False,
            }]
        return output

    def _bundle(
        self, translator_id: str
    ) -> tuple[list[dict[str, Any]], dict[str, list[dict[str, Any]]]]:
        delegates = self._delegate_catalog(translator_id)
        output: list[dict[str, Any]] = []
        seen: set[str] = set()

        def add(current_id: str) -> None:
            current_id = current_id.lower()
            if current_id in seen or current_id not in self._rows:
                return
            seen.add(current_id)
            adapter = self._adapter(current_id)
            output.append(
                {
                    "id": current_id,
                    "metadata": adapter["metadata"],
                    "source": adapter["source"],
                }
            )

        add(translator_id)
        # Web translators commonly ask Zotero to auto-detect a delegate rather
        # than naming it. Embedded Metadata is our deterministic delegate.
        add(EMBEDDED_METADATA_ID)
        # Keep page.evaluate payloads small. Import/search dependencies are
        # represented by the catalog and handled by the PDF-only parser/stub;
        # only executable web delegates and search translators that can create
        # a PDF attachment themselves need their upstream source bundled.
        for delegate in delegates["web"]:
            add(delegate["translatorID"])
        for delegate in delegates["search"]:
            if delegate["pdfCapable"]:
                add(delegate["translatorID"])
        return output, delegates

    @staticmethod
    def _pdf_candidate_rank(candidate: PDFCandidate) -> int:
        """Rank only main-paper attachments ahead of otherwise neutral PDFs."""
        return 0 if _PRIMARY_ATTACHMENT_TITLE_RE.search(candidate.title) else 1

    def run(
        self,
        page,
        url: str,
        *,
        target_doi: Optional[str] = None,
        matching_url: Optional[str] = None,
        limit: int = 8,
        total_timeout_ms: int = 12_000,
    ) -> TranslationReport:
        report = TranslationReport()
        seen_urls: set[str] = set()
        runtime = RUNTIME_PATH.read_text(encoding="utf-8")
        deadline = time.monotonic() + max(0.001, total_timeout_ms / 1000)
        for row in self.matching(matching_url or url, limit=limit):
            remaining_ms = int((deadline - time.monotonic()) * 1000)
            if remaining_ms <= 0:
                report.errors.append("translator registry deadline exceeded")
                break
            label = str(row.get("label", row["translatorID"]))
            report.attempted.append(label)
            adapters, delegates = self._bundle(row["translatorID"])
            payload = {
                "rootID": row["translatorID"],
                "url": url,
                "targetDOI": target_doi or _doi_from_url(url) or "",
                "adapters": adapters,
                "delegates": delegates,
                "timeoutMs": min(5_000, remaining_ms),
                "totalTimeoutMs": remaining_ms,
            }
            try:
                result = page.evaluate(runtime, payload) or {}
            except Exception as exc:  # noqa: BLE001 - a broken adapter must not abort acquisition
                report.errors.append(f"{label}: {type(exc).__name__}: {exc}")
                continue
            for error in result.get("errors", []) or []:
                report.errors.append(f"{label}: {error}")
            for item in result.get("pdfs", []) or []:
                candidate_url = _normalize_pdf_candidate_url(
                    str(item.get("url", "")).strip()
                )
                title = str(item.get("title", "")).strip()
                # A Zotero translator may expose every attachment (including
                # ACS/Frontiers supplements) while paper-dl wants the article.
                # URL matching is authoritative; attachment titles add a
                # conservative guard for generic CDN names.
                if (
                    not candidate_url
                    or candidate_url in seen_urls
                    or is_supplement_url(candidate_url)
                    or _SUPPLEMENT_ATTACHMENT_TITLE_RE.search(title)
                ):
                    continue
                seen_urls.add(candidate_url)
                report.candidates.append(
                    PDFCandidate(
                        url=candidate_url,
                        title=title,
                        mime_type=str(item.get("mimeType", "")),
                        translator=label,
                    )
                )
            report.candidates.sort(key=self._pdf_candidate_rank)
            # Zotero chooses the first matching translator. Do the same after a
            # successful PDF extraction; generic metadata remains a fallback.
            if report.candidates:
                break
        return report


def _doi_from_url(url: str) -> Optional[str]:
    decoded = unquote(url)
    match = re.search(r"10\.\d{4,9}/[^\s?#]+", decoded, flags=re.IGNORECASE)
    if not match:
        return None
    return match.group(0).rstrip("/.,;)")
