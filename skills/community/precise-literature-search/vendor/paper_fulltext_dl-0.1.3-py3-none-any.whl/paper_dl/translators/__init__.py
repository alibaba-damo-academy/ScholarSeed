"""Optional runtime for user-installed Zotero-compatible web translators."""

from .engine import PDFCandidate, TranslationReport, TranslatorRegistry

__all__ = [
    "PDFCandidate",
    "TranslationReport",
    "TranslatorRegistry",
]
