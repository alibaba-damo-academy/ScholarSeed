"""Repository-owned Zotero-compatible web translator runtime."""

from .engine import PDFCandidate, TranslationReport, TranslatorRegistry

__all__ = [
    "PDFCandidate",
    "TranslationReport",
    "TranslatorRegistry",
]
