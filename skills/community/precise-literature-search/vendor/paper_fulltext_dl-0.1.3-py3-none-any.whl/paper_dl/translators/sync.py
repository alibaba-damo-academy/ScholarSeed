#!/usr/bin/env python3
"""Compile a Zotero translators checkout into paper-dl adapter bundles.

The upstream files are not directly executable JavaScript: each starts with a
bare JSON metadata object and usually ends with Zotero-only test fixtures.  This
script turns every ``*.js`` file into one deterministic JSON adapter containing
the metadata and executable body.  The original source is never rewritten.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path


TEST_MARKER = "/** BEGIN TEST CASES **/"
UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)
NON_PRIMARY_PDF_TITLE_RE = re.compile(
    r"\b(?:supplement(?:ary|al)?|supporting\s+(?:information|material)"
    r"|table\s+of\s+contents|toc|cover)\b",
    flags=re.IGNORECASE,
)
PRIMARY_PDF_TITLE_RE = re.compile(
    r"\b(?:full\s*text|article|main|preprint|submitted\s+version)\b",
    flags=re.IGNORECASE,
)
PDF_ATTACHMENT_SOURCE_RE = re.compile(
    r"attachments(?:\s*=|\.push\s*\()[\s\S]{0,800}?"
    r"mimeType\s*:\s*['\"]application/pdf['\"]",
    flags=re.IGNORECASE,
)


def split_translator(path: Path) -> tuple[dict, str]:
    raw = path.read_text(encoding="utf-8-sig")
    start = len(raw) - len(raw.lstrip())
    metadata, end = json.JSONDecoder().raw_decode(raw, start)
    source = raw[end:].lstrip("\r\n")
    if TEST_MARKER in source:
        source = source.split(TEST_MARKER, 1)[0].rstrip() + "\n"
    return metadata, source


def _test_cases(raw: str) -> list[dict]:
    """Parse upstream's JSON-compatible test fixture array conservatively."""
    if TEST_MARKER not in raw:
        return []
    fixture_source = raw.split(TEST_MARKER, 1)[1]
    start = fixture_source.find("[")
    end = fixture_source.rfind("]")
    if start < 0 or end < start:
        return []
    try:
        value = json.loads(fixture_source[start:end + 1])
    except (TypeError, ValueError):
        # An unparsable upstream fixture must never silently approve network
        # code. The manifest will expose that the translator is unverified.
        return []
    return [case for case in value if isinstance(case, dict)]


def pdf_search_capability(metadata: dict, source: str, raw: str) -> dict | None:
    """Return auditable, conservative evidence for a search translator.

    Approval requires two independent upstream signals: the executable source
    directly constructs a PDF attachment, and a search test fixture expects a
    primary-document PDF. This excludes metadata-only services, catalog/TOC
    PDFs, and translators whose PDF is created by unsupported import machinery.
    """
    if not int(metadata.get("translatorType", 0)) & 8:
        return None

    source_creates_pdf = PDF_ATTACHMENT_SOURCE_RE.search(source) is not None
    search_case_count = 0
    primary_titles: set[str] = set()
    non_primary_titles: set[str] = set()
    ambiguous_titles: set[str] = set()
    for case in _test_cases(raw):
        if case.get("type") != "search":
            continue
        search_case_count += 1
        items = case.get("items")
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            attachments = item.get("attachments")
            if not isinstance(attachments, list):
                continue
            for attachment in attachments:
                if not isinstance(attachment, dict):
                    continue
                if str(attachment.get("mimeType", "")).lower() != "application/pdf":
                    continue
                title = str(attachment.get("title", "")).strip()
                if NON_PRIMARY_PDF_TITLE_RE.search(title):
                    non_primary_titles.add(title or "(untitled)")
                elif PRIMARY_PDF_TITLE_RE.search(title):
                    primary_titles.add(title)
                else:
                    ambiguous_titles.add(title or "(untitled)")

    if source_creates_pdf and primary_titles:
        decision = "approved"
        reason = "source-and-search-tests-confirm-primary-pdf"
    elif non_primary_titles and not primary_titles:
        decision = "rejected"
        reason = "search-tests-only-confirm-non-primary-pdf"
    elif primary_titles and not source_creates_pdf:
        decision = "rejected"
        reason = "primary-pdf-requires-unsupported-delegate"
    elif source_creates_pdf:
        decision = "unverified"
        reason = "source-pdf-has-no-primary-search-test"
    else:
        decision = "rejected"
        reason = "no-direct-primary-pdf-evidence"

    return {
        "decision": decision,
        "reason": reason,
        "sourceCreatesPDFAttachment": source_creates_pdf,
        "searchTestCaseCount": search_case_count,
        "primaryPDFTitles": sorted(primary_titles),
        "nonPrimaryPDFTitles": sorted(non_primary_titles),
        "ambiguousPDFTitles": sorted(ambiguous_titles),
    }


def pdf_search_capability_digest(manifest_rows: list[dict]) -> str:
    """Fingerprint all search evidence and source SHAs for an approval gate."""
    evidence = [
        {
            "translatorID": row["translatorID"],
            "sourceSHA256": row["sourceSHA256"],
            **row["pdfSearchCapability"],
        }
        for row in manifest_rows
        if "pdfSearchCapability" in row
    ]
    return hashlib.sha256(
        json.dumps(
            evidence,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()


def source_revision(source_dir: Path, override: str | None = None) -> str:
    if override:
        revision = override.strip()
        if re.fullmatch(r"[0-9a-fA-F]{40}", revision):
            return revision.lower()
        raise ValueError("--revision must be a full 40-character git revision")
    revision_file = source_dir / "REVISION"
    if revision_file.is_file():
        revision = revision_file.read_text(encoding="utf-8").strip()
        if re.fullmatch(r"[0-9a-fA-F]{40}", revision):
            return revision.lower()
        raise ValueError(f"{revision_file}: expected a full 40-character git revision")
    # Never let git walk up to paper-dl's own repository and accidentally record
    # its HEAD as Zotero's revision. Only an actual source checkout is trusted.
    if not (source_dir / ".git").exists():
        raise ValueError(
            f"{source_dir}: no REVISION file or local .git checkout; "
            "pass --revision explicitly"
        )
    try:
        result = subprocess.run(
            ["git", "-C", str(source_dir), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip()
    except (OSError, subprocess.CalledProcessError) as exc:
        raise ValueError(f"could not determine Zotero source revision: {exc}") from exc


def compile_all(source_dir: Path, output_dir: Path, revision: str) -> dict:
    if output_dir.is_symlink():
        raise ValueError("Output must not be a symlink")
    source_dir, output_dir = source_dir.resolve(), output_dir.resolve()
    if source_dir.is_relative_to(output_dir) or output_dir.is_relative_to(source_dir):
        raise ValueError("Source and output directories must not overlap")
    source_files = sorted(source_dir.glob("*.js"), key=lambda p: p.name.casefold())
    if not source_files:
        raise ValueError(f"{source_dir}: no translator .js files found")
    # This is a user-facing converter: never replace an arbitrary user directory.
    if output_dir.exists() and any(output_dir.iterdir()):
        manifest_path = output_dir / "manifest.json"
        if not manifest_path.is_file():
            raise ValueError("Non-empty output must be a previously generated adapter directory")
        previous = json.loads(manifest_path.read_text(encoding="utf-8"))
        if previous.get("upstream") != "https://github.com/zotero/translators":
            raise ValueError("Output is not a generated Zotero adapter directory")
        expected = {"manifest.json"} | {
            row["adapterFile"] for row in previous["adapters"]
        }
        if any(p.name not in expected or not p.is_file() for p in output_dir.iterdir()):
            raise ValueError("Output contains unrelated files; choose a dedicated adapter directory")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=f".{output_dir.name}-", dir=output_dir.parent))

    try:
        manifest_rows: list[dict] = []
        for path in source_files:
            raw = path.read_text(encoding="utf-8-sig")
            metadata, source = split_translator(path)
            translator_id = metadata.get("translatorID")
            if not isinstance(translator_id, str) or not translator_id.strip():
                raise ValueError(f"{path.name}: missing or invalid translatorID")
            dependencies = sorted(
                value.lower()
                for value in set(UUID_RE.findall(source))
                if value.lower() != translator_id.lower()
            )
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            # A handful of long-lived upstream translators have historical IDs that
            # are not well-formed UUIDs. Preserve the exact ID for delegation while
            # using a filesystem-safe, collision-resistant adapter name.
            safe_id = re.sub(r"[^0-9a-z-]+", "-", translator_id.lower()).strip("-")
            adapter_name = f"{safe_id}-{digest[:12]}.json"
            adapter = {
                "schemaVersion": 1,
                "sourceFile": path.name,
                "sourceSHA256": digest,
                "metadata": metadata,
                "dependencies": dependencies,
                "source": source,
            }
            (temporary / adapter_name).write_text(
                json.dumps(adapter, ensure_ascii=False, separators=(",", ":")) + "\n",
                encoding="utf-8",
            )
            capability = pdf_search_capability(metadata, source, raw)
            row = {
                "translatorID": translator_id.lower(),
                "label": metadata.get("label", path.stem),
                "target": metadata.get("target", ""),
                "translatorType": metadata.get("translatorType", 0),
                "priority": metadata.get("priority", 1000),
                "browserSupport": metadata.get("browserSupport", ""),
                "lastUpdated": metadata.get("lastUpdated", ""),
                "sourceFile": path.name,
                "adapterFile": adapter_name,
                "sourceSHA256": digest,
                "dependencies": dependencies,
            }
            if capability is not None:
                row["pdfSearchCapability"] = capability
            manifest_rows.append(row)

        search_capability_rows = [
            row["pdfSearchCapability"]
            for row in manifest_rows
            if "pdfSearchCapability" in row
        ]

        manifest = {
            "schemaVersion": 2,
            "upstream": "https://github.com/zotero/translators",
            "upstreamRevision": revision,
            "translatorCount": len(manifest_rows),
            "webTranslatorCount": sum(
                1 for row in manifest_rows if int(row["translatorType"]) & 4
            ),
            "pdfSearchCapabilityDigest": pdf_search_capability_digest(manifest_rows),
            "pdfSearchApprovedCount": sum(
                row["decision"] == "approved" for row in search_capability_rows
            ),
            "adapters": manifest_rows,
        }
        (temporary / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

        if output_dir.exists():
            shutil.rmtree(output_dir)
        temporary.rename(output_dir)
        return manifest
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source",
        type=Path,
        required=True,
        help="Zotero translators checkout",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="dedicated local adapter directory (outside the package)",
    )
    parser.add_argument("--revision", help="override the recorded upstream revision")
    args = parser.parse_args()
    try:
        source_dir, output_dir = args.source.expanduser(), args.output.expanduser()
        revision = source_revision(source_dir, args.revision)
        manifest = compile_all(source_dir, output_dir, revision)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    print(
        f"compiled {manifest['translatorCount']} translators "
        f"({manifest['webTranslatorCount']} web, "
        f"{manifest['pdfSearchApprovedCount']} PDF search approved) at {revision}"
    )


if __name__ == "__main__":
    main()
