# Third-party notices

paper-dl does not distribute Zotero translator source files or generated
adapters. Users may separately obtain trusted source files from
[Zotero translators](https://github.com/zotero/translators) and convert them
locally using `python -m paper_dl.translators.sync`. Each local bundle records
the upstream revision in its `manifest.json`; individual source files retain
their copyright and license headers inside the generated adapter JSON.

The GNU Affero General Public License version 3 text is retained for reference at
`paper_dl/translators/LICENSES/AGPL-3.0.txt`; the canonical text is also
available from the
[Free Software Foundation](https://www.gnu.org/licenses/agpl-3.0.html).

Check each upstream file's terms; not every translator has the same license.
Local conversion does not change those terms. Separate downloading and optional
loading alone do not establish license compatibility for a combined work.
