# Third-party notices

The generated adapters in this directory are derived from the
[Zotero translators](https://github.com/zotero/translators) project at the
revision recorded in `adapters/manifest.json`. Individual upstream source files
retain their copyright and license headers inside the generated adapter JSON.

The GNU Affero General Public License version 3 is distributed in wheels as
`paper_dl/translators/LICENSES/AGPL-3.0.txt`; the canonical text is also
available from the
[Free Software Foundation](https://www.gnu.org/licenses/agpl-3.0.html).
