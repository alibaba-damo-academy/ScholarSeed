"""Find PDF links inside an HTML landing page.

Scholarly pages almost always advertise their PDF via a ``citation_pdf_url``
meta tag (the Highwire / Google Scholar convention). We try that first, then
fall back to publisher-specific and generic link heuristics.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from .publishers.catalog import publisher_for_host
from .publishers.registry import get_publisher_adapter


def _abs(base: str, href: str) -> str:
    return urljoin(base, href.strip())


# Links that are SUPPLEMENTARY material, not the article itself. Publishers host
# these on the same CDN (and JAMA's are public even when the article is paywalled),
# so a naive ".pdf" match grabs them — yielding the wrong file. We never treat one
# as the main PDF. Conservative: needs an explicit supplement word or `supp<digit>`
# so it won't match "support", "supplier", etc.
_SUPPLEMENT_RE = re.compile(
    r"(supp\d"                              # supp1, supp2  (JAMA: ...supp1...)
    r"|suppl(?:ement|\b|[-_/.])"            # suppl/ suppl. supplement supplementary supplemental
    r"|supporting[-_ ]?info(?:rmation)?"
    r"|[-_]s\d{1,2}\.pdf"                   # foo-s1.pdf, fig_s2.pdf
    r"|/appendix\b)", re.I)

# Issue furniture is a PDF, but it is not the requested research article.  AMS
# issue pages in particular can put ``*-print-matter.pdf`` before every article
# link, which used to make the first structurally valid PDF win.
_NON_ARTICLE_PDF_RE = re.compile(
    r"(?:^|[/_.-])(?:"
    r"print[-_ ]?matter|front[-_ ]?matter|back[-_ ]?matter|"
    r"table[-_ ]?of[-_ ]?contents|contents|toc|masthead|editorial[-_ ]?board|"
    r"issue[-_ ]?information|cover"
    r")(?:[/_.?#-]|$)",
    re.I,
)


def is_supplement_url(url: str) -> bool:
    """True if the URL points at supplementary material rather than the article."""
    return bool(url and _SUPPLEMENT_RE.search(url))


def is_non_article_pdf_url(url: str) -> bool:
    """True for issue-level PDF furniture that cannot be a primary article."""
    return bool(url and _NON_ARTICLE_PDF_RE.search(url))


def find_pdf_links(html: str, base_url: str, publisher: str | None = None,
                   target_doi: str | None = None) -> list[str]:
    """Return an ordered, de-duplicated list of candidate PDF URLs."""
    soup = BeautifulSoup(html, "lxml")
    out: list[str] = []

    def add(u: str | None) -> None:
        if not u:
            return
        u = u.strip()
        if not u or u.startswith("javascript:"):
            return
        if is_supplement_url(u):     # never offer a supplement as the article PDF
            return
        if is_non_article_pdf_url(u):
            return
        if u not in out:
            out.append(u)

    # 1) citation_pdf_url meta (the gold standard for scholarly pages). LWW /
    #    Wolters Kluwer advertise theirs as wkhealth_pdf_url (-> downloadpdf.aspx).
    for meta in soup.find_all("meta"):
        name = (meta.get("name") or meta.get("property") or "").lower()
        if name in ("citation_pdf_url", "wkhealth_pdf_url"):
            add(_abs(base_url, meta.get("content", "")))

    # A citation PDF is the publisher's explicit primary-document declaration.
    # Do not dilute it with every other .pdf linked from the article body: figure
    # downloads and cited external reports are common and can consume the whole
    # item deadline (or, worse, be mistaken for the requested paper). If this
    # endpoint later fails, the browser engine still has translator, network,
    # and click fallbacks; those are safer than speculative body links.
    if out:
        return out

    # Issue/index pages can contain dozens of articles.  When the requested DOI
    # is visible, restrict discovery to the smallest ancestor that contains both
    # that DOI and a PDF link.  This is how AMS volume pages expose the selected
    # article while also rendering current-volume and early-view furniture.
    if target_doi:
        wanted = target_doi.strip().lower()
        for text_node in soup.find_all(string=True):
            if wanted not in str(text_node).lower():
                continue
            parent = text_node.parent
            for _depth in range(6):
                if parent is None:
                    break
                contextual: list[str] = []
                for anchor in parent.find_all("a", href=True):
                    label = anchor.get_text(" ", strip=True)
                    href = anchor.get("href", "")
                    # Require a PDF-control label here. Reference lists often
                    # contain external *.pdf URLs inside the target article's
                    # container; their URL suffix alone is not primary-document
                    # evidence.
                    if re.search(
                        r"^(?:download(?:\s+article)?\s*)?pdf$|^article\s+pdf$",
                        " ".join(label.split()),
                        re.I,
                    ):
                        absolute = _abs(base_url, href)
                        if (not is_supplement_url(absolute)
                                and not is_non_article_pdf_url(absolute)):
                            contextual.append(absolute)
                if contextual:
                    for url in contextual:
                        add(url)
                    return out
                parent = parent.parent

    # 2) <link rel="alternate" type="application/pdf">
    for link in soup.find_all("link"):
        if (link.get("type") or "").lower() == "application/pdf":
            add(_abs(base_url, link.get("href", "")))

    # 3) Publisher-specific maintenance adapter. Generic discovery remains the
    # fallback, and adapters only add evidence/URLs; they never classify failure.
    host = urlparse(base_url).netloc.lower()
    adapter_key = publisher or publisher_for_host(host)
    if adapter_key is None and "ieee" in host:
        # Preserve the legacy proxy-host heuristic; explicit publisher identity
        # and catalog host matching remain preferred.
        adapter_key = "ieee"
    adapter = get_publisher_adapter(adapter_key)
    if adapter is not None and adapter.discover_pdf_urls is not None:
        for url in adapter.discover_pdf_urls(html, base_url, target_doi):
            add(url)

    if publisher == "ams" or host.endswith("ams.org"):
        # pubs.ams.org renders the selected article alongside whole-volume and
        # early-view lists.  The final article route embeds the AMS article key;
        # its primary PDF uses the same path/key on www.ams.org.
        path = urlparse(base_url).path.rstrip("/")
        key_match = re.search(r"/(S[0-9A-Z-]+)$", path, re.I)
        if key_match and "/journals/" in path:
            key = key_match.group(1)
            add(f"https://www.ams.org{path}/{key}.pdf")
            if out:
                return out

    if publisher == "sciencedirect" or "sciencedirect" in host:
        # ScienceDirect's SPA no longer consistently exposes its PDF control as
        # an ordinary anchor or citation_pdf_url.  The article PII in the
        # canonical landing path is sufficient to address the publisher's
        # document endpoint, which then mints the session-bound asset URL (or
        # opens Chrome's PDF viewer).  Preserve the current host so EZproxy
        # rewritten ScienceDirect URLs continue through the proxy.
        pii_path = re.search(
            r"(/science/article/pii/[^/?#]+)", urlparse(base_url).path, re.I
        )
        if pii_path:
            add(urljoin(
                base_url,
                f"{pii_path.group(1).rstrip('/')}/pdfft"
                "?isDTMRedir=true&download=true",
            ))

    # 4) Generic anchors that look like PDFs
    pdf_like = re.compile(r"(\.pdf($|\?))|(/pdf/)|(stamp\.jsp)|(getPDF)|(/doi/pdf/)|(/doi/epdf/)|(type=printable)", re.I)
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if pdf_like.search(href):
            add(_abs(base_url, href))
    # 5) iframe / embed sources (PDF viewers)
    for tag in soup.find_all(["iframe", "embed"]):
        src = tag.get("src")
        if src and pdf_like.search(src):
            add(_abs(base_url, src))

    return out


_PAYWALL_HINTS = re.compile(
    r"(get access|purchase|buy article|subscribe|sign in to|institutional access|"
    r"access through your|rent this article|add to cart|\$\s?\d{2,})",
    re.I,
)
_BLOCK_HINTS = re.compile(
    r"(verify you are human|are you a robot|captcha|cloudflare|attention required|"
    r"unusual traffic|access denied|request blocked|enable javascript and cookies)",
    re.I,
)
# A landing page that says the requested paper/DOI simply does not exist (a dead
# DOI, a removed article, a publisher "page not found"). Deliberately CONSERVATIVE:
# we match the unambiguous phrases doi.org / publishers use, never a bare
# "not found" that could occur inside a real article. Used to report NOT_FOUND
# instead of a vague "no PDF link" when an identifier resolves to no paper.
_NOT_FOUND_HINTS = re.compile(
    r"("
    r"doi not found"                                        # doi.org's "Error: DOI Not Found"
    r"|404\s*[-:|–—]?\s*(error|not[ -]?found|page not found)"  # "404 Not Found", "404 - Page not found"
    r"|page not found"
    r"|article not found"
    r"|not found on this server"
    # Scope grammatical "... was/could not be found" wording to the requested
    # publication/page.  Searching a full article body for a bare phrase such as
    # "was not found" produces false positives whenever the scientific prose says
    # that an enzyme, gene, association, etc. was not found.
    r"|(?:article|page|paper|content|resource|record|doi|document|url)"
    r"(?:\s+you\s+requested)?\s+"
    r"(?:could\s*not|couldn'?t|cannot|can'?t|was\s+not|were\s+not|has\s+not\s+been)"
    r"\s+(?:be\s+)?found"
    r"|this (article|page|content) (is|was|has been) (no longer|not) (available|found|published)"
    r"|the requested (url|page|article|resource) .{0,60}?(was )?not found"
    r")",
    re.I,
)


def looks_paywalled(html: str) -> bool:
    return bool(_PAYWALL_HINTS.search(html or ""))


# High-confidence institutional-authentication evidence. A bare "Institutional
# access" navigation link is intentionally insufficient: many fully accessible
# pages show one in their global header. In addition to explicit SSO wording, the
# detector accepts terse publisher gates only when the caller confirms that PDF
# acquisition has already failed.
_INSTITUTION_ACTION_RE = re.compile(
    r"(access|sign(?:ing)?|log(?:ging)?)[ -]?(in|on)?\s*"
    r"(through|via|with|using)?\s*(your\s+)?(?:institution|organi[sz]ation)"
    r"|(?:institutional|organi[sz]ational)\s+"
    r"(sign[ -]?in|log[ -]?in|access)"
    r"|(select|find|choose)\s+(your\s+)?(?:institution|organi[sz]ation)"
    r"|(?:through|via|with)\s+(?:your\s+)?(?:institution|organi[sz]ation)"
    r"|openathens|shibboleth",
    re.I,
)
_CONTENT_ACCESS_GATE_RE = re.compile(
    r"(to\s+(read|view|access|download)\s+(this|the)\s+(article|content|paper|full\s*text))"
    r"|((?:check\s+)?access\s+(?:to\s+)?(?:this|the)\s+"
    r"(?:article|content|paper|full\s+(?:text|article)))"
    r"|(you\s+(do\s+not|don't)\s+have\s+access)"
    r"|(access\s+(is\s+)?required)"
    r"|(get\s+access|purchase\s+(?:(?:this\s+)?article|access|pdf)"
    r"|subscribe\s+to\s+access)"
    r"|(authentication\s+(is\s+)?required)",
    re.I,
)
_DIRECT_INSTITUTION_GATE_RE = re.compile(
    r"to\s+(?:read|view|access|download)\s+(?:this|the)\s+"
    r"(?:article|content|paper|full\s*text).{0,160}"
    r"(?:sign|log)[ -]?(?:in|on).{0,80}institution"
    r"|(?:sign|log)[ -]?(?:in|on).{0,80}institution.{0,160}"
    r"to\s+(?:read|view|access|download)\s+(?:this|the)\s+"
    r"(?:article|content|paper|full\s*text)",
    re.I,
)
_FAILED_ACQUISITION_GATE_RE = re.compile(
    r"\bget\s+access\b"
    r"|\brestricted\s+access\b"
    r"|\baccess\s+(?:to\s+(?:this|the)\s+)?(?:article|content|paper|full\s*text)\s+"
    r"(?:is\s+)?restricted\b"
    r"|\byou\s+(?:do\s+not|don't)\s+currently\s+have\s+access\s+to\s+"
    r"(?:this|the)\s+(?:article|content|paper|full\s*text)\b",
    re.I,
)
_EXPLICIT_ACCESS_DENIAL_RE = re.compile(
    r"\byou\s+(?:do\s+not|don't)\s+currently\s+have\s+access\s+to\s+"
    r"(?:this|the)\s+(?:article|content|paper|full\s*text)\b"
    r"|\baccess\s+to\s+(?:this|the)\s+(?:article|content|paper|full\s*text)\s+"
    r"(?:is\s+)?restricted\b",
    re.I,
)
_AUTH_PORTAL_LABEL_RE = re.compile(
    r"^(?:get\s+)?access$|^sign[ -]?in$|^log[ -]?in$|^institutional\s+access$"
    r"|^access\s+(?:through|via|with)\s+(?:your\s+)?"
    r"(?:institution|organi[sz]ation)$",
    re.I,
)
_AUTH_PORTAL_HREF_RE = re.compile(
    r"(?:^|/)(?:access|auth|login|log-in|signin|sign-in|sso|ssostart|"
    r"institutional[-_]?signin)(?:[/?#]|$)"
    r"|/(?:action/ssostart|account/institutionalsignin)(?:[/?#]|$)",
    re.I,
)


def _is_auth_portal_control(label: object, href: object) -> bool:
    normalized_label = " ".join(str(label or "").split())
    return bool(
        _AUTH_PORTAL_LABEL_RE.fullmatch(normalized_label)
        and _AUTH_PORTAL_HREF_RE.search(str(href or ""))
    )


def _has_auth_portal_control(
    soup: BeautifulSoup,
    rendered_controls: Iterable[tuple[object, object]],
) -> bool:
    """Return whether markup or rendered shadow DOM exposes an auth control."""
    controls = (
        (control.get_text(" ", strip=True), control.get("href"))
        for control in soup.find_all(("a", "button"))
    )
    return any(
        _is_auth_portal_control(label, href)
        for label, href in (*controls, *rendered_controls)
    )


def looks_institution_login_required(
    html: str,
    final_url: str = "",
    *,
    acquisition_failed: bool = False,
    pdf_access_failed: bool = False,
    rendered_controls: Iterable[tuple[object, object]] = (),
) -> bool:
    """True only for strong evidence that institutional authentication is needed.

    A missing PDF alone remains insufficient. Once the caller confirms that the
    normal acquisition path failed, however, terse publisher states such as
    ``Get Access`` and ``Restricted access`` become meaningful. If a discovered
    PDF endpoint itself failed, an explicit access/auth portal control is also
    accepted; this covers JavaScript platforms whose article body has no gate
    sentence while preserving the accessible-page/header-link safeguard.
    """
    try:
        parsed = urlparse(final_url or "")
        host = (parsed.hostname or "").lower()
        path = (parsed.path or "").lower()
        query = (parsed.query or "").lower()
    except Exception:
        host = path = query = ""
    if ("openathens" in host or "shibboleth" in host
            or "/shibboleth.sso/" in path or "/institutional-login" in path
            or "/institution-login" in path
            or "/account/institutionalsignin" in path
            or "/action/ssostart" in path
            or "samlrequest=" in query or "entityid=" in query):
        return True
    soup = BeautifulSoup(html or "", "lxml")
    text = soup.get_text(" ", strip=True)
    rendered_controls = tuple(rendered_controls)
    # JS-heavy publishers often render the access panel inside an open shadow
    # root.  Playwright can read those controls even though page.content() cannot.
    # Only merge their labels after acquisition failed: global header controls
    # must not turn an otherwise accessible landing page into an early login gate.
    diagnostic_text = text
    if acquisition_failed and rendered_controls:
        rendered_labels = " ".join(
            " ".join(str(label or "").split())
            for label, _href in rendered_controls
            if str(label or "").strip()
        )
        if rendered_labels:
            diagnostic_text = f"{text} {rendered_labels}"
    institution_action = _INSTITUTION_ACTION_RE.search(diagnostic_text)
    direct_gate = _DIRECT_INSTITUTION_GATE_RE.search(diagnostic_text)
    explicit_denial = _EXPLICIT_ACCESS_DENIAL_RE.search(diagnostic_text)
    failed_gate = _FAILED_ACQUISITION_GATE_RE.search(diagnostic_text)
    if institution_action and (direct_gate or explicit_denial):
        return True
    if (acquisition_failed and institution_action
            and _CONTENT_ACCESS_GATE_RE.search(diagnostic_text)):
        return True
    if acquisition_failed and failed_gate:
        return True
    return bool(
        pdf_access_failed
        and _has_auth_portal_control(soup, rendered_controls)
    )


def looks_blocked(html: str) -> bool:
    return bool(_BLOCK_HINTS.search(html or ""))


def looks_not_found(html: str, title: str | None = None) -> bool:
    """True if the page indicates the identifier resolves to no paper — a
    "DOI Not Found" / 404 / "article not found" page. Conservative by design so a
    real article is never mistaken for a missing one; the page title (short and
    publisher-controlled) is searched alongside the body."""
    hay = (title or "") + "\n" + (html or "")
    return bool(_NOT_FOUND_HINTS.search(hay))


def extract_title(html: str) -> str | None:
    soup = BeautifulSoup(html, "lxml")
    for meta in soup.find_all("meta"):
        name = (meta.get("name") or meta.get("property") or "").lower()
        if name in ("citation_title", "dc.title", "og:title"):
            c = meta.get("content")
            if c:
                return c.strip()
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return None
