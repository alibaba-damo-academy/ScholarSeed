"""Publisher identity catalog and optional maintenance adapters."""

from .catalog import PUBLISHERS, publisher_for_host, publisher_for_prefix, publisher_spec
from .contracts import PublisherAdapter, PublisherSpec

__all__ = [
    "PUBLISHERS",
    "PublisherAdapter",
    "PublisherSpec",
    "publisher_for_host",
    "publisher_for_prefix",
    "publisher_spec",
]
