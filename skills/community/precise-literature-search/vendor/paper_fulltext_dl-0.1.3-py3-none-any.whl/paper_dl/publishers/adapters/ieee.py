"""IEEE candidate planning, PDF discovery, and authenticated browser flow."""

from __future__ import annotations

import re
from typing import Optional
from urllib.parse import urljoin

from ...acquisition.contracts import Candidate
from ...config import ServiceConfig


def build_candidates(doi: str, _config: ServiceConfig) -> list[Candidate]:
    landing = f"https://doi.org/{doi}"
    return [
        Candidate(
            landing_url=landing,
            pdf_url=None,
            method="browser",
            label="ieee-doi-discover",
            publisher="ieee",
            needs_discovery=True,
        )
    ]


def discover_pdf_urls(
    html: str, base_url: str, _target_doi: Optional[str] = None
) -> list[str]:
    match = re.search(r"/document/(\d+)", base_url) or re.search(
        r"arnumber=(\d+)", base_url
    )
    if not match:
        match = re.search(r'"articleNumber"\s*:\s*"?(\d+)', html)
    if not match:
        return []
    arnumber = match.group(1)
    return [
        f"https://ieeexplore.ieee.org/stampPDF/getPDF.jsp?tp=&arnumber={arnumber}",
        f"https://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber={arnumber}",
    ]


def run_browser_flow(
    engine,
    *,
    page,
    final_url: str,
    html: str,
    referer: Optional[str],
) -> Optional[bytes]:
    """Follow IEEE's stamp viewer using the authenticated browser session."""
    match = re.search(r"/document/(\d+)", final_url or "") or re.search(
        r"arnumber=(\d+)", final_url or ""
    )
    if not match and html:
        match = re.search(r'"articleNumber"\s*:\s*"?(\d+)', html) or re.search(
            r"/document/(\d+)", html
        )
    if not match:
        return None

    arnumber = match.group(1)
    stamp_url = (
        "https://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=" + arnumber
    )
    try:
        from ...http_fallback import apply_ezproxy

        page.goto(
            apply_ezproxy(stamp_url, engine.cfg),
            wait_until="domcontentloaded",
        )
        engine._sleep()
        engine._pass_challenge(page)
        stamp_html = page.content()
    except Exception:
        stamp_html = ""

    if stamp_html:
        # Local import avoids making generic discovery depend on browser code.
        from ...discovery import find_pdf_links

        candidates = find_pdf_links(
            stamp_html,
            page.url if page else stamp_url,
            "ieee",
        )
    else:
        candidates = []
    embedded = re.search(
        r'(?:src|data)="([^"]*ielx[^"]*\.pdf[^"]*)"',
        stamp_html or "",
        re.I,
    )
    if embedded:
        candidates.insert(0, urljoin(page.url, embedded.group(1)))

    pdf_candidates: list[str] = []
    for url in candidates:
        if url != stamp_url and url not in pdf_candidates:
            pdf_candidates.append(url)

    live_referer = getattr(page, "url", None) or stamp_url
    for url in pdf_candidates:
        data = engine._request_pdf(url, stamp_url)
        if data:
            return data
    for url in pdf_candidates:
        data = engine._fetch_in_page(page, url)
        if data:
            return data
    if pdf_candidates:
        engine.log("    IEEE PDF requires document navigation; trying capture")
        data = engine._navigate_capture_pdf(
            pdf_candidates[:2], wait_ms=12_000, referer=live_referer
        )
        if data:
            return data
    return engine._request_pdf(stamp_url, referer)
