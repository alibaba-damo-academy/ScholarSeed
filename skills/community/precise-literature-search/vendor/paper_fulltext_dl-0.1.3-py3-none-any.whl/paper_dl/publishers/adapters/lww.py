"""Wolters Kluwer/LWW OAKS candidate, discovery, and browser flow."""

from __future__ import annotations

import re
from typing import Optional
from urllib.parse import urljoin, urlparse

from ...acquisition.contracts import Candidate
from ...config import ServiceConfig


def build_candidates(doi: str, _config: ServiceConfig) -> list[Candidate]:
    return [
        Candidate(
            landing_url=f"https://doi.org/{doi}",
            pdf_url=None,
            method="browser",
            label="lww-doi-discover",
            publisher="lww",
            needs_discovery=True,
        )
    ]


def discover_pdf_urls(
    html: str, base_url: str, _target_doi: Optional[str] = None
) -> list[str]:
    match = re.search(
        r'["\']([^"\']*oaks\.journals/downloadpdf\.aspx[^"\']*)',
        html,
        re.I,
    ) or re.search(
        r'(https?://[^"\'\s<>]*downloadpdf\.aspx[^"\'\s<>]*)',
        html,
        re.I,
    )
    if match:
        return [urljoin(base_url, match.group(1).replace("&amp;", "&"))]

    accession = re.search(r"\b(\d{8}-\d{9}-\d{5})\b", html)
    parsed = urlparse(base_url)
    segment = parsed.path.lstrip("/").split("/", 1)[0]
    if accession and segment and "lww.com" in parsed.netloc.lower():
        return [
            f"https://journals.lww.com/{segment}/_layouts/15/oaks.journals/"
            "downloadpdf.aspx?trckng_src_pg=ArticleViewer&an="
            + accession.group(1)
        ]
    return []


def run_browser_flow(
    engine,
    *,
    page,
    final_url: str,
    html: str,
    referer: Optional[str],
) -> Optional[bytes]:
    """Wait for the OAKS interstitial to mint its tokenized PDF."""
    del final_url, referer
    try:
        page.wait_for_load_state("domcontentloaded", timeout=8000)
    except Exception:
        pass
    try:
        live = page.content()
    except Exception:
        live = ""

    urls: list[str] = []
    seen: set[str] = set()

    def add(url: Optional[str]) -> None:
        if not url:
            return
        normalized = url.replace("&amp;", "&").strip()
        if "downloadpdf.aspx" in normalized.lower() and normalized not in seen:
            seen.add(normalized)
            urls.append(normalized)

    for selector in (
        'meta[name="wkhealth_pdf_url"]',
        'meta[name="citation_pdf_url"]',
        "[data-pdf-url]",
        "a#downloadPdfLink",
    ):
        try:
            locator = page.locator(selector).first
            if locator.count() == 0:
                continue
            add(
                locator.get_attribute("content")
                or locator.get_attribute("data-pdf-url")
                or locator.get_attribute("href")
            )
        except Exception:
            continue

    from ...discovery import find_pdf_links

    for source in (live, html):
        for url in find_pdf_links(source or "", page.url, "lww"):
            add(url)

    engine.log(
        f"    LWW: live_dom={len(live)}B landing_html={len(html or '')}B "
        f"-> {len(urls)} download endpoint(s)"
    )
    if not urls:
        engine.log(
            "    LWW: no downloadpdf.aspx endpoint in the page DOM — likely a "
            "bot challenge / cookie wall is up, or this isn't the article page. "
            "Re-run --max-stealth and solve any challenge; then it should appear."
        )
        return None
    engine.log(
        f"    LWW: navigating {urls[0]} (waiting up to "
        f"{int(engine.cfg.browser.download_wait_s)}s for the interstitial PDF)"
    )
    return engine._navigate_capture_pdf(
        urls[:2],
        wait_ms=int(engine.cfg.browser.download_wait_s * 1000),
        referer=page.url,
    )
