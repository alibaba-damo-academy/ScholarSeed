"""Single source of truth for publisher identity and download routing."""

from __future__ import annotations

from types import MappingProxyType

from .contracts import PublisherSpec


# Publisher hosts and DOI prefixes used for download resolution.
PUBLISHERS: tuple[PublisherSpec, ...] = (
    PublisherSpec("ieee", "IEEE Xplore", "10.1109/TWC.2022.3170576",
                  ("ieeexplore.ieee.org",), ("10.1109",), ("xplore",), bespoke=True),
    PublisherSpec("sciencedirect", "ScienceDirect / Elsevier", "10.1016/j.jfineco.2013.08.005",
                  ("sciencedirect.com", "linkinghub.elsevier.com"), ("10.1016", "10.1006"),
                  ("elsevier",), bespoke=True),
    PublisherSpec("springerlink", "SpringerLink", "10.1007/s10549-020-05747-7",
                  ("link.springer.com",), ("10.1007", "10.1208"), ("springer",)),
    PublisherSpec("nature", "Nature", "10.1038/nmat1849",
                  ("nature.com",), ("10.1038",), ("nature.com",), bespoke=True),
    PublisherSpec("science", "Science / AAAS", "10.1126/science.1233606",
                  ("science.org",), ("10.1126",), ("aaas", "science.org")),
    PublisherSpec("wiley", "Wiley Online Library", "10.1002/acs.4036",
                  ("onlinelibrary.wiley.com",), ("10.1002", "10.1111", "10.1155"),
                  ("wiley-online-library",)),
    PublisherSpec("taylor-francis", "Taylor & Francis Online", "10.1080/00927872.2024.2419478",
                  ("tandfonline.com",), ("10.1080", "10.2217", "10.4161"),
                  ("tandf", "tandfonline", "taylorandfrancis")),
    PublisherSpec("sage", "SAGE Journals", "10.5547/01956574.36.1.7",
                  ("journals.sagepub.com", "sage.cnpereading.com"), ("10.1177", "10.5547"),
                  ("sage-journals",)),
    PublisherSpec("acm", "ACM Digital Library", "10.1145/3290605.3300233",
                  ("dl.acm.org",), ("10.1145",), ("acm-dl",)),
    PublisherSpec("jstor", "JSTOR", "10.2307/1864376",
                  ("jstor.org",), ("10.2307",), bespoke=True),
    PublisherSpec("oxford", "Oxford Academic", "10.2527/asasmw.2017.008",
                  ("academic.oup.com",), ("10.1093", "10.2527"), ("oup",)),
    PublisherSpec("cambridge", "Cambridge Core", "10.1017/S0033291712001900",
                  ("cambridge.org",), ("10.1017",), ("cambridge-core",)),
    PublisherSpec("acs", "ACS Publications", "10.1021/jacs.5c01455",
                  ("pubs.acs.org",), ("10.1021",), ("american-chemical-society",)),
    PublisherSpec("aps", "APS Journals", "10.1103/PhysRevB.111.085423",
                  ("journals.aps.org", "link.aps.org"), ("10.1103",),
                  ("physical-review",), crossref_links=True, bespoke=True),
    PublisherSpec("aip", "AIP Publishing", "10.1063/5.0119421",
                  ("pubs.aip.org",), ("10.1063",), ("aip-publishing",), crossref_links=True),
    PublisherSpec("siam", "SIAM Journals", "10.1137/080716542",
                  ("epubs.siam.org",), ("10.1137",), bespoke=True),
    PublisherSpec("rsc", "Royal Society of Chemistry", None,
                  ("pubs.rsc.org",), ("10.1039",)),
    PublisherSpec("iop", "IOP Publishing", None,
                  ("iopscience.iop.org",), ("10.1088",), crossref_links=True, bespoke=True),
    PublisherSpec("ametsoc", "American Meteorological Society", None,
                  ("journals.ametsoc.org",), ("10.1175",), bespoke=True),
    PublisherSpec("ams", "American Mathematical Society", None,
                  ("ams.org", "pubs.ams.org"), ("10.1090",), bespoke=True),
    PublisherSpec("annualreviews", "Annual Reviews", None,
                  ("annualreviews.org",), ("10.1146",), bespoke=True),
    PublisherSpec("plos", "PLOS", None,
                  ("journals.plos.org",), ("10.1371",), bespoke=True),
    PublisherSpec("dove", "Dove Medical Press", None,
                  ("dovepress.com",), ("10.2147",), bespoke=True),
    PublisherSpec("thieme", "Thieme", None,
                  ("thieme-connect.de",), ("10.1055",), bespoke=True),
    PublisherSpec("rupress", "Rockefeller University Press", None,
                  ("rupress.org",), ("10.1083",), crossref_links=True),
    PublisherSpec("bmj", "BMJ", None,
                  ("bmj.com",), ("10.1136",), crossref_links=True),
    PublisherSpec("degruyter", "De Gruyter", None,
                  ("degruyter.com",), ("10.1515",), crossref_links=True, bespoke=True),
    PublisherSpec("projecteuclid", "Project Euclid", None,
                  ("projecteuclid.org",), ("10.1214",)),
    PublisherSpec("pensoft", "Pensoft", None,
                  ("pensoft.net",), ("10.3897",), crossref_links=True, bespoke=True),
    PublisherSpec("copernicus", "Copernicus Publications", None,
                  ("copernicus.org",), ("10.5194",), bespoke=True),
    PublisherSpec("lww", "Wolters Kluwer / LWW", None,
                  ("journals.lww.com", "pdfs.journals.lww.com"), ("10.1097",), bespoke=True),
)


def _unique_index(attribute: str) -> dict[str, PublisherSpec]:
    index: dict[str, PublisherSpec] = {}
    for spec in PUBLISHERS:
        for raw in getattr(spec, attribute):
            value = str(raw).lower()
            if value in index:
                raise RuntimeError(
                    f"duplicate publisher {attribute} value {value!r}: "
                    f"{index[value].key} and {spec.key}"
                )
            index[value] = spec
    return index


_BY_KEY = {spec.key: spec for spec in PUBLISHERS}
if len(_BY_KEY) != len(PUBLISHERS):
    raise RuntimeError("duplicate publisher key in catalog")
_BY_PREFIX = _unique_index("doi_prefixes")

PUBLISHER_BY_KEY = MappingProxyType(_BY_KEY)
DOI_PREFIX_TO_KEY = MappingProxyType({key: spec.key for key, spec in _BY_PREFIX.items()})
CROSSREF_LINK_PUBLISHERS = frozenset(
    spec.key for spec in PUBLISHERS if spec.crossref_links
)
BESPOKE_PUBLISHERS = frozenset(spec.key for spec in PUBLISHERS if spec.bespoke)


def publisher_spec(key: str | None) -> PublisherSpec | None:
    return PUBLISHER_BY_KEY.get(str(key or "").lower())


def publisher_for_prefix(prefix: str) -> str | None:
    spec = _BY_PREFIX.get(prefix.lower())
    return spec.key if spec else None


def publisher_for_host(host: str) -> str | None:
    normalized = host.lower().strip(".").removeprefix("www.")
    for spec in PUBLISHERS:
        for candidate in spec.hosts:
            candidate = candidate.lower().strip(".").removeprefix("www.")
            if normalized == candidate or normalized.endswith("." + candidate):
                return spec.key
    return None
