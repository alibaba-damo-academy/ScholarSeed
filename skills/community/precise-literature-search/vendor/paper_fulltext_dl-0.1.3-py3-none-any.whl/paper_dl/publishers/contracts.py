"""Contracts for publisher identity and optional site-specific hooks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from ..acquisition.contracts import Candidate
from ..config import ServiceConfig


CandidateBuilder = Callable[[str, ServiceConfig], list[Candidate]]
PDFDiscoverer = Callable[[str, str, Optional[str]], list[str]]
BrowserFlow = Callable[..., Optional[bytes]]


@dataclass(frozen=True)
class PublisherSpec:
    key: str
    name: str
    representative_doi: Optional[str]
    hosts: tuple[str, ...]
    doi_prefixes: tuple[str, ...]
    aliases: tuple[str, ...] = ()
    crossref_links: bool = False
    bespoke: bool = False

    @property
    def url(self) -> str:
        return f"https://doi.org/{self.representative_doi or ''}"

    @property
    def match_keys(self) -> set[str]:
        return {
            f"publisher:{self.key}",
            *(f"doi-prefix:{prefix}" for prefix in self.doi_prefixes),
            *(f"host:{host}" for host in self.hosts),
        }


@dataclass(frozen=True)
class PublisherAdapter:
    """Optional hooks for behavior that cannot use generic acquisition paths."""

    key: str
    build_candidates: Optional[CandidateBuilder] = None
    discover_pdf_urls: Optional[PDFDiscoverer] = None
    run_browser_flow: Optional[BrowserFlow] = None
