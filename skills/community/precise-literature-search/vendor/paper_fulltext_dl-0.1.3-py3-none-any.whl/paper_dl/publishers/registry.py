"""Registry for reviewed publisher-specific maintenance hooks."""

from __future__ import annotations

from .adapters import ieee, lww
from .catalog import publisher_spec
from .contracts import PublisherAdapter


_ADAPTERS = {
    adapter.key: adapter
    for adapter in (
        PublisherAdapter(
            key="ieee",
            build_candidates=ieee.build_candidates,
            discover_pdf_urls=ieee.discover_pdf_urls,
            run_browser_flow=ieee.run_browser_flow,
        ),
        PublisherAdapter(
            key="lww",
            build_candidates=lww.build_candidates,
            discover_pdf_urls=lww.discover_pdf_urls,
            run_browser_flow=lww.run_browser_flow,
        ),
    )
}

if any(publisher_spec(key) is None for key in _ADAPTERS):
    raise RuntimeError("publisher adapter registered without a catalog entry")


def get_publisher_adapter(key: str | None) -> PublisherAdapter | None:
    return _ADAPTERS.get(str(key or "").lower())


def publisher_adapters() -> tuple[PublisherAdapter, ...]:
    return tuple(_ADAPTERS[key] for key in sorted(_ADAPTERS))
