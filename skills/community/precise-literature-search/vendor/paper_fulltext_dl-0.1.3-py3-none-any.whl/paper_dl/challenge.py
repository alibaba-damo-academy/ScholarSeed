"""Pluggable challenge / captcha-solving seam (extension point).

By default the engine stays completely **hands-off**: in a visible window it waits
for a human to solve a captcha (see :meth:`BrowserEngine._pass_challenge`). This
module defines an *optional* :class:`ChallengeSolver` interface so a future
automated solver — a captcha-solving service (2captcha / anti-captcha), a vision
model, a managed-challenge bypass, etc. — can be injected **without touching the
engine**. Wire one in via::

    PaperDownloadService(cfg, solver=MySolver())

When no solver is supplied, behavior is byte-for-byte the current human-assisted
wait. When one is supplied it gets first crack at a detected challenge; the engine
then re-verifies the wall is actually gone before continuing, and falls back to the
human wait if the solver declines, errors, or only claims success.

HARD CONTRACT for any solver (these mirror the engine's hard-won constraints):

* **Never enable Playwright request interception** (``context.route`` /
  ``page.route``). It fans ``Network.setCacheDisabled`` to every frame session and
  a teardown mid-flight crashes the Patchright/Playwright Node driver with an
  uncaught rejection Python cannot catch (the "v7" crash). A solver that routes
  requests will destabilize the whole engine.
* **Keep CDP traffic light** while the challenge's background checks run — heavy
  polling/automation can make Turnstile/DataDome flag the session and fail.
* **Do not raise** as a control-flow path; return ``False`` to decline. (The engine
  guards the call regardless.)
* Respect ``ChallengeContext.deadline_s`` as the time budget.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol, runtime_checkable


@dataclass
class ChallengeContext:
    """What a solver is told about the challenge it is asked to clear."""

    nav_status: Optional[int]   # landing HTTP status (403/429 => a hard bot wall)
    headless: bool              # interactive window available?
    deadline_s: float           # wall-clock budget the solver should respect
    final_url: str = ""         # the page the challenge is gating
    title: str = ""             # current page title (e.g. "Just a moment...")


@runtime_checkable
class ChallengeSolver(Protocol):
    """Implement this to plug in automated captcha / bot-wall solving.

    ``solve`` is invoked when the engine has detected a live challenge on ``page``.
    Return ``True`` only once you believe the challenge is cleared (the engine
    re-verifies the live DOM afterwards). Return ``False`` to decline and fall back
    to the default behavior. ``context`` is the Playwright persistent context (do
    NOT add routing to it). Must not raise.
    """

    def solve(self, page, context, ctx: ChallengeContext) -> bool:  # pragma: no cover - interface
        ...
