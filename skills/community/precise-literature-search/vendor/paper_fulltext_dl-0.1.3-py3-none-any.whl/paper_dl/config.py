"""Configuration for identifier resolution, downloading and local storage."""

from __future__ import annotations

import math
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


def _default_user_agent() -> str:
    """A Chrome UA whose OS token matches the host platform.

    Used ONLY on the bundled-Chromium fallback launch (patchright unavailable AND no
    real ``--channel``); with patchright or a real channel we never override the UA
    at all, since the genuine one is less detectable. Advertising a *Windows* UA on
    macOS/Linux is itself an inconsistency bot-detectors flag, so mirror the host.
    Chrome freezes the OS version (and reports "Intel Mac OS X 10_15_7" even on Apple
    Silicon), so these fixed tokens match a real Chrome."""
    if sys.platform == "darwin":
        os_token = "Macintosh; Intel Mac OS X 10_15_7"
    elif sys.platform.startswith("linux"):
        os_token = "X11; Linux x86_64"
    else:
        os_token = "Windows NT 10.0; Win64; x64"
    return (f"Mozilla/5.0 ({os_token}) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


@dataclass
class ZoteroConfig:
    """Configuration for the optional Zotero Connector fallback.

    When enabled, if standard download methods fail the tool triggers the Zotero
    Connector browser extension to save the paper, then retrieves the PDF from
    Zotero's local storage directory.

    The normal HTTP, optional-translator, and browser strategies always run first.
    Zotero is attempted only when those strategies do not produce a PDF.
    """
    enabled: bool = False
    base_url: str = "http://127.0.0.1:23119"
    collection_key: Optional[str] = None
    # Path to Zotero's data storage directory; defaults to ~/Zotero/storage.
    storage_dir: Optional[str] = None
    # Max time to wait for Zotero to finish saving (PDF download can be slow).
    save_timeout_s: float = 60.0
    # Interval between polls when waiting for the item to appear.
    poll_interval_s: float = 2.0
    # Fast-failure grace for the PDF wait. If Zotero has not registered a PDF
    # *attachment* on the saved item within this many seconds, the Connector did
    # a metadata-only save (paywalled / translator found no PDF) and no file will
    # ever land — give up now and fall back to the browser instead of polling the
    # full save_timeout_s. Once a PDF attachment IS registered we wait the full
    # budget for its file to finish downloading.
    pdf_grace_s: float = 16.0


@dataclass
class BrowserConfig:
    enabled: bool = True
    headless: bool = True
    # Persistent profile dir: log into your institution once here and the
    # session cookies (incl. Cloudflare cf_clearance) are reused for every later
    # download. Defaults to <storage>/.browser-profile if left None.
    user_data_dir: Optional[str] = None
    # Use a real installed browser channel ("chrome" / "msedge") instead of the
    # bundled Chromium. With a real channel + persistent profile we do NOT
    # override the user-agent (genuine UA/client-hints/TLS stay consistent, which
    # is *less* detectable than a spoofed UA).
    channel: Optional[str] = None
    # Spoof UA for the bundled-Chromium fallback only; matches the host OS so a
    # macOS/Linux run doesn't present a Windows UA (see _default_user_agent).
    user_agent: str = field(default_factory=_default_user_agent)
    # Prefer patchright (CDP-leak-patched Playwright) if installed; else playwright.
    prefer_patchright: bool = True
    # Attach to an already-running Chrome via its DevTools endpoint (e.g.
    # "http://localhost:9222") instead of LAUNCHING one. Start that Chrome yourself
    # with --remote-debugging-port + a dedicated profile to keep the login
    # session (cookies, login, any cf_clearance); the tool then drives that real
    # browser minimally and NEVER closes it — it only disconnects on teardown. When
    # set, channel / profile / stealth-launch are not used. CLI: --connect-cdp.
    cdp_endpoint: Optional[str] = None
    # Explicit opt-in to user-converted Zotero translators; never auto-discovered.
    translators_dir: Optional[str] = None
    locale: str = "en-US"
    # None uses the host timezone; CDP uses the attached browser's own settings.
    timezone_id: Optional[str] = None
    viewport_width: int = 1366
    viewport_height: int = 900
    proxy: Optional[str] = None                 # e.g. "http://user:pass@host:port"
    nav_timeout_ms: int = 35_000               # page navigation timeout
    pdf_request_timeout_ms: int = 60_000       # in-context PDF GET timeout
    challenge_wait_s: float = 25.0              # max wait for a Cloudflare challenge to clear (headless / non-interactive)
    challenge_human_wait_s: float = 180.0       # max wait for a HUMAN to solve a captcha in a visible window (we stay hands-off)
    download_wait_s: float = 35.0               # max wait for a click/interstitial to yield a file (e.g. LWW's ~11s "download will begin" page)
    keep_open: bool = False                     # retain the browser for inspection/retry until the caller closes it
    # human-like jitter between actions (seconds)
    min_delay_s: float = 0.4
    max_delay_s: float = 1.6
    # --- Institutional (EZproxy) access -------------------------------------
    # Two mutually-exclusive forms; hostname rewrite is preferred.
    #  * ezproxy_host: "ezproxy.lib.example.edu" -> www.nature.com becomes
    #    www-nature-com.ezproxy.lib.example.edu (dots->hyphens, path preserved).
    #  * ezproxy_prefix: "https://login.ezproxy.lib.example.edu/login?url=" (legacy).
    ezproxy_host: Optional[str] = None
    ezproxy_prefix: Optional[str] = None


@dataclass
class ServiceConfig:
    # where original full text and metadata live
    storage_dir: str = "library"
    # where the batch report.json is written
    output_dir: str = "out"
    # email used for the Unpaywall OA discovery API (polite-pool requirement)
    unpaywall_email: Optional[str] = None
    use_unpaywall: bool = True
    # Crossref exact-DOI metadata supplies canonical bibliographic evidence and
    # member-registered links. It is independent from alternate-version search.
    use_crossref_metadata: bool = True
    # OpenAlex supplies additional explicitly OA repository/publisher locations.
    use_openalex: bool = True
    # Strict title/author/year search for preprints and other versions.
    use_crossref_alternates: bool = True
    # Semantic Scholar fallback: finds an arXiv id / open-access PDF when
    # Unpaywall has none (e.g. a SIAM paper that lives free on arXiv). No key needed.
    use_semantic_scholar: bool = True
    # PubMed Central via NCBI id-conversion: the authoritative route to the free
    # full text for biomedical papers (e.g. a paywalled JAMA article whose NIH
    # copy is on PMC). No key needed.
    use_pmc: bool = True
    # Prefer verified open-access locations (including arXiv/repository copies)
    # before the publisher's version of record. Set this to True to opt back into
    # publisher-first ordering. Publisher-hosted OA versions remain OA candidates.
    prefer_published: bool = False
    # try a plain HTTP fetch before spinning up the browser for direct/OA URLs
    http_first: bool = True
    overwrite: bool = False           # re-download even if already in the library
    autodev: bool = False  # unattended batch mode: skip stuck publishers fast
    # Absolute wall-clock cap for one automated paper attempt, covering
    # resolution, HTTP, browser/captcha waits, validation, and
    # persistence. CLI: --paper-timeout. Kept under its original config key for
    # backward compatibility.
    per_request_timeout_s: float = 300.0
    # Read timeout for the plain-HTTP fetch (Tier 0 OA / direct downloads). This
    # is httpx's max gap BETWEEN bytes, not the total download time, so a tight
    # bound still lets a large PDF stream while stopping a stalled server from
    # burning the whole per-item budget. Effective value is capped by
    # per_request_timeout_s.
    http_timeout_s: float = 45.0
    retries: int = 2
    # polite delay between consecutive requests in a batch
    inter_request_delay_s: float = 2.0
    browser: BrowserConfig = field(default_factory=BrowserConfig)
    zotero: ZoteroConfig = field(default_factory=ZoteroConfig)

    # ---- loading helpers ---------------------------------------------------
    @classmethod
    def load(cls, path: Optional[str | Path] = None) -> "ServiceConfig":
        cfg = cls()
        if path:
            p = Path(path)
            data = yaml.safe_load(p.read_text(encoding="utf-8"))
            if data is None:
                data = {}
            if not isinstance(data, dict):
                raise ValueError("Configuration must be a YAML mapping")
            cfg = cls.from_dict(data)
        cfg._apply_env()
        return cfg

    @classmethod
    def from_dict(cls, data: dict) -> "ServiceConfig":
        if not isinstance(data, dict):
            raise ValueError("Configuration must be a YAML mapping")
        data = dict(data)
        browser_data = data.pop("browser", {})
        if browser_data is None:
            browser_data = {}
        if not isinstance(browser_data, dict):
            raise ValueError("browser configuration must be a mapping")
        browser = BrowserConfig(**browser_data)
        zotero_data = data.pop("zotero", {})
        if zotero_data is None:
            zotero_data = {}
        if not isinstance(zotero_data, dict):
            raise ValueError("zotero configuration must be a mapping")
        zotero = ZoteroConfig(**zotero_data)
        return cls(browser=browser, zotero=zotero, **data)

    def _apply_env(self) -> None:
        if v := os.getenv("PAPER_DL_STORAGE_DIR"):
            self.storage_dir = v
        if v := os.getenv("PAPER_DL_UNPAYWALL_EMAIL"):
            self.unpaywall_email = v
        if v := os.getenv("PAPER_DL_PROFILE"):
            self.browser.user_data_dir = v
        if v := os.getenv("PAPER_DL_PROXY"):
            self.browser.proxy = v
        if v := os.getenv("PAPER_DL_EZPROXY"):
            self.browser.ezproxy_prefix = v
        if v := os.getenv("PAPER_DL_EZPROXY_HOST"):
            self.browser.ezproxy_host = v
        if v := os.getenv("PAPER_DL_CHANNEL"):
            self.browser.channel = v
        if v := os.getenv("PAPER_DL_CDP_ENDPOINT"):
            self.browser.cdp_endpoint = v
        if v := os.getenv("PAPER_DL_PAPER_TIMEOUT_S"):
            try:
                timeout_s = float(v)
            except ValueError as exc:
                raise ValueError(
                    "PAPER_DL_PAPER_TIMEOUT_S must be a number greater than 0"
                ) from exc
            if not math.isfinite(timeout_s) or timeout_s <= 0.0:
                raise ValueError(
                    "PAPER_DL_PAPER_TIMEOUT_S must be a finite number greater than 0"
                )
            self.per_request_timeout_s = timeout_s
        if v := os.getenv("PAPER_DL_KEEP_OPEN"):
            self.browser.keep_open = v.lower() not in ("0", "false", "no")
        if v := os.getenv("PAPER_DL_HEADLESS"):
            self.browser.headless = v.lower() not in ("0", "false", "no")
        # Use the explicitly supplied fallback contact email if none is configured.
        if not self.unpaywall_email:
            self.unpaywall_email = os.getenv("PAPER_DL_EMAIL")

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir).expanduser().resolve()

    @property
    def output_path(self) -> Path:
        return Path(self.output_dir).expanduser().resolve()

    @property
    def browser_profile_path(self) -> Path:
        configured = self.browser.user_data_dir
        if configured:
            return Path(configured).expanduser().resolve()
        return (self.storage_path / ".browser-profile").resolve()
