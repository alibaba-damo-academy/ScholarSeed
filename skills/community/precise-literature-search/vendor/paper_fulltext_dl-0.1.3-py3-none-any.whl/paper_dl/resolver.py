"""Resolve a normalized Identifier into an ordered list of download candidates.

A candidate describes *where* and *how* to get the PDF. The browser/http engine
then executes them in order until one yields a valid PDF. Resolution is
publisher-aware (IEEE / SIAM / Nature) and augmented with DOI metadata and
open-access location providers.
"""

from __future__ import annotations

import math
from typing import Optional
from urllib.parse import quote, urlparse

from . import netclient
from .acquisition.contracts import (
    AlternateWork,
    Candidate,
    OpenAlexLocation,
    ResolvePlan,
    WorkMetadata,
)
from .config import ServiceConfig
from .models import Identifier, IdentifierKind
from .publishers.catalog import (
    BESPOKE_PUBLISHERS,
    CROSSREF_LINK_PUBLISHERS,
    DOI_PREFIX_TO_KEY,
    publisher_for_prefix,
)
from .publishers.registry import get_publisher_adapter
from .work_identity import author_overlap, matched_author_names, normalize_identity


# Compatibility aliases for callers/tests that inspect the historical indexes.
_PREFIX_PUBLISHER = DOI_PREFIX_TO_KEY
_CROSSREF_LINK_PUBLISHERS = CROSSREF_LINK_PUBLISHERS
_BESPOKE_PUBLISHERS = BESPOKE_PUBLISHERS


def publisher_for_doi(doi: str) -> Optional[str]:
    prefix = doi.split("/", 1)[0]
    return publisher_for_prefix(prefix)


def _arxiv_candidates(arxiv_id: str) -> list[Candidate]:
    base = arxiv_id
    abs_url = f"https://arxiv.org/abs/{base}"
    pdf_url = f"https://arxiv.org/pdf/{base}"
    return [
        Candidate(landing_url=abs_url, pdf_url=pdf_url, method="http",
                  label="arxiv-direct", publisher="arxiv", referer=abs_url,
                  open_access=True, discovery_sources=("arxiv",)),
        Candidate(landing_url=abs_url, pdf_url=pdf_url, method="browser",
                  label="arxiv-browser", publisher="arxiv", referer=abs_url,
                  open_access=True, discovery_sources=("arxiv",)),
    ]


def _siam_candidates(doi: str) -> list[Candidate]:
    # One browser candidate suffices: the engine navigates the landing page, tries
    # /doi/pdf, then discovers + clicks the PDF/ePDF button on that same page.
    landing = f"https://epubs.siam.org/doi/{doi}"
    pdf = f"https://epubs.siam.org/doi/pdf/{doi}?download=true"   # raw bytes (watermarked)
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="siam-pdf", publisher="siam", needs_discovery=True, referer=landing),
    ]


def _wiley_candidates(doi: str) -> list[Candidate]:
    """Deterministic Wiley article/PDF routes.

    Wiley's OIDC landing can render a journal shell without exposing its
    ``citation_pdf_url`` or PDF button to the live DOM. The stable ``/doi/pdf``
    document route works independently of that rendering; the browser engine
    already distinguishes a successful viewer from the entitlement redirect
    back to ``/doi/abs``.
    """
    landing = f"https://onlinelibrary.wiley.com/doi/abs/{doi}"
    pdf = f"https://onlinelibrary.wiley.com/doi/pdf/{doi}"
    return [
        Candidate(
            landing_url=landing,
            pdf_url=pdf,
            method="browser",
            label="wiley-pdf-browser",
            publisher="wiley",
            needs_discovery=True,
            referer=landing,
        ),
    ]


def _nature_candidates(doi: str) -> list[Candidate]:
    article_id = doi.split("/", 1)[1] if "/" in doi else doi
    landing = f"https://www.nature.com/articles/{article_id}"
    pdf = f"{landing}.pdf"
    # nature.com gates everything through an idp.nature.com cookie handshake; a
    # cookieless HTTP client can bypass the loop with ?error=cookies_not_supported.
    pdf_nocookie = f"{pdf}?error=cookies_not_supported"
    return [
        Candidate(landing_url=landing, pdf_url=pdf_nocookie, method="http",
                  label="nature-pdf-http", publisher="nature", referer=landing),
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="nature-pdf-browser", publisher="nature", needs_discovery=True, referer=landing),
    ]


def _jstor_candidates(doi: str) -> list[Candidate]:
    # JSTOR stable id is the DOI suffix (e.g. 10.2307/1864376 -> 1864376).
    sid = doi.split("/", 1)[1] if "/" in doi else doi
    landing = f"https://www.jstor.org/stable/{sid}"
    # acceptTC=true is what the "Accept and download" modal sets; on an entitled
    # session the in-page fetch of this URL gets the PDF without the modal.
    pdf = f"https://www.jstor.org/stable/pdf/{sid}.pdf?acceptTC=true"
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="jstor-pdf", publisher="jstor", needs_discovery=True, referer=landing),
    ]


def _aps_candidates(doi: str) -> list[Candidate]:
    landing = f"https://link.aps.org/doi/{doi}"
    pdf = f"https://link.aps.org/pdf/{doi}"
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="http",
                  label="aps-pdf-http", publisher="aps", referer=landing),
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="aps-pdf-browser", publisher="aps", needs_discovery=True,
                  referer=landing),
    ]


def _iop_candidates(doi: str) -> list[Candidate]:
    landing = f"https://iopscience.iop.org/article/{doi}"
    pdf = f"{landing}/pdf"
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="iop-pdf-browser", publisher="iop", needs_discovery=True,
                  referer=landing),
    ]


def _degruyter_candidates(doi: str) -> list[Candidate]:
    landing = f"https://www.degruyterbrill.com/document/doi/{doi}/html"
    pdf = f"https://www.degruyterbrill.com/document/doi/{doi}/pdf"
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="http",
                  label="degruyter-pdf-http", publisher="degruyter", referer=landing),
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="degruyter-pdf-browser", publisher="degruyter",
                  needs_discovery=True, referer=landing),
    ]


def _publisher_doi_candidate(doi: str, publisher: str) -> list[Candidate]:
    landing = f"https://doi.org/{doi}"
    return [Candidate(
        landing_url=landing, pdf_url=None, method="browser",
        label=f"{publisher}-doi-discover", publisher=publisher,
        needs_discovery=True,
    )]


def _plos_candidates(doi: str) -> list[Candidate]:
    journal_code = doi.lower().split("/", 1)[-1].split(".", 2)[1]
    journals = {
        "pbio": "plosbiology",
        "pone": "plosone",
        "pmed": "plosmedicine",
        "pcbi": "ploscompbiol",
        "pgen": "plosgenetics",
        "ppat": "plospathogens",
        "pntd": "plosntds",
    }
    journal = journals.get(journal_code)
    if not journal:
        return _publisher_doi_candidate(doi, "plos")
    landing = f"https://journals.plos.org/{journal}/article?id={doi}"
    pdf = f"https://journals.plos.org/{journal}/article/file?id={doi}&type=printable"
    return [
        Candidate(
            landing_url=landing, pdf_url=pdf, method="http",
            label="plos-pdf-http", publisher="plos", referer=landing,
            open_access=True, publisher_open_access=True,
        ),
        Candidate(
            landing_url=landing, pdf_url=pdf, method="browser",
            label="plos-pdf-browser", publisher="plos", referer=landing,
            needs_discovery=True, open_access=True, publisher_open_access=True,
        ),
    ]


def _annualreviews_candidates(doi: str) -> list[Candidate]:
    landing = f"https://www.annualreviews.org/content/journals/{doi}"
    pdf = f"https://www.annualreviews.org/doi/pdf/{doi}"
    return [Candidate(
        landing_url=landing, pdf_url=pdf, method="browser",
        label="annualreviews-pdf-browser", publisher="annualreviews",
        needs_discovery=True, referer=landing,
    )]


def _thieme_candidates(doi: str) -> list[Candidate]:
    escaped = quote(doi, safe="")
    landing = f"https://www.thieme-connect.de/products/ejournals/abstract/{doi}"
    pdf = f"https://www.thieme-connect.de/products/ejournals/pdf/{escaped}.pdf"
    return [Candidate(
        landing_url=landing, pdf_url=pdf, method="browser",
        label="thieme-pdf-browser", publisher="thieme",
        needs_discovery=True, referer=landing,
    )]


def _pensoft_candidates(doi: str) -> list[Candidate]:
    # Pensoft DOIs use <journal>.<volume>.e<article-id>.  The platform's stable
    # article and PDF paths do not require resolving doi.org first.
    suffix = doi.split("/", 1)[1] if "/" in doi else ""
    parts = suffix.rsplit(".", 1)
    if len(parts) != 2 or not parts[1].lower().startswith("e"):
        return _generic_doi_candidates(doi)
    journal = parts[0].split(".", 1)[0]
    article_id = parts[1][1:]
    if not journal or not article_id.isdigit():
        return _generic_doi_candidates(doi)
    landing = f"https://{journal}.pensoft.net/article/{article_id}/"
    pdf = f"{landing}download/pdf/"
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="http",
                  label="pensoft-pdf-http", publisher="pensoft", referer=landing,
                  open_access=True, publisher_open_access=True),
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="pensoft-pdf-browser", publisher="pensoft",
                  needs_discovery=True, referer=landing,
                  open_access=True, publisher_open_access=True),
    ]


def _copernicus_candidates(doi: str) -> list[Candidate]:
    """Construct Copernicus's stable OA article and static PDF URLs."""
    suffix = doi.split("/", 1)[1] if "/" in doi else ""
    parts = suffix.split("-")
    if len(parts) < 4 or not parts[-1].isdigit():
        return _generic_doi_candidates(doi)
    journal = parts[0].lower()
    volume, article, year = parts[-3:]
    if not journal.isalnum() or not all(p.isdigit() for p in (volume, article, year)):
        return _generic_doi_candidates(doi)
    landing = f"https://{journal}.copernicus.org/articles/{volume}/{article}/{year}/"
    pdf = f"{landing}{suffix}.pdf"
    return [
        Candidate(
            landing_url=landing, pdf_url=pdf, method="http",
            label="copernicus-pdf-http", publisher="copernicus", referer=landing,
            open_access=True, publisher_open_access=True,
        ),
        Candidate(
            landing_url=landing, pdf_url=pdf, method="browser",
            label="copernicus-pdf-browser", publisher="copernicus",
            needs_discovery=True, referer=landing,
            open_access=True, publisher_open_access=True,
        ),
    ]


def _legacy_elsevier_candidates(doi: str) -> Optional[list[Candidate]]:
    """Repair known IDEAL-era DOI metadata that points at a dead host.

    This article was registered as ``pest.2000.2530`` but the live article and
    bibliographic record use ``pest.2001.2530`` / PII S0048357501925301.
    Keep the alias deliberately exact rather than guessing corrections for other
    legacy Elsevier DOIs.
    """
    if doi.lower() not in {
        "10.1006/pest.2000.2530", "10.1006/pest.2001.2530",
    }:
        return None
    landing = "https://www.sciencedirect.com/science/article/pii/S0048357501925301"
    pdf = f"{landing}/pdfft?isDTMRedir=true&download=true"
    return [
        Candidate(landing_url=landing, pdf_url=pdf, method="http",
                  label="legacy-elsevier-pdf-http", publisher="sciencedirect",
                  referer=landing),
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="legacy-elsevier-pdf-browser", publisher="sciencedirect",
                  needs_discovery=True, referer=landing),
    ]


def _pmc_candidates(pmcid: str) -> list[Candidate]:
    """PubMed Central free full text, with a no-browser Europe PMC fast path."""
    pid = pmcid.upper()
    if not pid.startswith("PMC"):
        pid = "PMC" + pid
    landing = f"https://pmc.ncbi.nlm.nih.gov/articles/{pid}/"
    pdf = f"https://pmc.ncbi.nlm.nih.gov/articles/{pid}/pdf/"
    europe_pdf = f"https://europepmc.org/articles/{pid}?pdf=render"
    return [
        Candidate(
            landing_url=f"https://europepmc.org/articles/{pid}",
            pdf_url=europe_pdf,
            method="http",
            label="pmc-europe-oa-http",
            publisher="pmc",
            referer="https://europepmc.org/",
            open_access=True,
            discovery_sources=("pmc",),
        ),
        Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                  label="pmc-oa", publisher="pmc", needs_discovery=True,
                  referer=landing, open_access=True,
                  discovery_sources=("pmc",)),
    ]


def _generic_doi_candidates(doi: str, publisher: Optional[str] = None) -> list[Candidate]:
    landing = f"https://doi.org/{doi}"
    return [
        Candidate(landing_url=landing, pdf_url=None, method="browser",
                  label="doi-discover", publisher=publisher,
                  needs_discovery=True),
    ]


def _crossref_year(message: dict) -> Optional[int]:
    """Return Crossref's best available publication year."""
    for key in ("published-print", "published-online", "published", "issued"):
        date_value = message.get(key)
        if not isinstance(date_value, dict):
            continue
        parts = date_value.get("date-parts") or []
        if (not isinstance(parts, list) or not parts
                or not isinstance(parts[0], (list, tuple)) or not parts[0]):
            continue
        try:
            year = int(parts[0][0])
        except (TypeError, ValueError):
            continue
        if 1000 <= year <= 3000:
            return year
    return None


def _crossref_metadata_from_message(
    message: object,
    fallback_doi: str = "",
) -> Optional[WorkMetadata]:
    """Normalize one Crossref work object without trusting its schema."""
    if not isinstance(message, dict):
        return None
    resource = message.get("resource") or {}
    if not isinstance(resource, dict):
        resource = {}
    primary = resource.get("primary") or {}
    if not isinstance(primary, dict):
        primary = {}
    landing = primary.get("URL") or message.get("URL")
    titles = message.get("title") or []
    title = (titles[0]
             if isinstance(titles, list) and titles
             and isinstance(titles[0], str) else None)
    author_names: list[str] = []
    raw_authors = message.get("author") or []
    if not isinstance(raw_authors, list):
        raw_authors = []
    for author in raw_authors:
        if not isinstance(author, dict):
            continue
        name = author.get("family") or author.get("name")
        if isinstance(name, str) and name.strip() and name.strip() not in author_names:
            author_names.append(name.strip())
    registered_doi = message.get("DOI")
    if not isinstance(registered_doi, str) or not registered_doi.strip():
        registered_doi = fallback_doi
    return WorkMetadata(
        doi=registered_doi.strip().lower(),
        title=title,
        author_names=tuple(author_names),
        year=_crossref_year(message),
        publisher=(message.get("publisher")
                   if isinstance(message.get("publisher"), str) else None),
        work_type=(message.get("type")
                   if isinstance(message.get("type"), str) else None),
        landing_url=landing if isinstance(landing, str) else None,
    )


def _crossref_pdfs_from_message(message: object) -> list[str]:
    if not isinstance(message, dict):
        return []
    pdfs: list[str] = []
    raw_links = message.get("link") or []
    if not isinstance(raw_links, list):
        return []
    for link in raw_links:
        if not isinstance(link, dict):
            continue
        link_url = link.get("URL")
        if not isinstance(link_url, str):
            continue
        raw_content_type = link.get("content-type")
        content_type = (raw_content_type.lower()
                        if isinstance(raw_content_type, str) else "")
        if ("application/pdf" in content_type
                or link_url.lower().split("?", 1)[0].endswith(".pdf")):
            if link_url not in pdfs:
                pdfs.append(link_url)
    return pdfs


def _crossref_work_lookup(
    doi: str,
) -> tuple[Optional[WorkMetadata], list[str]]:
    """Return normalized exact-DOI Crossref metadata and registered PDFs."""
    url = f"https://api.crossref.org/works/{quote(doi, safe='')}"
    status, data = netclient.request_json(url)
    if status != 200 or not isinstance(data, dict):
        return None, []
    message = data.get("message") or {}
    return (
        _crossref_metadata_from_message(message, doi),
        _crossref_pdfs_from_message(message),
    )


def _crossref_lookup(
    doi: str,
) -> tuple[Optional[str], list[str], Optional[str]]:
    """Backward-compatible compact Crossref lookup used by older integrations."""
    metadata, pdfs = _crossref_work_lookup(doi)
    if metadata is None:
        return None, pdfs, None
    return metadata.landing_url, pdfs, metadata.title


def _crossref_candidates(
    doi: str,
    publisher: Optional[str],
    lookup: Optional[tuple[Optional[WorkMetadata], list[str]]] = None,
) -> tuple[list[Candidate], Optional[str]]:
    if lookup is None:
        landing, pdfs, title = _crossref_lookup(doi)
    else:
        metadata, pdfs = lookup
        landing = metadata.landing_url if metadata else None
        title = metadata.title if metadata else None
    if not landing and not pdfs:
        return [], title
    landing = landing or f"https://doi.org/{doi}"
    candidates: list[Candidate] = []
    for index, pdf in enumerate(pdfs[:3], 1):
        label = "crossref-publisher-pdf" if index == 1 else f"crossref-publisher-pdf-{index}"
        candidates.extend([
            Candidate(landing_url=landing, pdf_url=pdf, method="http",
                      label=label, publisher=publisher, referer=landing,
                      discovery_sources=("crossref",), matched_doi=doi),
            Candidate(landing_url=landing, pdf_url=pdf, method="browser",
                      label=f"{label}-browser", publisher=publisher,
                      needs_discovery=True, referer=landing,
                      discovery_sources=("crossref",), matched_doi=doi),
        ])
    if not pdfs:
        candidates.append(Candidate(
            landing_url=landing, pdf_url=None, method="browser",
            label="crossref-publisher-landing", publisher=publisher,
            needs_discovery=True, discovery_sources=("crossref",),
            matched_doi=doi,
        ))
    return candidates, title


_ALTERNATE_DOI_PLATFORMS = {
    "10.2139": ("ssrn", "submitted"),
    "10.1101": ("biorxiv-medrxiv", "submitted"),
    "10.21203": ("research-square", "submitted"),
    "10.26434": ("chemrxiv", "submitted"),
    "10.31219": ("osf-preprints", "submitted"),
    "10.5281": ("zenodo", "unknown"),
}
_ALTERNATE_HOST_PLATFORMS = {
    "ssrn.com": ("ssrn", "submitted"),
    "biorxiv.org": ("biorxiv", "submitted"),
    "medrxiv.org": ("medrxiv", "submitted"),
    "researchsquare.com": ("research-square", "submitted"),
    "chemrxiv.org": ("chemrxiv", "submitted"),
    "osf.io": ("osf", "submitted"),
    "zenodo.org": ("zenodo", "unknown"),
    "figshare.com": ("figshare", "unknown"),
    "hal.science": ("hal", "unknown"),
    "arxiv.org": ("arxiv", "submitted"),
}
_ALTERNATE_WORK_TYPES = {
    "posted-content", "journal-article", "proceedings-article", "report",
}


def _alternate_platform(metadata: WorkMetadata) -> Optional[tuple[str, str]]:
    prefix = metadata.doi.split("/", 1)[0]
    if prefix in _ALTERNATE_DOI_PLATFORMS:
        return _ALTERNATE_DOI_PLATFORMS[prefix]
    try:
        host = (urlparse(metadata.landing_url or "").hostname or "").lower().strip(".")
    except ValueError:
        return None
    for suffix, value in _ALTERNATE_HOST_PLATFORMS.items():
        if host == suffix or host.endswith("." + suffix):
            return value
    return None


def _alternate_match_evidence(
    source: WorkMetadata,
    candidate: WorkMetadata,
) -> Optional[tuple[str, ...]]:
    if (not source.title or not candidate.title
            or normalize_identity(source.title) != normalize_identity(candidate.title)):
        return None
    if not source.author_names or not candidate.author_names:
        return None
    author_count, author_base = author_overlap(
        source.author_names, candidate.author_names
    )
    if author_base == 0 or author_count < math.ceil(0.6 * author_base):
        return None
    if source.year is None or candidate.year is None:
        return None
    year_delta = abs(source.year - candidate.year)
    if year_delta > 3:
        return None
    return (
        "crossref-exact-title",
        f"author-overlap:{author_count}/{author_base}",
        f"year-delta:{year_delta}",
    )


def _crossref_alternate_lookup(source: WorkMetadata) -> list[AlternateWork]:
    """Find strictly matched repository/preprint records by Crossref metadata."""
    if not source.title or not source.author_names or source.year is None:
        return []
    params = {"query.title": source.title, "rows": 10}
    if source.author_names[0]:
        params["query.author"] = source.author_names[0]
    status, data = netclient.request_json("https://api.crossref.org/works", params)
    if status != 200 or not isinstance(data, dict):
        return []
    message = data.get("message") or {}
    items = message.get("items") if isinstance(message, dict) else None
    if not isinstance(items, list):
        return []
    results: list[AlternateWork] = []
    seen_dois: set[str] = set()
    for item in items:
        metadata = _crossref_metadata_from_message(item)
        if metadata is None or not metadata.doi:
            continue
        if metadata.doi.casefold() == source.doi.casefold():
            continue
        if metadata.doi in seen_dois:
            continue
        if metadata.work_type not in _ALTERNATE_WORK_TYPES:
            continue
        platform = _alternate_platform(metadata)
        if platform is None:
            continue
        evidence = _alternate_match_evidence(source, metadata)
        if evidence is None:
            continue
        seen_dois.add(metadata.doi)
        platform_name, version = platform
        verified_author_names, author_base = matched_author_names(
            source.author_names, metadata.author_names
        )
        results.append(AlternateWork(
            metadata=metadata,
            platform=platform_name,
            version=version,
            evidence=evidence + (f"repository:{platform_name}",),
            verified_author_names=verified_author_names,
            required_author_matches=math.ceil(0.6 * author_base),
        ))
    return results


def _alternate_candidates(matches: list[AlternateWork]) -> list[Candidate]:
    candidates: list[Candidate] = []
    for match in matches:
        metadata = match.metadata
        landing = metadata.landing_url or f"https://doi.org/{metadata.doi}"
        candidates.append(Candidate(
            landing_url=landing,
            pdf_url=None,
            method="browser",
            label=f"crossref-alternate-{match.platform}",
            publisher=match.platform,
            needs_discovery=True,
            referer=landing,
            discovery_sources=("crossref-title",),
            work_version=match.version,
            matched_doi=metadata.doi,
            target_doi=metadata.doi,
            match_evidence=match.evidence,
            requires_strict_identity=True,
            independent_access=True,
            verified_author_names=match.verified_author_names,
            required_author_matches=match.required_author_matches,
        ))
    return candidates


def _url_candidates(url: str) -> list[Candidate]:
    if url.lower().split("?")[0].endswith(".pdf"):
        return [
            Candidate(landing_url=None, pdf_url=url, method="http", label="url-direct-pdf"),
            Candidate(landing_url=url, pdf_url=url, method="browser", label="url-direct-pdf-browser"),
        ]
    return [
        Candidate(landing_url=url, pdf_url=None, method="browser",
                  label="url-discover", needs_discovery=True),
    ]


def _unpaywall_lookup(
    doi: str,
    email: str,
) -> tuple[Optional[str], Optional[str], Optional[str], bool]:
    """Return ``(pdf_url, landing_url, title, publisher_oa)`` from Unpaywall.

    ``best_oa_location.url`` is not necessarily a PDF. For gold OA it can be
    only the publisher landing page, which must go through browser discovery.
    """
    url = f"https://api.unpaywall.org/v2/{doi}"
    status, data = netclient.request_json(url, {"email": email})
    if status != 200 or not data:
        return None, None, None, False
    title = data.get("title")
    locations = [data.get("best_oa_location") or {}]
    locations.extend(data.get("oa_locations", []) or [])
    pdf_location = next(
        (loc for loc in locations if loc.get("url_for_pdf")), None
    )
    pdf = pdf_location.get("url_for_pdf") if pdf_location else None
    landing_locations = (
        [pdf_location] + locations if pdf_location is not None else locations
    )
    landing = next(
        (loc.get("url_for_landing_page") for loc in landing_locations
         if loc.get("url_for_landing_page")),
        None,
    )
    if landing is None:
        landing = next(
            (loc.get("url") for loc in locations if loc.get("url")),
            None,
        )
    selected_location = pdf_location or next(
        (loc for loc in landing_locations
         if loc.get("url_for_landing_page") or loc.get("url")),
        {},
    )
    publisher_oa = selected_location.get("host_type") == "publisher"
    return pdf, landing, title, publisher_oa


_OPENALEX_VERSION_MAP = {
    "publishedVersion": "published",
    "acceptedVersion": "accepted",
    "submittedVersion": "submitted",
}


def _openalex_lookup(
    doi: str,
    email: Optional[str] = None,
) -> tuple[list[OpenAlexLocation], Optional[WorkMetadata]]:
    """Return every location that OpenAlex explicitly marks open access."""
    work_id = quote(f"https://doi.org/{doi}", safe="")
    url = f"https://api.openalex.org/works/{work_id}"
    params = {"mailto": email} if email else None
    status, data = netclient.request_json(url, params)
    if status != 200 or not isinstance(data, dict):
        return [], None

    author_names: list[str] = []
    raw_authorships = data.get("authorships") or []
    if not isinstance(raw_authorships, list):
        raw_authorships = []
    for authorship in raw_authorships:
        if not isinstance(authorship, dict):
            continue
        author = authorship.get("author") or {}
        name = author.get("display_name") if isinstance(author, dict) else None
        if isinstance(name, str) and name.strip() and name.strip() not in author_names:
            author_names.append(name.strip())
    ids = data.get("ids") or {}
    registered_doi = ids.get("doi") if isinstance(ids, dict) else None
    if isinstance(registered_doi, str):
        registered_doi = registered_doi.lower().removeprefix("https://doi.org/")
    else:
        registered_doi = doi
    metadata = WorkMetadata(
        doi=registered_doi,
        title=data.get("title") if isinstance(data.get("title"), str) else None,
        author_names=tuple(author_names),
        year=(data.get("publication_year")
              if isinstance(data.get("publication_year"), int) else None),
        publisher=None,
        work_type=data.get("type") if isinstance(data.get("type"), str) else None,
        landing_url=(data.get("doi")
                     if isinstance(data.get("doi"), str) else None),
    )

    locations_value = data.get("locations") or []
    raw_locations = list(locations_value) if isinstance(locations_value, list) else []
    best = data.get("best_oa_location")
    if isinstance(best, dict):
        raw_locations.insert(0, best)
    locations: list[OpenAlexLocation] = []
    seen: set[tuple[Optional[str], Optional[str]]] = set()
    for raw in raw_locations:
        if not isinstance(raw, dict) or raw.get("is_oa") is not True:
            continue
        pdf = raw.get("pdf_url") if isinstance(raw.get("pdf_url"), str) else None
        landing = (raw.get("landing_page_url")
                   if isinstance(raw.get("landing_page_url"), str) else None)
        if not pdf and not landing:
            continue
        key = (pdf, landing)
        if key in seen:
            continue
        seen.add(key)
        source = raw.get("source") or {}
        if not isinstance(source, dict):
            source = {}
        raw_version = raw.get("version")
        version = (_OPENALEX_VERSION_MAP.get(raw_version, raw_version)
                   if isinstance(raw_version, str) else None)
        locations.append(OpenAlexLocation(
            pdf_url=pdf,
            landing_url=landing,
            source_name=(source.get("display_name")
                         if isinstance(source.get("display_name"), str) else None),
            source_type=(source.get("type")
                         if isinstance(source.get("type"), str) else None),
            version=version,
            license=(raw.get("license")
                     if isinstance(raw.get("license"), str) else None),
        ))
    return locations, metadata


def _openalex_candidates(
    doi: str,
    locations: list[OpenAlexLocation],
    publisher: Optional[str],
) -> list[Candidate]:
    """Convert explicit OpenAlex OA assertions into acquisition candidates."""
    candidates: list[Candidate] = []
    for location in locations:
        landing = location.landing_url or location.pdf_url
        evidence = ((f"openalex-source:{location.source_name}",)
                    if location.source_name else ())
        publisher_oa = location.source_type == "journal"
        common = {
            "publisher": publisher,
            "referer": landing,
            "open_access": True,
            "publisher_open_access": publisher_oa,
            "discovery_sources": ("openalex",),
            "work_version": location.version,
            "license": location.license,
            "matched_doi": doi,
            "match_evidence": evidence,
        }
        if location.pdf_url:
            candidates.append(Candidate(
                landing_url=landing,
                pdf_url=location.pdf_url,
                method="http",
                label="openalex-oa-pdf",
                **common,
            ))
        candidates.append(Candidate(
            landing_url=landing,
            pdf_url=location.pdf_url,
            method="browser",
            label=("openalex-oa-pdf-browser" if location.pdf_url
                   else "openalex-oa-landing"),
            needs_discovery=True,
            **common,
        ))
    return candidates


def _pmc_lookup(doi: str, email: Optional[str] = None) -> tuple[Optional[str], Optional[str]]:
    """Return (pmcid, pmid) for a DOI via NCBI's id-converter, or (None, None).
    Authoritative for whether a free PubMed Central copy exists. No key needed."""
    url = "https://www.ncbi.nlm.nih.gov/pmc/utils/idconv/v1.0/"
    params = {"ids": doi, "format": "json", "tool": "paper-dl"}
    if email:
        params["email"] = email
    status, data = netclient.request_json(url, params)
    if status != 200 or not data:
        return None, None
    for rec in (data.get("records") or []):
        if rec.get("pmcid"):
            return rec.get("pmcid"), (str(rec["pmid"]) if rec.get("pmid") else None)
    return None, None


def _semantic_scholar_lookup(doi: str) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Return (open_access_pdf_url, arxiv_id, title) from Semantic Scholar."""
    url = f"https://api.semanticscholar.org/graph/v1/paper/DOI:{doi}"
    status, data = netclient.request_json(url, {"fields": "title,openAccessPdf,externalIds"})
    if status != 200 or not data:
        return None, None, None
    title = data.get("title")
    oa = (data.get("openAccessPdf") or {}).get("url")
    arxiv = (data.get("externalIds") or {}).get("ArXiv")
    return oa, arxiv, title


def _dedupe(cands: list[Candidate]) -> list[Candidate]:
    seen: dict[tuple, int] = {}
    out = []
    for c in cands:
        # Do not merge identical URLs that metadata providers attribute to
        # different works. That conflict needs separate strict identity checks.
        identity_doi = c.matched_doi or c.target_doi
        key = (
            c.method, c.pdf_url, c.landing_url, c.needs_discovery, identity_doi
        )
        if key in seen:
            index = seen[key]
            existing = out[index]
            sources = tuple(dict.fromkeys(
                existing.discovery_sources + c.discovery_sources
            ))
            evidence = tuple(dict.fromkeys(
                existing.match_evidence + c.match_evidence
            ))
            open_access = existing.open_access or c.open_access
            publisher_open_access = (
                existing.publisher_open_access or c.publisher_open_access
            )
            requires_strict_identity = (
                existing.requires_strict_identity or c.requires_strict_identity
            )
            independent_access = (
                existing.independent_access or c.independent_access
            )
            matched_doi = existing.matched_doi or c.matched_doi
            target_doi = existing.target_doi or c.target_doi
            verified_author_names = tuple(dict.fromkeys(
                existing.verified_author_names + c.verified_author_names
            ))
            required_values = [
                value for value in (
                    existing.required_author_matches, c.required_author_matches
                ) if value is not None
            ]
            required_author_matches = (
                max(required_values) if required_values else None
            )
            if c.open_access and not existing.open_access:
                c.discovery_sources = sources
                c.match_evidence = evidence
                c.work_version = c.work_version or existing.work_version
                c.license = c.license or existing.license
                c.open_access = open_access
                c.publisher_open_access = publisher_open_access
                c.requires_strict_identity = requires_strict_identity
                c.independent_access = independent_access
                c.matched_doi = matched_doi
                c.target_doi = target_doi
                c.verified_author_names = verified_author_names
                c.required_author_matches = required_author_matches
                out[index] = c
            else:
                existing.discovery_sources = sources
                existing.match_evidence = evidence
                existing.work_version = existing.work_version or c.work_version
                existing.license = existing.license or c.license
                existing.open_access = open_access
                existing.publisher_open_access = publisher_open_access
                existing.requires_strict_identity = requires_strict_identity
                existing.independent_access = independent_access
                existing.matched_doi = matched_doi
                existing.target_doi = target_doi
                existing.verified_author_names = verified_author_names
                existing.required_author_matches = required_author_matches
            continue
        seen[key] = len(out)
        out.append(c)
    return out


def resolve(identifier: Identifier, config: ServiceConfig) -> ResolvePlan:
    plan = ResolvePlan(identifier=identifier)

    if identifier.kind == IdentifierKind.UNKNOWN:
        plan.notes.append("Could not classify identifier as DOI / arXiv / URL.")
        return plan

    if identifier.kind == IdentifierKind.ARXIV:
        plan.publisher = "arxiv"
        plan.candidates = _arxiv_candidates(identifier.value)
        return plan

    if identifier.kind == IdentifierKind.URL:
        plan.candidates = _url_candidates(identifier.value)
        return plan

    # DOI
    doi = identifier.value
    pub = publisher_for_doi(doi)
    plan.publisher = pub

    # (A) Publisher's version of record — the published full-text PDF.
    legacy = _legacy_elsevier_candidates(doi)
    if legacy is not None:
        published = legacy
        plan.publisher = "sciencedirect"
        pub = "sciencedirect"
        if doi.lower() == "10.1006/pest.2000.2530":
            plan.notes.append(
                "Corrected legacy DOI alias to 10.1006/pest.2001.2530 "
                "(ScienceDirect PII S0048357501925301)."
            )
    elif (adapter := get_publisher_adapter(pub)) is not None \
            and adapter.build_candidates is not None:
        published = adapter.build_candidates(doi, config)
    elif pub == "siam":
        published = _siam_candidates(doi)
    elif pub == "wiley":
        published = _wiley_candidates(doi)
    elif pub == "nature":
        published = _nature_candidates(doi)
    elif pub == "jstor":
        published = _jstor_candidates(doi)
    elif pub == "aps":
        published = _aps_candidates(doi)
    elif pub == "iop":
        published = _iop_candidates(doi)
    elif pub == "degruyter":
        published = _degruyter_candidates(doi)
    elif pub == "plos":
        published = _plos_candidates(doi)
    elif pub == "annualreviews":
        published = _annualreviews_candidates(doi)
    elif pub == "thieme":
        published = _thieme_candidates(doi)
    elif pub in {"ametsoc", "ams", "dove"}:
        published = _publisher_doi_candidate(doi, pub)
    elif pub == "pensoft":
        published = _pensoft_candidates(doi)
        if config.autodev:
            # The official generated-PDF endpoint is consistently throttled to
            # minutes. Let the browser render the already complete OA article.
            published = [cand for cand in published if cand.method == "browser"]
    elif pub == "copernicus":
        published = _copernicus_candidates(doi)
        if config.autodev:
            # Its static PDFs are correct but currently transfer too slowly for
            # a bounded batch; the complete OA HTML prints cleanly and quickly.
            published = [cand for cand in published if cand.method == "browser"]
    else:
        published = _generic_doi_candidates(doi, pub)

    # Query exact-DOI metadata for every prefix when enabled. Crossref's
    # member-supplied PDF links are only promoted for the publishers whose
    # opaque routes need them; all other DOI handlers retain their deterministic
    # candidates while still gaining title/author/year evidence.
    crossref_lookup: Optional[tuple[Optional[WorkMetadata], list[str]]] = None
    if config.use_crossref_metadata:
        crossref_lookup = _crossref_work_lookup(doi)
        plan.work_metadata = crossref_lookup[0]
        registered, registered_title = _crossref_candidates(
            doi, pub, crossref_lookup
        )
        if registered_title:
            plan.title = registered_title
        if registered and pub in _CROSSREF_LINK_PUBLISHERS:
            published = registered + published

    # Crossref can re-introduce the same slow publisher PDF after the platform
    # candidates above were pruned, so enforce the unattended policy once more
    # after all published-version construction is complete.
    if config.autodev and pub in {"pensoft", "copernicus"}:
        published = [cand for cand in published if cand.method == "browser"]

    # (B) Open-access fallbacks (publisher gold-OA, repository, or arXiv preprint).
    oa: list[Candidate] = []
    pmc: list[Candidate] = []
    direct_oa_found = False
    # PubMed Central — the authoritative free full text for biomedical papers
    # (e.g. a paywalled JAMA article whose NIH copy lives on PMC). Runs without an
    # email and is more reliable than Unpaywall for PMC coverage. Kept in its own
    # list so it can be ordered ahead of *generic* (heuristic) publisher discovery.
    if config.use_pmc:
        pmcid, pmid = _pmc_lookup(doi, config.unpaywall_email)
        if pmcid:
            plan.notes.append(f"PubMed Central free full text: {pmcid}"
                              + (f" (PMID {pmid})" if pmid else ""))
            pmc = _pmc_candidates(pmcid)
            direct_oa_found = True
    if config.use_unpaywall and config.unpaywall_email:
        oa_pdf, oa_landing, title, publisher_oa = _unpaywall_lookup(
            doi, config.unpaywall_email
        )
        if title:
            plan.title = title
        if oa_pdf or oa_landing:
            direct_oa_found = direct_oa_found or bool(oa_pdf)
            plan.notes.append(
                f"Unpaywall open-access copy: {oa_pdf or oa_landing}"
            )
            landing = oa_landing or f"https://doi.org/{doi}"
            if oa_pdf:
                oa.append(Candidate(
                    landing_url=landing,
                    pdf_url=oa_pdf,
                    method="http",
                    label="unpaywall-oa",
                    publisher=pub,
                    referer=landing,
                    open_access=True,
                    publisher_open_access=publisher_oa,
                    discovery_sources=("unpaywall",),
                    matched_doi=doi,
                ))
            oa.append(Candidate(
                landing_url=landing,
                pdf_url=oa_pdf,
                method="browser",
                label="unpaywall-oa-browser",
                publisher=pub,
                needs_discovery=True,
                referer=landing,
                open_access=True,
                publisher_open_access=publisher_oa,
                discovery_sources=("unpaywall",),
                matched_doi=doi,
            ))
    if config.use_openalex:
        openalex_locations, openalex_metadata = _openalex_lookup(
            doi, config.unpaywall_email
        )
        if plan.work_metadata is None and openalex_metadata is not None:
            plan.work_metadata = openalex_metadata
        if openalex_metadata and openalex_metadata.title and not plan.title:
            plan.title = openalex_metadata.title
        openalex = _openalex_candidates(doi, openalex_locations, pub)
        if openalex:
            direct_oa_found = direct_oa_found or any(
                location.pdf_url for location in openalex_locations
            )
            oa.extend(openalex)
            plan.notes.append(
                f"OpenAlex open-access locations: {len(openalex_locations)}"
            )
    if config.use_crossref_alternates and plan.work_metadata is not None:
        alternate_matches = _crossref_alternate_lookup(plan.work_metadata)
        if alternate_matches:
            oa.extend(_alternate_candidates(alternate_matches))
            for match in alternate_matches:
                plan.notes.append(
                    "Crossref strict alternate match: "
                    f"{match.metadata.doi} ({match.platform})"
                )
    if config.use_semantic_scholar and not direct_oa_found:
        ss_oa, ss_arxiv, ss_title = _semantic_scholar_lookup(doi)
        if ss_title and not plan.title:
            plan.title = ss_title
        # Skip a useless "OA PDF" that is just the DOI resolver (it only redirects
        # back to the publisher landing the publisher candidate already handles).
        if ss_oa and "doi.org/" not in ss_oa.lower():
            plan.notes.append(f"Semantic Scholar open-access PDF: {ss_oa}")
            oa.append(Candidate(
                landing_url=ss_oa, pdf_url=ss_oa, method="http", label="s2-oa",
                open_access=True, discovery_sources=("semantic-scholar",),
                matched_doi=doi,
            ))
            oa.append(Candidate(
                landing_url=ss_oa, pdf_url=ss_oa, method="browser",
                label="s2-oa-browser", open_access=True,
                discovery_sources=("semantic-scholar",), matched_doi=doi,
            ))
        if ss_arxiv:
            plan.notes.append(f"Semantic Scholar: free arXiv copy {ss_arxiv} (preprint fallback)")
            oa += _arxiv_candidates(ss_arxiv)

    # Order. OA-first (default) puts verified open-access locations ahead of the
    # publisher version. PubMed Central is authoritative for the *article*
    # (no ambiguity about which file is the paper), so it goes ahead of a GENERIC
    # doi-discover candidate (whose link-scraping can grab the wrong public PDF —
    # the JAMA-supplement bug), but stays behind a bespoke publisher handler
    # (IEEE/SIAM/Nature/JSTOR/LWW) that already knows the exact main-PDF URL when
    # the user explicitly opts into publisher-first ordering.
    if config.prefer_published:
        if pub in _BESPOKE_PUBLISHERS:
            plan.candidates = published + pmc + oa
        else:
            plan.candidates = pmc + published + oa
    else:
        plan.candidates = pmc + oa + published

    for candidate in plan.candidates:
        # Every exact-DOI provider is evidence about the requested work. Alternate
        # discovery sets its own matched/target DOI before this normalization.
        candidate.matched_doi = candidate.matched_doi or doi
        candidate.target_doi = candidate.target_doi or candidate.matched_doi
    plan.candidates = _dedupe(plan.candidates)
    return plan
