"""paper_dl — academic paper downloader.

Public API:

    from paper_dl import PaperDownloadService, ServiceConfig

    svc = PaperDownloadService(ServiceConfig())
    report = svc.download_many(["10.1038/s41467-019-09234-6", "arXiv:1706.03762"])
    print(report.to_json())
"""


def _ensure_native_dll_path() -> None:
    """On Windows, PyMuPDF native modules need the MSVC runtime. If it
    isn't installed system-wide, the `msvc-runtime` package drops the DLLs into
    the venv; register those locations on the DLL search path so `import fitz`
    works even without admin rights / a system VC++ redistributable."""
    import os
    import sys

    if os.name != "nt":
        return
    candidates = [sys.prefix, os.path.join(sys.prefix, "Scripts")]
    # site-packages dirs may also hold bundled runtimes
    try:
        import site

        for sp in site.getsitepackages():
            candidates.append(sp)
    except Exception:
        pass
    for d in candidates:
        try:
            if d and os.path.isdir(d):
                os.add_dll_directory(d)
        except Exception:
            continue


_ensure_native_dll_path()

from .config import ServiceConfig
from .models import (
    DownloadResult,
    Identifier,
    IdentifierKind,
    BatchReport,
    Status,
    UnableReason,
)
from .service import PaperDownloadService

__all__ = [
    "PaperDownloadService",
    "ServiceConfig",
    "DownloadResult",
    "BatchReport",
    "Identifier",
    "IdentifierKind",
    "Status",
    "UnableReason",
]

__version__ = "0.1.3"
