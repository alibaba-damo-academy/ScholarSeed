"""paper_dl — academic paper downloader.

Public API:

    from paper_dl import PaperDownloadService, ServiceConfig

    svc = PaperDownloadService(ServiceConfig())
    report = svc.download_many(["10.1038/s41467-019-09234-6", "arXiv:1706.03762"])
    print(report.to_json())
"""

from .config import ServiceConfig
from .models import (
    DownloadResult,
    Identifier,
    IdentifierKind,
    BatchReport,
    Status,
    UnableReason,
)
from .service import PaperDownloadService

__all__ = [
    "PaperDownloadService",
    "ServiceConfig",
    "DownloadResult",
    "BatchReport",
    "Identifier",
    "IdentifierKind",
    "Status",
    "UnableReason",
]

__version__ = "0.1.3"
