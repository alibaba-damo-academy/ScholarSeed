"""Stable internal contracts shared by resolution and acquisition layers."""

from .contracts import (
    AlternateWork,
    Candidate,
    OpenAlexLocation,
    ResolvePlan,
    WorkMetadata,
)

__all__ = [
    "AlternateWork",
    "Candidate",
    "OpenAlexLocation",
    "ResolvePlan",
    "WorkMetadata",
]
