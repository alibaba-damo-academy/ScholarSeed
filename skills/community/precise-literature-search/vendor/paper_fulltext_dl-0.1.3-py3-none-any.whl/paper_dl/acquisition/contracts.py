"""Data-only acquisition contracts.

This module deliberately has no browser, storage, reporting, or service
dependencies.  ``paper_dl.resolver`` re-exports these names for compatibility.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..models import Identifier


@dataclass
class Candidate:
    """One ordered way to attempt an acquisition."""

    landing_url: Optional[str]
    pdf_url: Optional[str]
    method: str
    label: str
    publisher: Optional[str] = None
    needs_discovery: bool = False
    referer: Optional[str] = None
    open_access: bool = False
    publisher_open_access: bool = False
    target_doi: Optional[str] = None
    discovery_sources: tuple[str, ...] = ()
    work_version: Optional[str] = None
    license: Optional[str] = None
    matched_doi: Optional[str] = None
    match_evidence: tuple[str, ...] = ()
    requires_strict_identity: bool = False
    independent_access: bool = False
    verified_author_names: tuple[str, ...] = ()
    required_author_matches: Optional[int] = None


@dataclass(frozen=True)
class WorkMetadata:
    """Provider-neutral bibliographic evidence for the requested work."""

    doi: str
    title: Optional[str] = None
    author_names: tuple[str, ...] = ()
    year: Optional[int] = None
    publisher: Optional[str] = None
    work_type: Optional[str] = None
    landing_url: Optional[str] = None


@dataclass(frozen=True)
class OpenAlexLocation:
    """One location that OpenAlex explicitly marks open access."""

    pdf_url: Optional[str]
    landing_url: Optional[str]
    source_name: Optional[str] = None
    source_type: Optional[str] = None
    version: Optional[str] = None
    license: Optional[str] = None


@dataclass(frozen=True)
class AlternateWork:
    """Strictly matched alternate record eligible for acquisition."""

    metadata: WorkMetadata
    platform: str
    version: str
    evidence: tuple[str, ...]
    verified_author_names: tuple[str, ...] = ()
    required_author_matches: Optional[int] = None


@dataclass
class ResolvePlan:
    identifier: Identifier
    candidates: list[Candidate] = field(default_factory=list)
    title: Optional[str] = None
    publisher: Optional[str] = None
    notes: list[str] = field(default_factory=list)
    work_metadata: Optional[WorkMetadata] = None
