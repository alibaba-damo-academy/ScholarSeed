"""Playwright-based browser engine with anti-block / anti-detection features.

Design notes
------------
* Uses a **persistent context** (a real on-disk Chromium/Chrome profile) so an
  institutional login or a solved Cloudflare challenge (cf_clearance cookie) is
  reused across runs. Point ``browser.user_data_dir`` at that profile.
* Applies a **stealth init script** (bundled-Chromium only) hiding the common
  automation fingerprints.
* **Challenge detection is structural, not text-based** — it looks for actual
  Cloudflare/Turnstile/PerimeterX DOM markers, never a "cloudflare" substring
  (publisher pages legitimately load Cloudflare-CDN assets). In a visible window
  it *waits for the human to solve* the challenge instead of giving up.
* **Finds the PDF aggressively**: citation_pdf_url meta, the candidate's known
  PDF URL, discovered links, and — crucially — by **clicking the "Download PDF"
  / "PDF" / "Full Text" button** and capturing the resulting download, popup, or
  inline-PDF navigation. This is what gets the *published* version of record.
"""

from __future__ import annotations

import base64
import logging
import random
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urljoin, urlparse, urlunparse

from .config import ServiceConfig
from .deadline import (
    check as check_item_deadline,
    clamp_milliseconds,
    clamp_seconds,
    remaining_seconds,
    sleep as deadline_sleep,
)
from .discovery import (find_pdf_links, looks_institution_login_required,
                        looks_paywalled, looks_not_found, extract_title,
                        is_supplement_url)
from .http_fallback import apply_ezproxy
from .pdfutil import extract_text, is_pdf_bytes
from .publishers.registry import get_publisher_adapter
from .resolver import Candidate
from .translators import TranslatorRegistry

# Diagnostic breadcrumbs for the live-only acquisition path. Silent by default (no
# handler); enable with logging.getLogger("paper_dl").setLevel(logging.DEBUG). Used
# ONLY in pure fetch/parse helpers — never in the v7-sensitive teardown excepts.
_dbg = logging.getLogger("paper_dl.browser")

_MIN_BROWSER_RENDERED_FULLTEXT_CHARS = 1_500

_STEALTH_JS = r"""
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
Object.defineProperty(navigator, 'plugins', {get: () => [1,2,3,4,5]});
window.chrome = window.chrome || { runtime: {} };
const _q = window.navigator.permissions && window.navigator.permissions.query;
if (_q) {
  window.navigator.permissions.query = (p) => (
    p && p.name === 'notifications'
      ? Promise.resolve({ state: Notification.permission })
      : _q(p)
  );
}
try {
  const gp = WebGLRenderingContext.prototype.getParameter;
  WebGLRenderingContext.prototype.getParameter = function(p) {
    if (p === 37445) return 'Intel Inc.';
    if (p === 37446) return 'Intel Iris OpenGL Engine';
    return gp.apply(this, [p]);
  };
} catch (e) {}
"""

# Visible link/button text that leads to the full-text PDF.
_PDF_TEXT_RE = re.compile(
    r"(download\s*pdf|view\s*pdf|full[\s-]*text\s*pdf|get\s*pdf|read\s*pdf|"
    r"article\s*pdf|^\s*pdf\s*$|pdf\b.*download|save\s*pdf|^\s*download\s*$)", re.I)

# Confirmation control inside a post-click Terms&Conditions modal (e.g. JSTOR's
# "Accept and download"). Worded to avoid matching cookie-consent "Accept all".
_ACCEPT_TEXT_RE = re.compile(
    r"(accept\s*(and|&)?\s*(download|continue|read|terms)|"
    r"^\s*i?\s*accept\s*$|agree\s*(and|&)\s*(download|continue)|^\s*agree\s*$)", re.I)

# A "PDF" item inside a Download menu that offers formats (PDF vs EPUB), e.g.
# LWW / journals.lww.com "Download" -> "PDF". We click PDF and never EPUB.
_PDF_MENU_RE = re.compile(r"\bpdf\b", re.I)

# Structural markers that ONLY exist on a full-page bot challenge / interstitial
# (never embedded in a normal page), so they are trusted on any HTTP status.
_INTERSTITIAL_SELECTOR = (
    "#challenge-running, #cf-please-wait, #challenge-form, #challenge-stage, "
    "#captcha-box, form[action*='/captcha/'] input[name='Answer']"
)
# Captcha / Turnstile WIDGETS that ALSO appear embedded in a *normal* page's
# forms — and a Cloudflare-fronted site (e.g. bioRxiv) can leave a Turnstile
# iframe in the DOM of a page that loaded fine — so they only indicate a wall when
# the page was actually BLOCKED (HTTP 403/429). The challenge *title* and the
# interstitial markers above remain the always-trusted signals.
_WIDGET_SELECTOR = (
    "iframe[src*='challenges.cloudflare.com'], iframe[title*='Cloudflare'], "
    "iframe[title*='challenge'], .cf-turnstile, "
    "iframe[src*='captcha'], iframe[src*='recaptcha']"
)
# STRONG verification widgets that essentially never load on a normally-served
# publisher article page: hCaptcha and dedicated bot-wall vendors (DataDome /
# PerimeterX) only inject their captcha container/iframe on an ACTUAL block page.
# Their presence is therefore a bot wall on ANY HTTP status — this catches the
# 200-status "I am a real visitor" hCaptcha gates that show no interstitial title
# and return neither 403 nor 429.
_STRONG_WIDGET_SELECTOR = (
    "iframe[src*='hcaptcha'], .h-captcha, #px-captcha, "
    "iframe[src*='captcha-delivery'], #datadome, .datadome, [id^='ddv1-captcha']"  # DataDome (JSTOR)
)
# Vendor challenge-frame URL markers. These frames are useful evidence only when
# their iframe is actually visible: hCaptcha/reCAPTCHA also support invisible or
# passive modes, and publishers can leave those hidden frames on a normal page.
# The visibility check below still catches nested Imperva/Incapsula challenges.
_CHALLENGE_FRAME_URL_MARKERS = (
    "hcaptcha.com",
    "captcha-delivery.com",
    "geo.captcha-delivery",
    "recaptcha/api2/bframe",
)
# Bot-protection WRAPPER frames. These are not captcha widgets themselves; a
# vendor (Imperva/Incapsula, Distil, ...) serves an otherwise-empty shell page
# and injects the real captcha CHILD frame a beat later. Their presence means a
# challenge widget may still be attaching, so the caller should poll briefly
# rather than declare the page clean on the first snapshot.
_PROTECTION_SHELL_FRAME_MARKERS = (
    "_incapsula_resource",
    "distil_r_captcha",
)
# Title substrings that indicate a genuine bot challenge / interstitial. Includes
# common Chinese localizations so a zh-CN captcha page is not mistaken for a
# normal article.
_CHALLENGE_TITLES = (
    "just a moment", "attention required",
    "verifying you are human", "human verification",
    "one moment, please",
    "checking your browser", "request verification", "pardon our interruption",
    "please verify you are a human", "are you a robot",
    "verify you are a real visitor", "real visitor",
    "请稍候", "请稍等", "人机验证", "安全验证", "验证您是真人", "正在验证",
    "正在检查您的浏览器",
)
# VISIBLE, human-readable phrases that only appear on an actual challenge page —
# safe to scan in any page's body text without false positives.
_CHALLENGE_VISIBLE_PHRASES = (
    "are you a robot", "confirm you are a human", "completing the captcha",
    "complete the captcha challenge", "verify you are a human",
    "request verification: in progress",
    "please enable cookies", "checking if the site connection is secure",
    "verify you are human", "complete this recaptcha", "complete the recaptcha",
    "unusual traffic activity from your network",   # JSTOR "Access Check" page
    "sorry, you have been blocked",                  # Cloudflare custom block page
    "there was a problem providing the content you requested",  # Elsevier CPE block
    "i am a real visitor", "verify you are a real visitor",
    "我是真实访客", "真实访客", "人机验证", "验证您是真人",
    "正在进行安全验证", "验证您不是自动程序", "确认您不是自动程序",
)
# Page-SOURCE markers (DataDome / reCAPTCHA / Cloudflare). These scripts can load
# on normal pages of a protected site, so they are only trusted when the HTTP
# response was actually BLOCKED (403/429) — otherwise a normal page looks challenged.
_CHALLENGE_SOURCE_MARKERS = (
    "captcha-delivery.com", "geo.captcha-delivery", "datadome",
    "recaptcha", "g-recaptcha", "hcaptcha", "/captcha/captcha.js",
)
# Back-compat alias (kept for any external reference).
_CHALLENGE_BODY_PHRASES = _CHALLENGE_VISIBLE_PHRASES


def _challenge_title_matches(title: str) -> bool:
    """Match challenge titles without treating a generic access gate as CAPTCHA."""
    normalized = (title or "").lower()
    if any(marker in normalized for marker in _CHALLENGE_TITLES):
        return True
    # "Access Check" is JSTOR's bot-wall title, but Wiley and other publishers
    # use the same generic wording for entitlement/institution-login screens.
    return "access check" in normalized and "jstor" in normalized


def _challenge_url_matches(url: str) -> bool:
    """Match publisher routes that are themselves dedicated CAPTCHA pages."""
    try:
        parsed = urlparse(url or "")
    except Exception:
        return False
    hostname = (parsed.hostname or "").lower()
    path = parsed.path.lower().rstrip("/")
    return bool(
        (hostname == "opg.optica.org" and path.startswith("/captcha/"))
        or (hostname == "pubs.acs.org"
            and path == "/crawlprevention/governor")
    )


def _sticky_challenge_url_matches(url: str) -> bool:
    """Dedicated challenge routes that cannot represent a solved article.

    Optica may retain its sessionful CAPTCHA URL after a successful submit, so
    polling must inspect its live form. ACS's governor route, by contrast, is
    always a crawl-prevention surface and remains authoritative while polling.
    """
    try:
        parsed = urlparse(url or "")
    except Exception:
        return False
    return bool(
        (parsed.hostname or "").lower() == "pubs.acs.org"
        and parsed.path.lower().rstrip("/") == "/crawlprevention/governor"
    )


def _looks_like_bot_wall(title: str, source: str, blocked: bool = False) -> bool:
    """Pure predicate: does this (title, page-source/body) look like a bot wall /
    captcha? ``blocked`` (the landing returned 403/429) is what makes the ambiguous
    DataDome/Cloudflare source markers trustworthy. Unit-tested directly."""
    t = (title or "").lower()
    if _challenge_title_matches(t):
        return True
    s = (source or "").lower()
    if any(p in s for p in _CHALLENGE_VISIBLE_PHRASES):
        return True
    if blocked and any(m in s for m in _CHALLENGE_SOURCE_MARKERS):
        return True
    return False


_DOI_TOKEN_RE = re.compile(r"10\.\d{4,9}/[-._;()/:a-z0-9]+", re.I)


def _normalize_doi_token(value: str) -> str:
    value = (value or "").strip().lower()
    value = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", value)
    return value.rstrip(".,;:)]}\"")


def _article_document_evidence(html: str, title: str = "") -> bool:
    """High-confidence evidence that a publisher served a real article.

    This deliberately requires bibliographic/article structure, not merely a
    long body, so a verbose WAF page cannot suppress genuine challenge signals.
    """
    low = (html or "").lower()
    title_low = (title or "").lower()
    if _challenge_title_matches(title_low):
        return False
    bibliographic = any(marker in low for marker in (
        "citation_doi", "prism.doi", "dc.identifier", "article:published_time",
    ))
    article_structure = sum(marker in low for marker in (
        "abstract", "references", "download pdf", "article-title", "<article",
    )) >= 2
    bibliographic = bibliographic or bool(_DOI_TOKEN_RE.search(low))
    return bibliographic and article_structure


def landing_identity_mismatch(expected_doi: str, html: str,
                              final_url: str = "") -> Optional[str]:
    """Return a precise message when publisher metadata names another DOI.

    Only explicit bibliographic meta fields are authoritative.  Incidental DOI
    strings in references and related-article lists are ignored.
    """
    expected = _normalize_doi_token(expected_doi)
    if not expected or not html:
        return None
    meta_values = re.findall(
        r"<meta\b[^>]*(?:name|property)=[\"'][^\"']*"
        r"(?:citation_doi|prism[.:]doi|dc[.:]identifier|^doi$)[^\"']*[\"']"
        r"[^>]*content=[\"']([^\"']+)[\"']",
        html,
        flags=re.I,
    )
    # Attribute order is not guaranteed.
    meta_values += re.findall(
        r"<meta\b[^>]*content=[\"']([^\"']+)[\"'][^>]*"
        r"(?:name|property)=[\"'][^\"']*"
        r"(?:citation_doi|prism[.:]doi|dc[.:]identifier|^doi$)[^\"']*[\"']",
        html,
        flags=re.I,
    )
    observed: list[str] = []
    for value in meta_values:
        match = _DOI_TOKEN_RE.search(value)
        if match:
            token = _normalize_doi_token(match.group(0))
            if token and token not in observed:
                observed.append(token)
    if not observed or expected in observed:
        return None
    rendered = ", ".join(observed[:3])
    return (
        f"Identifier mismatch: requested DOI {expected_doi}, but the publisher "
        f"landing identifies {rendered}; refused to save another article."
    )


def _response_is_waf_challenge(headers: object) -> bool:
    """AWS WAF identifies its otherwise-empty 202 challenge only by header."""
    try:
        normalized = {
            str(k).lower(): str(v).lower()
            for k, v in dict(headers or {}).items()
        }
    except Exception:
        return False
    return normalized.get("x-amzn-waf-action", "").strip() == "challenge"


_ELEMENT_VISIBLY_RENDERED_JS = """el => {
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    // Reject the common top:-10000px / left:-10000px hidden-frame pattern, but
    // keep below-the-fold challenges visible so the user can scroll to them.
    if (rect.bottom <= 0 || rect.right <= 0) return false;
    for (let node = el; node; node = node.parentElement) {
        const style = getComputedStyle(node);
        if (style.display === 'none' || style.visibility === 'hidden' ||
                Number(style.opacity || 1) <= 0.01) return false;
    }
    return true;
}"""


def _element_is_visibly_rendered(element) -> bool:
    """Visibility stricter than Playwright's (which treats opacity:0 as visible)."""
    try:
        return bool(
            element.is_visible()
            and element.evaluate(_ELEMENT_VISIBLY_RENDERED_JS)
        )
    except Exception:
        return False


def _frame_is_visible(frame) -> bool:
    """Best-effort visibility check for a child frame and its iframe ancestors."""
    current = frame
    saw_child = False
    while True:
        try:
            parent = current.parent_frame
        except Exception:
            return False
        if parent is None:
            return saw_child
        saw_child = True
        try:
            element = current.frame_element()
            if not _element_is_visibly_rendered(element):
                return False
        except Exception:
            # Detached/uninspectable frames must not make a normal HTTP 200 page
            # block for three minutes on a challenge the user cannot see.
            return False
        current = parent


def _has_challenge_frame(page) -> bool:
    """True if a visible frame is a dedicated captcha-vendor challenge frame.

    Iterating ``page.frames`` covers nested Imperva/Incapsula challenges, while
    requiring the full iframe ancestry to be visible avoids passive/invisible
    reCAPTCHA and hCaptcha frames left behind on normal publisher pages.
    """
    try:
        frames = page.frames
    except Exception:
        return False
    for fr in frames:
        try:
            url = (fr.url or "").lower()
        except Exception:
            continue
        if (url and any(m in url for m in _CHALLENGE_FRAME_URL_MARKERS)
                and _frame_is_visible(fr)):
            return True
    return False


def _has_visible_locator(page, selector: str, *, limit: int = 12) -> bool:
    """Return whether ``selector`` has a rendered, non-zero-size match.

    ``locator.count()`` alone is not challenge evidence: invisible captcha frames
    are routinely present on normal pages. The stricter element check also rejects
    transparent ancestors and the common ``top:-10000px`` hiding pattern.
    """
    try:
        matches = page.locator(selector)
        count = min(matches.count(), limit)
    except Exception:
        return False
    for index in range(count):
        try:
            if _element_is_visibly_rendered(matches.nth(index)):
                return True
        except Exception:
            continue
    return False


def _looks_like_pending_challenge_shell(page) -> bool:
    """Whether the page looks like a bot-protection shell whose captcha widget may
    still be attaching. Imperva/Incapsula (and similar) serve an empty wrapper page
    and inject the hCaptcha CHILD frame a beat later, so the first snapshot can miss
    it — the caller should poll for a moment when this is True."""
    try:
        frames = page.frames
    except Exception:
        frames = []
    for fr in frames:
        try:
            url = (fr.url or "").lower()
        except Exception:
            continue
        if url and any(m in url for m in _PROTECTION_SHELL_FRAME_MARKERS):
            return True
    # An empty shell (no title AND no visible body text) that still returned a
    # page is itself suspicious — a normal article always renders text.
    try:
        if (page.title() or "").strip():
            return False
    except Exception:
        return False
    try:
        body = (page.inner_text("body") or "").strip()
    except Exception:
        return False
    return len(body) < 16


def _looks_like_pdf_url(url: str, content_type: str = "") -> bool:
    """True if a landed URL/response is itself a PDF file — e.g. a DOI that
    redirects straight to ``Paper1234.pdf``, so the landing page IS the PDF and the
    landed URL is what we should fetch. Unit-tested directly."""
    u = (url or "").lower().split("?", 1)[0]
    return u.endswith(".pdf") or "application/pdf" in (content_type or "").lower()


def _wiley_pdf_redirected_to_abstract(requested_url: str, final_url: str) -> bool:
    """Whether a Wiley PDF request was downgraded to its abstract page.

    Wiley uses this redirect after its bot check when the browser session has no
    full-text entitlement. Replaying the PDF URL only starts Cloudflare again;
    the actionable next step is institutional authentication.
    """
    try:
        requested = urlparse(requested_url or "")
        final = urlparse(final_url or "")
    except Exception:
        return False
    requested_host = (requested.hostname or "").lower()
    final_host = (final.hostname or "").lower()
    if not (
        requested_host.endswith("onlinelibrary.wiley.com")
        and final_host.endswith("onlinelibrary.wiley.com")
    ):
        return False
    requested_path = requested.path.lower()
    final_path = final.path.lower()
    return bool(
        re.search(r"/doi/(?:e?pdf|pdfdirect)/", requested_path)
        and "/doi/abs/" in final_path
    )


def _canonicalize_wiley_pdf_urls(urls: list[str], final_url: str) -> list[str]:
    """Keep Wiley PDF requests on the journal host selected by the landing."""
    try:
        canonical = urlparse(final_url or "")
    except Exception:
        return list(dict.fromkeys(urls))
    if not (canonical.hostname or "").lower().endswith(
        "onlinelibrary.wiley.com"
    ):
        return list(dict.fromkeys(urls))

    normalized: list[str] = []
    for url in urls:
        try:
            parsed = urlparse(url)
            if (parsed.hostname or "").lower().endswith(
                "onlinelibrary.wiley.com"
            ):
                url = urlunparse(parsed._replace(
                    scheme=canonical.scheme or parsed.scheme,
                    netloc=canonical.netloc,
                ))
        except Exception:
            pass
        if url not in normalized:
            normalized.append(url)
    return normalized


_NAV_ERROR_CODE_RE = re.compile(r"\b(?:net::)?(ERR_[A-Z0-9_]+)\b", re.I)
_TERMINAL_NAV_ERRORS = {
    "ERR_ADDRESS_UNREACHABLE",
    "ERR_CONNECTION_ABORTED",
    "ERR_CONNECTION_CLOSED",
    "ERR_CONNECTION_REFUSED",
    "ERR_CONNECTION_RESET",
    "ERR_EMPTY_RESPONSE",
    "ERR_HTTP2_PROTOCOL_ERROR",
    "ERR_HTTP_RESPONSE_CODE_FAILURE",
    "ERR_INTERNET_DISCONNECTED",
    "ERR_INVALID_URL",
    "ERR_NAME_NOT_RESOLVED",
    "ERR_PROXY_CONNECTION_FAILED",
    "ERR_QUIC_PROTOCOL_ERROR",
    "ERR_TIMED_OUT",
    "ERR_TOO_MANY_REDIRECTS",
    "ERR_TUNNEL_CONNECTION_FAILED",
    "ERR_UNKNOWN_URL_SCHEME",
}
_TERMINAL_NAV_ERROR_PREFIXES = ("ERR_CERT_", "ERR_DNS_", "ERR_SSL_")


def _is_terminal_navigation_error(code: str) -> bool:
    code = (code or "").upper()
    return (
        code in _TERMINAL_NAV_ERRORS
        or code.startswith(_TERMINAL_NAV_ERROR_PREFIXES)
    )


_COMPACT_ERROR_PAGE_MAX_CHARS = 30_000
_STRONG_NOT_FOUND_BODY_RE = re.compile(
    r"("
    r"doi not found"
    r"|404\s*[-:|\u2013\u2014]?\s*(error|not[ -]?found|page not found)"
    r"|page not found"
    r"|article not found"
    r"|not found on this server"
    r"|the requested (url|page|article|resource) .{0,60}?(was )?not found"
    r"|the (article|page|content) (you requested )?(could not|couldn'?t|cannot|can'?t) "
    r"(be )?found"
    r"|this (article|page|content) (is|was|has been) (no longer|not) "
    r"(available|found|published)"
    r"|no longer available"
    r")",
    re.I,
)


def _landing_looks_not_found(nav_status: Optional[int], page_text: str,
                             title: Optional[str]) -> bool:
    """High-confidence missing-paper evidence from a publisher landing page.

    A real paper can contain ordinary research prose such as "the compound was
    not found".  Trust that broad wording in the publisher-controlled title, but
    restrict body matching to compact error pages and unmistakable error phrases.
    """
    if nav_status in (404, 410):
        return True
    if looks_not_found("", title):
        return True
    text = page_text or ""
    return (
        len(text) <= _COMPACT_ERROR_PAGE_MAX_CHARS
        and bool(_STRONG_NOT_FOUND_BODY_RE.search(text))
    )


def _is_browser_error_url(url: Optional[str]) -> bool:
    return (url or "").lower().startswith("chrome-error:")


def landing_terminal_verdict(nav_status: Optional[int], html: str,
                             title: Optional[str],
                             navigation_error: str = "", *,
                             final_url: Optional[str] = None) -> tuple[Optional[str], str]:
    """Return a high-confidence terminal landing-page verdict and safe detail.

    ``reason`` is ``"url_error"``, ``"not_found"``, or ``None``.  This check is
    deliberately narrow because it runs *before* Zotero translators, captcha
    handling, and the browser PDF strategies:

    * browser-level network failures (for example ``ERR_CONNECTION_CLOSED``),
    * publisher/server 5xx responses and unmistakable static error pages, and
    * authoritative 404 / DOI-not-found / article-not-found pages.

    A generic 401/403 and a real interactive bot challenge are not URL errors;
    existing access/captcha handling still owns those cases.  ``ERR_ABORTED`` is
    also ignored because Chromium uses it for successful navigation-to-download
    flows and redirects.
    """
    if _is_browser_error_url(final_url):
        return "url_error", "URL error: browser displayed an internal navigation error page."
    if _landing_looks_not_found(nav_status, html, title):
        status = f"HTTP {nav_status}" if nav_status else "article-not-found page"
        return "not_found", f"identifier resolves to no paper ({status})"

    nav_match = _NAV_ERROR_CODE_RE.search(navigation_error or "")
    nav_code = nav_match.group(1).upper() if nav_match else ""
    if _is_terminal_navigation_error(nav_code):
        return (
            "url_error",
            f"URL error: browser could not open the paper page ({nav_code}).",
        )

    if nav_status is not None and 500 <= nav_status <= 599:
        return (
            "url_error",
            f"URL error: paper page returned HTTP {nav_status}.",
        )

    title_text = title or ""
    page_text = html or ""
    hay = f"{title_text}\n{page_text}"
    low = hay.lower().replace("’", "'")
    title_low = title_text.lower().replace("’", "'")
    # A CDN's HTTP 403 bot wall belongs to challenge handling, even when it uses
    # a static-looking custom block template.  Returning URL_ERROR here used to
    # stop BMJ/Cloudflare pages before the user could clear the challenge.
    if nav_status in (401, 403, 429):
        return None, ""
    # Browser/server error pages are compact. Requiring a compact page (or a
    # matching title) avoids treating an ERR_* string discussed inside a real
    # article as a navigation failure.
    compact_error_page = len(page_text) <= _COMPACT_ERROR_PAGE_MAX_CHARS
    rendered_match = _NAV_ERROR_CODE_RE.search(hay)
    rendered_code = rendered_match.group(1).upper() if rendered_match else ""
    if (_is_terminal_navigation_error(rendered_code)
            and (compact_error_page or rendered_code.lower() in title_low)):
        return (
            "url_error",
            f"URL error: browser could not open the paper page ({rendered_code}).",
        )

    article_document = _article_document_evidence(page_text, title_text)
    static_markers = (
        ("sorry, you have been blocked", "publisher returned a static block page"),
        ("the request could not be satisfied", "publisher returned a static error page"),
        ("this site can't be reached", "browser could not reach the paper page"),
        ("this webpage is not available", "browser could not reach the paper page"),
        ("webpage not available", "browser could not reach the paper page"),
        # Common gateway / unavailability error pages (nginx / CDN / load balancer).
        # These carry no "HTTP error 5xx" wording, so match their plain text too —
        # important when the background service-worker tab could not capture the HTTP
        # status code (httpStatus == 0) and only the rendered body is available.
        ("bad gateway", "publisher returned a Bad Gateway (502) error"),
        ("gateway time-out", "publisher returned a Gateway Timeout (504) error"),
        ("gateway timeout", "publisher returned a Gateway Timeout (504) error"),
        ("service temporarily unavailable", "publisher server is temporarily unavailable (503)"),
        ("service unavailable", "publisher server is temporarily unavailable (503)"),
        ("internal server error", "publisher returned an Internal Server Error (500)"),
    )
    for marker, explanation in static_markers:
        if marker in title_low or (
            compact_error_page and not article_document and marker in low
        ):
            return "url_error", f"URL error: {explanation}."

    http_error = re.search(
        r"\bhttp\s+error\s+([45]\d\d)\b",
        title_low if not compact_error_page else low,
    )
    if http_error:
        return (
            "url_error",
            f"URL error: paper page displayed HTTP error {http_error.group(1)}.",
        )
    return None, ""


def landing_no_paper_verdict(nav_status: Optional[int], html: str,
                             title: Optional[str], challenge_seen: bool) -> tuple[bool, bool]:
    """From a *landing* page's outcome decide whether the identifier leads to no
    paper. Returns ``(not_found, access_denied)``.

    Trust the HTTP status ONLY when no bot wall was involved: a Cloudflare / DataDome
    403 IS the challenge, so once the user solves it the initial 403 is stale and we
    end up on the real article — deriving "no paper" from that stale 403 mis-reports a
    live paper as missing (the fepbl.com/imsrj Cloudflare case). A failed ``/pdf``
    fetch is never fed here either: it 404s for a merely wrong PDF URL on an article
    that does exist. Unit-tested directly.

      * 404/410, or a "DOI Not Found" / "…not found" page  -> not_found
      * 401/403 that was NOT a bot wall                    -> access_denied
    """
    if challenge_seen:
        return False, False
    if _landing_looks_not_found(nav_status, html, title):
        return True, False
    if nav_status in (401, 403):
        return False, True
    return False, False


@dataclass
class EngineResult:
    ok: bool
    data: Optional[bytes] = None
    pdf_url: Optional[str] = None
    final_url: Optional[str] = None
    title: Optional[str] = None
    blocked: bool = False
    needs_manual: bool = False      # bot wall remained unresolved
    paywalled: bool = False
    found_control: bool = False     # a visible PDF/download control was clicked
    found_link: bool = False        # a concrete PDF URL was located/tried
    viewer_opened: bool = False     # Chrome rendered the PDF but byte capture failed
    viewer_url: Optional[str] = None
    acquisition_source: Optional[str] = None
    failure_reason: Optional[str] = None
    translator_matched: bool = False
    translator_name: Optional[str] = None
    translator_candidate: Optional[str] = None
    not_found: bool = False         # landing says no such paper (404 / "DOI Not Found")
    url_error: bool = False         # landing itself is unreachable / a terminal static error
    url_error_detail: str = ""      # safe high-confidence URL-error explanation
    access_denied: bool = False     # landing refused access (HTTP 403/401, not a bot wall)
    needs_login: bool = False       # strong institutional-login/SSO gate evidence
    login_skipped: bool = False     # paper was auto-skipped because authentication is required
    http_status: Optional[int] = None  # landing nav status, when known
    detail: str = ""
    discovered: list[str] = field(default_factory=list)
    landing_html: Optional[str] = None
    zotero_triggered: bool = False  # Connector was triggered on the live page
    zotero_pdf_ready: bool = False  # Desktop finished downloading the attachment
    identity_mismatch: bool = False
    identity_mismatch_detail: str = ""


@dataclass
class ClickPDFResult:
    """Structured evidence collected while clicking a PDF control."""

    data: Optional[bytes] = None
    found_control: bool = False
    found_direct_url: bool = False
    viewer_opened: bool = False
    viewer_url: Optional[str] = None
    pdf_captured: bool = False
    pdf_url: Optional[str] = None
    acquisition_source: Optional[str] = None
    failure_reason: Optional[str] = None


class BrowserUnavailable(RuntimeError):
    pass


def _maybe_pdf_response(resp, sink: list) -> None:
    """Append a response that may carry PDF bytes for later signature checking.

    Some publishers (including IOP) use extensionless ``/pdf`` endpoints and can
    label downloads as ``application/octet-stream``. Treat those responses as
    candidates, but never as success: callers still require a valid ``%PDF`` body.
    """
    try:
        headers = {}
        try:
            headers = resp.headers or {}
        except Exception:
            pass
        ct = headers.get("content-type", "").lower()
        disposition = headers.get("content-disposition", "").lower()
        u = (resp.url or "")
        path = urlparse(u).path.lower().rstrip("/")
        pdf_endpoint = path.endswith((".pdf", "/pdf", "/epdf"))
        disposition_pdf = ".pdf" in disposition
        if "application/pdf" in ct or pdf_endpoint or disposition_pdf:
            sink.append(resp)
    except Exception:
        pass


class BrowserEngine:
    def __init__(self, config: ServiceConfig, logger=None, solver=None, skip_check=None):
        self.cfg = config
        self.log = logger or (lambda *a, **k: None)
        # Optional ChallengeSolver (paper_dl.challenge); None = hands-off human wait.
        self._solver = solver
        self._skip_check = skip_check
        self.backend = "?"
        self._pw = None
        self._browser = None        # set only in connect-over-CDP mode
        self._connected = False     # True => attached to the user's own Chrome
        self._context = None
        self._alive = False
        # Set True whenever a real bot challenge / captcha is encountered while
        # processing the current item (in an interactive window the human had to
        # solve it). Reset per-item by the service via reset_challenge_flag().
        self._challenge_seen = False
        # Loaded lazily because the generated registry is sizeable and HTTP-only
        # runs never need it.
        self._translator_registry = None
        self.zotero_wait_fn = None

    @property
    def challenge_seen(self) -> bool:
        """Whether a bot challenge / captcha was encountered since the last reset."""
        return self._challenge_seen

    def reset_challenge_flag(self) -> None:
        """Clear the per-item challenge-encountered flag (call before each item)."""
        self._challenge_seen = False

    def _skip_requested(self) -> bool:
        try:
            return bool(self._skip_check and self._skip_check())
        except Exception:
            return False

    def _sleep_interruptible(self, seconds: float) -> bool:
        """Sleep in short slices; return False when the current paper was skipped."""
        deadline = time.time() + max(0.0, seconds)
        while time.time() < deadline:
            if self._skip_requested():
                return False
            deadline_sleep(min(0.1, max(0.0, deadline - time.time())))
        return not self._skip_requested()

    # -- lifecycle -----------------------------------------------------------
    def _import_playwright(self):
        bc = self.cfg.browser
        errors = []
        if bc.prefer_patchright:
            try:
                from patchright.sync_api import sync_playwright  # type: ignore
                self.backend = "patchright"
                return sync_playwright
            except Exception as e:  # noqa: BLE001
                errors.append(f"patchright: {e}")
        try:
            from playwright.sync_api import sync_playwright
            self.backend = "playwright"
            return sync_playwright
        except Exception as e:  # noqa: BLE001
            errors.append(f"playwright: {e}")
        raise BrowserUnavailable("no browser backend importable -> " + " | ".join(errors))

    @staticmethod
    def _set_inline_pdf_viewer(profile: str) -> None:
        """Undo any previously-forced "download PDFs externally" pref.

        An earlier approach set ``plugins.always_open_pdf_externally`` to capture
        inline PDFs as downloads, but that proved unreliable (Chrome saved the file
        yet Playwright didn't recognize it). The proven path — confirmed by a JSTOR
        HAR — is to capture the PDF via the entitled same-origin request/fetch + the
        response sniffer, which needs Chrome's inline viewer ON (the default). So we
        explicitly clear the override on an existing profile. Best-effort."""
        import json
        try:
            pref_file = Path(profile) / "Default" / "Preferences"
            if not pref_file.exists():
                return
            data = json.loads(pref_file.read_text(encoding="utf-8")) or {}
            plugins = data.get("plugins")
            if isinstance(plugins, dict) and plugins.get("always_open_pdf_externally"):
                plugins["always_open_pdf_externally"] = False
                pref_file.write_text(json.dumps(data), encoding="utf-8")
        except Exception:
            pass

    def _enter_connected(self, bc) -> "BrowserEngine":
        """Attach to an already-running Chrome over CDP (paper-dl --connect-cdp).

        Drives the user's real, warm browser (start it with --remote-debugging-port
        + a profile copy). We use its existing default context and NEVER close the
        browser or its tabs on teardown — only disconnect. Profile preferences,
        and stealth init-scripts do not apply here; it's the user's own browser, and
        being a genuinely user-launched Chrome is exactly why it can clear walls that
        loop on a Playwright-launched one."""
        try:
            browser = self._pw.chromium.connect_over_cdp(bc.cdp_endpoint)
        except Exception as e:  # noqa: BLE001
            self._cleanup()
            raise BrowserUnavailable(
                f"could not connect to Chrome at {bc.cdp_endpoint}: {type(e).__name__}: {e}. "
                "Start Chrome with a dedicated profile and a local debugging port, "
                "then retry with --connect-cdp. See QuickStart.md for platform-specific commands.") from e
        self._browser = browser
        self._connected = True
        ctxs = browser.contexts
        if not ctxs:
            # A real CDP Chrome always has its default context; refuse rather than
            # create one we'd then have to own/close inside the user's browser.
            self._cleanup()
            raise BrowserUnavailable(
                f"Chrome at {bc.cdp_endpoint} exposed no browsing context — open a tab in it "
                "and retry.")
        self._context = ctxs[0]      # the user's real, warm default context
        self._alive = True
        for obj, ev in ((self._context, "close"), (browser, "disconnected")):
            try:
                obj.on(ev, lambda *_: setattr(self, "_alive", False))
            except Exception:
                pass
        try:
            self._context.set_default_navigation_timeout(bc.nav_timeout_ms)
            self._context.set_default_timeout(bc.nav_timeout_ms)
        except Exception:
            pass
        self.log(f"    connected to your Chrome over CDP at {bc.cdp_endpoint} "
                 f"(backend={self.backend}); driving it minimally, will leave it open")
        return self

    def __enter__(self) -> "BrowserEngine":
        sync_playwright = self._import_playwright()
        self._pw = sync_playwright().start()
        bc = self.cfg.browser
        if bc.cdp_endpoint:
            return self._enter_connected(bc)
        profile = str(self.cfg.browser_profile_path)
        Path(profile).mkdir(parents=True, exist_ok=True)
        self._set_inline_pdf_viewer(profile)   # capture PDFs via entitled fetch, not forced downloads

        patchright = self.backend == "patchright"
        # Patchright does its own (CDP-level) stealth; fighting it with custom
        # flags / a spoofed UA / a JS init-script makes it MORE detectable, so we
        # keep the launch minimal when it (or a real Chrome channel) is in play.
        use_real = patchright or bool(bc.channel)
        args = []
        if not patchright:
            args.append("--disable-blink-features=AutomationControlled")
        if sys.platform.startswith("linux"):
            args += ["--no-sandbox", "--disable-dev-shm-usage"]

        launch_kwargs = dict(
            user_data_dir=profile,
            headless=bc.headless,
            locale=bc.locale,
            timezone_id=bc.timezone_id,
            accept_downloads=True,
            args=args,
        )
        if bc.channel:
            launch_kwargs["channel"] = bc.channel
        if use_real:
            launch_kwargs["no_viewport"] = True
        else:
            launch_kwargs["user_agent"] = bc.user_agent
            launch_kwargs["viewport"] = {"width": bc.viewport_width, "height": bc.viewport_height}
        if bc.proxy:
            launch_kwargs["proxy"] = {"server": bc.proxy}


        try:
            self._context = self._pw.chromium.launch_persistent_context(**launch_kwargs)
        except Exception as e:  # noqa: BLE001
            self._cleanup()
            hint = (f"is the '{bc.channel}' browser installed?" if bc.channel
                    else f"run `python -m {self.backend} install chromium` "
                    f"in your Python environment (or `uv run {self.backend} install chromium`)")
            raise BrowserUnavailable(f"could not launch browser ({hint}): {e}") from e

        # Track liveness via the close event — more reliable than probing (the
        # user can close the window at any time in keep_open mode).
        self._alive = True
        try:
            self._context.on("close", lambda *_: setattr(self, "_alive", False))
        except Exception:
            pass

        # JS stealth shim only helps vanilla Chromium without a real channel.
        if not use_real:
            self._context.add_init_script(_STEALTH_JS)
        self._context.set_default_navigation_timeout(bc.nav_timeout_ms)
        self._context.set_default_timeout(bc.nav_timeout_ms)
        self.log(f"    browser backend={self.backend} channel={bc.channel or 'bundled'} "
                 f"headless={bc.headless}")
        return self

    def __exit__(self, *exc) -> None:
        self._cleanup()

    def is_alive(self) -> bool:
        """True if the browser context is still usable (the user may have closed
        the window in keep_open mode, which kills the underlying session)."""
        if self._context is None or not self._alive:
            return False
        try:
            _ = self._context.pages  # raises if the connection/target is closed
            return True
        except Exception:
            self._alive = False
            return False


    def open_login_page(self, url: str):
        """Open a publisher page for interactive institutional login.

        The caller deliberately retains the live page while the user completes
        SSO/2FA. Only a hostname and response status are returned; redirected SSO
        URLs can contain secrets and must never enter the download report.
        """
        if self._context is None:
            raise BrowserUnavailable("engine not started (use as context manager)")
        target = apply_ezproxy(url, self.cfg)
        # This page is for the user to LOG IN on, so open it in the foreground and
        # bring it to front — they need to see and interact with it.
        page = self._context.new_page()
        status = None
        error = None
        try:
            response = page.goto(target, wait_until="domcontentloaded",
                                 timeout=self.cfg.browser.nav_timeout_ms)
            response = self._renavigate_ezproxy_redirect(page, target, response)
            status = response.status if response else None
            try:
                page.bring_to_front()
            except Exception:
                pass
        except Exception as exc:  # keep the page open so the user can recover manually
            # Exception messages often embed the final redirected URL, whose SSO
            # query can hold a one-time token. Keep only the exception class.
            error = type(exc).__name__
        return page, {
            "start_host": urlparse(target).hostname,
            "http_status": status,
            "navigation_error": error,
        }

    def _renavigate_ezproxy_redirect(self, page, initial_url: str, response=None):
        """Route a DOI redirect's publisher destination through EZproxy.

        DOI resolver hosts themselves must stay direct, but their final publisher
        URL still needs proxy rewriting for institutional entitlement.
        """
        if not (self.cfg.browser.ezproxy_host or self.cfg.browser.ezproxy_prefix):
            return response
        try:
            final_url = page.url or initial_url
            proxied = apply_ezproxy(final_url, self.cfg)
        except Exception:
            return response
        if proxied == final_url or proxied == initial_url:
            return response
        self.log(f"    routing redirected publisher through EZproxy: {urlparse(final_url).hostname}")
        return page.goto(
            proxied,
            wait_until="domcontentloaded",
            timeout=clamp_milliseconds(self.cfg.browser.nav_timeout_ms),
        )


    @staticmethod
    def close_login_page(page) -> None:
        try:
            page.close()
        except Exception:
            pass


    def _cleanup(self) -> None:
        # Connected to the user's own Chrome (--connect-cdp): NEVER close their
        # browser, context, or tabs — just drop the connection by stopping the
        # driver (the CDP socket closes with it; Chrome keeps running).
        if self._connected:
            try:
                if self._pw:
                    self._pw.stop()
            except Exception:
                pass
            self._browser = None
            self._context = None
            self._pw = None
            self._connected = False
            return
        # Close pages first so no in-flight CDP op (e.g. request-interception
        # toggle) races a context teardown — that race is what crashes the
        # Patchright/Playwright Node driver with an uncaught rejection.
        try:
            if self._context is not None:
                for p in list(self._context.pages):
                    try:
                        p.close()
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            if self._context:
                self._context.close()
        except Exception:
            pass
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass
        self._context = None
        self._pw = None


    def trigger_zotero_save(self, page) -> bool:
        """Trigger the Zotero Connector browser extension to save the current page.

        Chrome extensions' global shortcuts (chrome.commands) do NOT respond to
        CDP synthetic keyboard events (page.keyboard.press). We must send REAL
        OS-level keystrokes to the Chrome window.

        On macOS: uses osascript to send Cmd+Shift+S to the Chrome application.
        On Linux: uses xdotool to send Ctrl+Shift+S.
        On Windows: uses PowerShell SendKeys.

        The page must be focused/visible before calling this. Returns True if
        the keystroke was sent successfully (does NOT mean the save completed —
        the caller must poll Zotero's API).
        """
        self.log("    [zotero] triggering Connector save via OS-level keystroke...")

        # Bring the page to front so it's the active tab in Chrome.
        try:
            page.bring_to_front()
            deadline_sleep(0.5)
        except Exception as e:
            self.log(f"    [zotero] could not bring page to front: {e}")

        import subprocess
        try:
            if sys.platform == "darwin":
                # macOS: AppleScript sends REAL Cmd+Shift+S to Chrome.
                script = (
                    'tell application "Google Chrome" to activate\n'
                    'delay 0.5\n'
                    'tell application "System Events"\n'
                    '    keystroke "s" using {command down, shift down}\n'
                    'end tell'
                )
                result = subprocess.run(
                    ["osascript", "-e", script],
                    capture_output=True, text=True, timeout=clamp_seconds(10.0)
                )
                if result.returncode != 0:
                    self.log(f"    [zotero] osascript failed: {result.stderr.strip()}")
                    return False
            elif sys.platform.startswith("linux"):
                # Linux: xdotool sends Ctrl+Shift+S.
                subprocess.run(
                    ["xdotool", "key", "ctrl+shift+s"],
                    capture_output=True, timeout=clamp_seconds(10.0)
                )
            else:
                # Windows: PowerShell SendKeys (fallback).
                ps_cmd = (
                    "Add-Type -AssemblyName System.Windows.Forms; "
                    "[System.Windows.Forms.SendKeys]::SendWait('^+s')"
                )
                subprocess.run(
                    ["powershell", "-Command", ps_cmd],
                    capture_output=True, timeout=clamp_seconds(10.0)
                )

            self.log("    [zotero] OS keystroke sent; waiting for Connector to react...")
            # Wait for the extension to react and initiate the save.
            deadline_sleep(3.0)
            return True
        except subprocess.TimeoutExpired:
            self.log("    [zotero] OS keystroke command timed out")
            return False
        except FileNotFoundError as e:
            self.log(f"    [zotero] command not found: {e}")
            return False
        except Exception as e:
            self.log(f"    [zotero] failed to send OS keystroke: {type(e).__name__}: {e}")
            return False


    def _open_page(self, *, background: bool = False):
        """Open a new tab.

        When ``background=True`` the tab is created via CDP ``Target.createTarget``
        with ``background:true`` so it does NOT steal the foreground — the user's
        active tab/window stays put. This works both when attached to the user's
        Chrome over CDP (browser-level session) and for a launched persistent
        context (a page-level CDP session issues the same browser-wide command).
        Falls back to a normal (foreground) ``new_page`` if the CDP path fails.
        """
        ctx = self._context
        if background and ctx is not None:
            session = None
            try:
                if self._browser is not None:
                    session = self._browser.new_browser_cdp_session()
                elif ctx.pages:
                    # Launched persistent context: no browser-level handle, but a
                    # page-level CDP session can still issue the browser-wide
                    # Target.createTarget to open an unfocused background tab.
                    session = ctx.new_cdp_session(ctx.pages[0])
                if session is not None:
                    with ctx.expect_page(timeout=15000) as pinfo:
                        session.send("Target.createTarget",
                                     {"url": "about:blank", "background": True})
                    return pinfo.value
            except Exception as e:  # noqa: BLE001
                self.log(f"    [engine] background tab open failed "
                         f"({type(e).__name__}); using a foreground tab")
            finally:
                if session is not None:
                    try:
                        session.detach()
                    except Exception:
                        pass
        return ctx.new_page()

    @staticmethod
    def _rendered_access_controls(page) -> list[tuple[object, object]]:
        """Read link/button labels and hrefs, including open shadow DOM."""
        try:
            rows = page.locator("a, button").evaluate_all(
                "els => els.slice(0, 500).map(e => ["
                "(e.innerText || e.getAttribute('aria-label') || '').trim(), "
                "e.href || e.getAttribute('href') || ''"
                "])"
            )
            return [
                (row[0], row[1])
                for row in rows
                if isinstance(row, list) and len(row) == 2
            ]
        except Exception:
            return []

    @staticmethod
    def _page_needs_institution_login(
        page, *, pdf_access_failed: bool = False
    ) -> bool:
        try:
            html = page.content()
        except Exception:
            html = ""
        try:
            url = page.url or ""
        except Exception:
            url = ""
        return looks_institution_login_required(
            html,
            url,
            acquisition_failed=True,
            pdf_access_failed=pdf_access_failed,
            rendered_controls=BrowserEngine._rendered_access_controls(page),
        )

    def _sleep(self) -> None:
        bc = self.cfg.browser
        self._sleep_interruptible(random.uniform(bc.min_delay_s, bc.max_delay_s))

    def _challenge_present(self, page, deep: bool = False,
                           nav_status: Optional[int] = None,
                           trust_widgets: bool = False,
                           trust_challenge_url: bool = True) -> bool:
        """Detect a genuine bot challenge via DOM markers (never via a loose text
        match — publisher pages legitimately load Cloudflare-CDN assets).

        Kept deliberately LIGHT (1-2 CDP calls) so polling it while the user solves
        a Turnstile/captcha does not flood the browser with automation traffic that
        the challenge's background checks can flag. ``deep`` (one-off initial check)
        and an HTTP ``nav_status`` of 403/429 add a body/source scan — the landing's
        blocked status is the strongest, most reliable bot-wall signal (DataDome /
        JSTOR return 403 even when the title/DOM markers vary).

        ``trust_challenge_url`` is True for the first snapshot so a partially
        rendered dedicated challenge route is caught. Pollers set it to False:
        Optica can retain its sessionful ``/captcha/`` URL after a successful
        submit, so the live challenge form must decide whether waiting continues.
        """
        try:
            live_url = page.url or ""
        except Exception:
            live_url = ""
        if (_sticky_challenge_url_matches(live_url)
                or (trust_challenge_url and _challenge_url_matches(live_url))):
            return True
        try:
            title = (page.title() or "").strip().lower()
        except Exception as e:  # noqa: BLE001
            _dbg.debug("challenge title read failed: %r", e)
            title = ""
        if _challenge_title_matches(title):
            return True
        try:
            live_html = page.content() or ""
        except Exception:
            live_html = ""
        article_document = _article_document_evidence(live_html, title)
        # A visible dedicated captcha frame (often nested inside an
        # Imperva/Incapsula wrapper) is a bot wall on any status. Hidden/passive
        # captcha frames are deliberately ignored: there is nothing for the user
        # to solve and they also occur on normally loaded publisher pages.
        if not article_document and _has_challenge_frame(page):
            return True
        # Some publisher CDNs report a stale/asset-level 403 while the actual
        # article DOM is already present.  Bibliographic article evidence makes
        # ambiguous status/script/widget signals non-authoritative; explicit
        # challenge titles and full-page interstitial selectors still win.
        blocked = nav_status in (403, 429) and not article_document
        # Interstitial markers (only on a full-page challenge) are trusted on any
        # status; captcha/Turnstile widgets also appear embedded in normal pages
        # (e.g. a residual Turnstile iframe on a loaded bioRxiv article), so they
        # only count as a wall when the page was actually blocked (403/429).
        try:
            if _has_visible_locator(page, _INTERSTITIAL_SELECTOR):
                return True
            # Strong verification widgets (hCaptcha / DataDome / PerimeterX) do not
            # legitimately embed in a served article page, so their presence is a
            # bot wall on ANY status — this catches 200-status "I am a real visitor"
            # hCaptcha gates that carry no interstitial title and no 403/429.
            if (not article_document
                    and _has_visible_locator(page, _STRONG_WIDGET_SELECTOR)):
                return True
            # Ambiguous Turnstile/reCAPTCHA widgets count immediately on a blocked
            # response. For an HTTP-200 PDF navigation, require a challenge shell
            # or explicit human-verification copy as corroboration: a /pdf endpoint
            # may redirect back to a normal article containing a visible login,
            # comment, or reCAPTCHA-badge widget.
            visible_widget = _has_visible_locator(page, _WIDGET_SELECTOR)
            if blocked and visible_widget:
                return True
            if trust_widgets and visible_widget:
                if _looks_like_pending_challenge_shell(page):
                    return True
                try:
                    visible_copy = page.inner_text("body") or ""
                except Exception:
                    visible_copy = ""
                if _looks_like_bot_wall(title, visible_copy):
                    return True
        except Exception:
            pass
        # A blocked landing (403/429) or the one-off deep check: scan the rendered
        # text AND the page source. DataDome's source marker is only trusted when
        # the response was actually blocked (it loads on normal pages too).
        if (deep or blocked) and not article_document:
            for getter in (lambda: page.inner_text("body"), lambda: page.content()):
                try:
                    src = getter() or ""
                except Exception:
                    continue
                if _looks_like_bot_wall(title, src, blocked=blocked):
                    return True
        return False

    def _pass_challenge(self, page, nav_status: Optional[int] = None,
                        trust_widgets: bool = False,
                        force_challenge: bool = False) -> bool:
        """Return True if no challenge, or once it clears. In a VISIBLE window we
        MUST wait for the human to solve the captcha — we stay completely hands-off
        and poll gently until it clears (up to ``challenge_human_wait_s``). Headless
        can't solve an interactive challenge, so we wait only briefly."""
        if (not force_challenge
                and not self._challenge_present(
                    page, deep=True, nav_status=nav_status,
                    trust_widgets=trust_widgets,
                )):
            # A bot-protection wrapper (e.g. Imperva/Incapsula) injects its captcha
            # CHILD frame a beat AFTER serving an empty shell page, so the first
            # snapshot can miss it. When the page looks like such a shell, poll
            # briefly for the challenge to emerge before declaring it clean.
            if not _looks_like_pending_challenge_shell(page):
                return True
            emerged = False
            emerge_deadline = time.time() + 4.0
            while time.time() < emerge_deadline:
                if not self._sleep_interruptible(1.0):
                    return False
                if self._challenge_present(page, deep=True, nav_status=nav_status,
                                           trust_widgets=trust_widgets):
                    emerged = True
                    break
            if not emerged:
                return True
        # A real bot challenge is present — record it so the report can flag this
        # item as one that required a (manual) solve, regardless of the outcome.
        self._challenge_seen = True
        headless = self.cfg.browser.headless
        # Optional automated solver (default: none). When injected it gets first
        # crack; on success we skip the human wait. Its contract: NO request
        # interception (the v7 driver crash), light CDP. See paper_dl.challenge.
        if self._solver is not None and self._try_solver(page, nav_status, headless):
            return True
        if self.cfg.autodev:
            # Unattended: never block on a human. Give a brief grace window for a
            # managed challenge to auto-clear, then bail so the item is flagged
            # "needs manual solve" and the batch moves on.
            max_wait = min(self.cfg.browser.challenge_wait_s, 10.0)
        elif headless:
            max_wait = min(self.cfg.browser.challenge_wait_s, 8.0)
        else:
            max_wait = max(self.cfg.browser.challenge_human_wait_s, 60.0)
            # The tab may have been opened in the background to avoid stealing
            # focus during a normal download. Now a human must solve a challenge,
            # so bring it to the foreground where the user can see it.
            try:
                page.bring_to_front()
            except Exception:
                pass
            self.log("    ! CAPTCHA / bot challenge detected — please solve it in the browser "
                     f"window. I will WAIT up to {int(max_wait)}s and stay completely hands-off "
                     "until you clear it.")
        deadline = time.time() + max_wait
        cleared_streak = 0
        last_note = time.time()
        while time.time() < deadline:
            if not self._sleep_interruptible(3.0):
                return False
            # Poll on the LIVE DOM only — after a solve the page reloads to 200, so
            # the stale 403 no longer applies; keep it light to not disturb the
            # captcha's own background checks.
            challenge_gone = not self._challenge_present(
                page, deep=force_challenge, trust_widgets=trust_widgets,
                trust_challenge_url=False,
            )
            # A forced AWS-WAF challenge can have an entirely empty DOM. Do not
            # call that "cleared" until the tab has actually rendered a page.
            if (challenge_gone
                    and not (force_challenge
                             and _looks_like_pending_challenge_shell(page))):
                # require two consecutive clears to avoid a transient false pass
                cleared_streak += 1
                if cleared_streak >= 2:
                    deadline_sleep(3.0)          # let cf_clearance / DataDome cookie + page settle
                    self.log("    challenge cleared — continuing.")
                    return True
            else:
                cleared_streak = 0
                if not headless and time.time() - last_note >= 30:
                    last_note = time.time()
                    self.log("    …still waiting for you to solve the captcha "
                             f"(~{int(deadline - time.time())}s left).")
        if not headless:
            self.log("    captcha still unsolved after the wait window — re-run, or in "
                     "--keep-open mode solve it and press 'r' to retry (your session is kept).")
        return False


    def _wait_challenge_cleared(self, page, nav_status: Optional[int] = None) -> bool:
        """Gate before triggering Zotero: confirm the bot challenge is cleared.

        Polls the live page: if no challenge is present the page is ready and we
        return True immediately; otherwise we keep polling (via _pass_challenge,
        which waits up to challenge_human_wait_s, checking every few seconds)
        until the human/automation clears it. Returns True only once the page is
        challenge-free, False if it never clears within the wait budget.
        """
        if not self._challenge_present(page, nav_status=nav_status):
            return True
        self.log("    [zotero] bot challenge detected — polling until it clears "
                 "before triggering the Connector...")
        return self._pass_challenge(page, nav_status=nav_status)


    def _try_solver(self, page, nav_status: Optional[int], headless: bool) -> bool:
        """Give an injected ChallengeSolver a chance to clear the wall. Returns
        True only if the solver ran AND the challenge is actually gone afterwards;
        any solver error is swallowed and we fall back to the default wait."""
        from .challenge import ChallengeContext
        try:
            title = (page.title() or "").strip()
        except Exception:
            title = ""
        budget = (min(self.cfg.browser.challenge_wait_s, 8.0) if headless
                  else max(self.cfg.browser.challenge_human_wait_s, 60.0))
        ctx = ChallengeContext(
            nav_status=nav_status, headless=headless, deadline_s=budget,
            final_url=(getattr(page, "url", "") or ""), title=title)
        self.log("    challenge solver engaged…")
        try:
            ok = bool(self._solver.solve(page, self._context, ctx))
        except Exception as e:  # noqa: BLE001
            self.log(f"    challenge solver error ({type(e).__name__}: {e}); falling back")
            return False
        if not ok:
            self.log("    challenge solver could not clear it; falling back")
            return False
        try:
            deadline_sleep(2.0)   # let cf_clearance / cookie + reload settle
        except Exception:
            pass
        if not self._challenge_present(page, trust_challenge_url=False):
            self.log("    challenge solver cleared it — continuing.")
            return True
        self.log("    challenge solver reported success but the wall is still up; falling back")
        return False

    def _request_pdf(self, url: str, referer: Optional[str]) -> Optional[bytes]:
        headers = {"Accept": "application/pdf,*/*", "Referer": referer or ""}
        try:
            resp = self._context.request.get(
                apply_ezproxy(url, self.cfg), headers=headers,
                timeout=clamp_milliseconds(
                    self.cfg.browser.pdf_request_timeout_ms
                ))
            if not resp.ok:
                return None
            body = resp.body()
            return body if is_pdf_bytes(body) else None
        except Exception as e:  # noqa: BLE001
            _dbg.debug("request_pdf failed for %s: %r", url, e)
            return None

    def _render_fulltext_pdf(self, page) -> Optional[bytes]:
        """Render an already complete OA article when its generated PDF dribbles.

        Pensoft's server-side PDF generator can take many minutes while the full
        article is already present. Chromium's print output is bounded by the
        per-paper worker deadline and retains the usable article instead of HTML.
        """
        try:
            # Pensoft places the 30k-pixel article in a same-origin iframe.
            # Chromium printing the outer shell clips that iframe to one page;
            # printing the iframe document itself paginates the whole article.
            try:
                try:
                    page.wait_for_function(
                        r"""() => {
                          const f = document.querySelector('#articleIframe');
                          return !f || (
                            f.contentDocument && f.contentDocument.body &&
                            (f.contentDocument.body.innerText || '').length > 5000
                          );
                        }""",
                        timeout=clamp_milliseconds(5_000),
                    )
                except Exception:
                    pass
                lifted = page.evaluate(r"""
                    () => {
                      const frame = document.querySelector('#articleIframe');
                      if (!frame) return 'no-frame';
                      if (!frame.contentDocument || !frame.contentDocument.body)
                        return 'frame-not-ready';
                      if ((frame.contentDocument.body.innerText || '').length < 5000)
                        return 'frame-too-short';
                      const clone = document.importNode(
                        frame.contentDocument.documentElement, true
                      );
                      let base = clone.querySelector('base');
                      if (!base) {
                        base = document.createElement('base');
                        clone.querySelector('head').prepend(base);
                      }
                      base.href = frame.src;
                      document.replaceChild(clone, document.documentElement);
                      return 'lifted';
                    }
                """)
                _dbg.debug("full-text iframe state: %s", lifted)
            except Exception as exc:  # noqa: BLE001
                _dbg.debug("could not switch to full-text iframe: %r", exc)
            page.add_style_tag(content="""
                @media print {
                    html, body, #container, .AOF, .Main-Content,
                    .P-Article-Content-Wrapper, #article-preview {
                        height: auto !important;
                        max-height: none !important;
                        overflow: visible !important;
                    }
                    .P-Article-Content-Wrapper {
                        width: 100% !important;
                        max-width: none !important;
                    }
                    #P-Article-Info-Bar, footer, .footer,
                    .cookie-policy, .cookies-policy {
                        display: none !important;
                    }
                }
            """)
            page.emulate_media(media="print")
            body = page.pdf(
                format="A4",
                print_background=True,
                prefer_css_page_size=True,
            )
            if is_pdf_bytes(body):
                # This path prints an HTML article, so a usable result must have
                # a text layer.  A publisher shell can be large enough to pass
                # the HTML heuristic while its article iframe is still empty;
                # Chromium then returns a syntactically valid one-page PDF that
                # contains only the page background.  Do not let that placeholder
                # short-circuit later full-text fallbacks.
                rendered_text = " ".join(
                    extract_text(body, max_pages=3).split()
                )
                if len(rendered_text) >= _MIN_BROWSER_RENDERED_FULLTEXT_CHARS:
                    return body
                self.log(
                    "    browser full-text PDF render contained no usable "
                    "article text "
                    f"({len(rendered_text)} < "
                    f"{_MIN_BROWSER_RENDERED_FULLTEXT_CHARS} chars); falling back"
                )
                return None
            self.log(
                "    browser full-text PDF render returned invalid bytes "
                f"(size={len(body) if body else 0})"
            )
            return None
        except Exception as exc:  # noqa: BLE001
            _dbg.debug("full-text PDF render failed: %r", exc)
            self.log(
                "    browser full-text PDF render failed: "
                f"{type(exc).__name__}: {exc}"
            )
            return None

    def _translator_pdf_urls(self, page, url: str,
                             target_doi: Optional[str] = None,
                             matching_url: Optional[str] = None) -> list[str]:
        """Run explicitly enabled, user-installed Zotero-compatible translators.

        Translator failures are deliberately isolated: upstream adapters span
        hundreds of sites and API generations, so one unsupported Zotero helper
        must never suppress the generic DOM/click acquisition paths.
        """
        self._translator_matched = False
        self._translator_name = None
        self._translator_candidate = None
        self._translator_failure_reason = None
        if not self.cfg.browser.translators_dir:
            return []
        try:
            if self._translator_registry is None:
                self._translator_registry = TranslatorRegistry(
                    Path(self.cfg.browser.translators_dir).expanduser().resolve()
                )
            remaining = remaining_seconds()
            total_timeout_ms = clamp_milliseconds(
                min(12_000, remaining * 1000)
                if remaining is not None else 12_000
            )
            report = self._translator_registry.run(
                page,
                url,
                target_doi=target_doi,
                matching_url=matching_url,
                total_timeout_ms=total_timeout_ms,
            )
        except Exception as exc:  # noqa: BLE001
            _dbg.debug("translator registry failed for %s: %r", url, exc)
            self._translator_failure_reason = "translator_failed"
            self.log(
                "    [translators] failed before returning a PDF candidate: "
                f"{type(exc).__name__}: {exc}"
            )
            return []
        self._translator_matched = bool(report.attempted)
        if report.attempted:
            self._translator_name = ", ".join(dict.fromkeys(report.attempted))
        if report.candidates:
            labels = ", ".join(dict.fromkeys(
                candidate.translator for candidate in report.candidates
            ))
            self._translator_name = labels
            self._translator_candidate = report.candidates[0].url
            self.log(
                f"    [translators] matched={labels}; "
                f"pdf_candidates={len(report.candidates)}"
            )
        elif report.attempted:
            self._translator_failure_reason = "translator_no_candidate"
            self.log(
                "    [translators] matched="
                f"{self._translator_name}; pdf_candidates=0"
            )
            _dbg.debug(
                "translators tried for %s: %s; errors=%s",
                url, report.attempted, report.errors,
            )
        else:
            self._translator_failure_reason = "translator_no_candidate"
            self.log("    [translators] matched=none; pdf_candidates=0")
        return [candidate.url for candidate in report.candidates]

    def _translator_matching_url(self, live_url: str,
                                 landing_url: Optional[str]) -> str:
        """Return an unproxied URL used only for translator target matching."""
        parsed = urlparse(live_url)
        proxy_host = (self.cfg.browser.ezproxy_host or "").lower().strip(".")
        hostname = (parsed.hostname or "").lower()
        suffix = f".{proxy_host}" if proxy_host else ""
        if suffix and hostname.endswith(suffix):
            encoded_host = hostname[:-len(suffix)]
            if encoded_host:
                canonical = parsed._replace(
                    netloc=encoded_host.replace("-", ".")
                )
                return urlunparse(canonical)
        if self.cfg.browser.ezproxy_prefix:
            nested = (parse_qs(parsed.query).get("url") or [""])[0]
            if nested.startswith(("http://", "https://")):
                return nested
        return live_url

    def _fetch_in_page(self, page, url: str) -> Optional[bytes]:
        """Fetch the PDF from inside the page's own JS context (same-origin,
        credentials included). This carries the full entitled session + Cloudflare
        clearance, so it succeeds on gated publishers (e.g. SIAM /doi/pdf) where a
        bare out-of-page request is bounced and the on-page reader yields no file."""
        js = r"""
        async ({u, timeoutMs}) => {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), timeoutMs);
          try {
            const r = await fetch(u, {credentials: 'include',
                                      headers: {'Accept': 'application/pdf,*/*'},
                                      signal: controller.signal});
            if (!r.ok) return null;
            const ct = (r.headers.get('content-type') || '').toLowerCase();
            const buf = new Uint8Array(await r.arrayBuffer());
            if (buf.length < 1024) return null;
            // must look like a PDF (%PDF) unless the server flagged it as one
            const head = String.fromCharCode.apply(null, buf.subarray(0, 5));
            if (head !== '%PDF-' && ct.indexOf('pdf') === -1) return null;
            let bin = ''; const chunk = 0x8000;
            for (let i = 0; i < buf.length; i += chunk) {
              bin += String.fromCharCode.apply(null, buf.subarray(i, i + chunk));
            }
            return btoa(bin);
          } catch (e) { return null; }
          finally { clearTimeout(timer); }
        }
        """
        try:
            b64 = page.evaluate(js, {
                "u": apply_ezproxy(url, self.cfg),
                "timeoutMs": clamp_milliseconds(
                    self.cfg.browser.pdf_request_timeout_ms
                ),
            })
        except Exception as e:  # noqa: BLE001
            _dbg.debug("in-page fetch failed for %s: %r", url, e)
            return None
        if not b64:
            return None
        try:
            data = base64.b64decode(b64)
        except Exception:
            return None
        return data if is_pdf_bytes(data) else None

    def _pdf_viewer_source_urls(self, page, fallback_url: str) -> list[str]:
        """Return HTTP(S) sources exposed by Chrome/PDF.js' inline viewer.

        Chrome can visibly render a PDF after the corresponding Playwright
        ``Response.body()`` has become unavailable.  The viewer normally retains
        the original, possibly signed URL in an ``embed`` attribute or an
        extension-viewer query parameter.  Keep the URL byte-for-byte so expiring
        ScienceDirect asset signatures are not damaged by re-encoding.
        """
        scopes = [page]
        try:
            for frame in page.frames:
                if frame not in scopes:
                    scopes.append(frame)
        except Exception:
            pass

        marker_selector = (
            "pdf-viewer, embed[type*='pdf' i], "
            "embed[type='application/x-google-chrome-pdf'], #plugin"
        )
        detected = False
        for scope in scopes:
            try:
                if scope.locator(marker_selector).count() > 0:
                    detected = True
                    break
            except Exception:
                continue
        if not detected:
            return []

        raw: list[str] = []
        try:
            current = page.url or ""
        except Exception:
            current = ""
        for scope in scopes:
            try:
                scope_url = scope.url or ""
                if scope_url and scope_url != current:
                    raw.append(scope_url)
            except Exception:
                pass
            try:
                rows = scope.locator("embed, iframe").evaluate_all(
                    "els => els.slice(0, 50).map(e => ["
                    "e.getAttribute('original-url') || '', "
                    "e.getAttribute('src') || '', "
                    "e.getAttribute('data') || '', "
                    "e.getAttribute('file') || ''"
                    "])"
                )
                for row in rows or []:
                    if isinstance(row, list):
                        raw.extend(str(value or "") for value in row)
            except Exception:
                pass
        # Prefer the viewer's concrete original-url over the public /pdfft or
        # article fallback.  On ScienceDirect the former is the minted asset URL
        # while replaying the latter can start a fresh bot-check transaction.
        raw.extend((current, fallback_url))

        out: list[str] = []

        def _add(value: str) -> None:
            value = (value or "").strip()
            if not value:
                return
            if value.startswith(("chrome-extension://", "blob:")):
                try:
                    query = parse_qs(urlparse(value).query)
                except Exception:
                    query = {}
                for key in ("file", "url", "src", "originalUrl"):
                    for nested in query.get(key, []):
                        _add(nested)
                return
            absolute = urljoin(current or fallback_url, value)
            if absolute.startswith(("http://", "https://")) and absolute not in out:
                out.append(absolute)

        for value in raw:
            _add(value)
        return out

    def _download_from_pdf_viewer(self, page) -> tuple[Optional[bytes], bool]:
        """Use an already-open native viewer's download control.

        This is deliberately attempted before replaying the viewer URL.  Signed
        publisher URLs can be single-use or navigation-only even though Chrome
        already holds and displays the complete PDF.
        """
        selectors = (
            "pdf-viewer #download",
            "viewer-toolbar #download",
            "cr-icon-button#download",
            "#download",
            "#downloadButton",
            "[aria-label*='Download' i]",
        )
        scopes = [page]
        try:
            for frame in page.frames:
                if frame not in scopes:
                    scopes.append(frame)
        except Exception:
            pass
        for scope in scopes:
            for selector in selectors:
                try:
                    loc = scope.locator(selector)
                    n = min(loc.count(), 3)
                except Exception:
                    n = 0
                for i in range(n):
                    button = loc.nth(i)
                    try:
                        if not button.is_visible():
                            continue
                    except Exception:
                        continue
                    clicked = False
                    try:
                        # Download events belong to the owning Page even when the
                        # button itself lives in Chrome's extension iframe.
                        with page.expect_download(timeout=5000) as info:
                            button.click(timeout=3000)
                            clicked = True
                        path = info.value.path()
                        if path:
                            body = Path(path).read_bytes()
                            if is_pdf_bytes(body):
                                return body, True
                    except Exception:
                        if clicked:
                            # A page-level listener may still receive a late download.
                            return None, True
                        continue
                    return None, True
        return None, False

    def _recover_pdf_viewer(self, page, fallback_url: str,
                            referer: Optional[str]) -> tuple[Optional[bytes], bool, bool]:
        """Recover bytes from a visible PDF viewer.

        Returns ``(bytes, viewer_detected, download_clicked)``.  The viewer's own
        download is the safest path; replaying source URLs is retained only as a
        fallback for viewers without an accessible toolbar.
        """
        sources = self._pdf_viewer_source_urls(page, fallback_url)
        if not sources:
            return None, False, False

        data, clicked = self._download_from_pdf_viewer(page)
        if data:
            return data, True, True

        for source in sources:
            got = self._request_pdf(source, referer)
            if not got:
                try:
                    got = self._fetch_in_page(page, source)
                except Exception:
                    got = None
            if got:
                return got, True, clicked
        return None, True, clicked

    def _navigate_capture_pdf(self, urls: list[str], wait_ms: Optional[int] = None,
                              referer: Optional[str] = None,
                              page=None) -> Optional[bytes]:
        """Open each PDF URL as a top-level navigation and capture the bytes. This
        sends genuine document-navigation headers (Sec-Fetch-Dest: document) —
        which JSTOR (and similar) require: they serve the inline PDF to a
        navigation but bounce an XHR/fetch/APIRequest of the same URL.

        ``wait_ms`` is how long to poll, per URL, for the file to arrive. Some
        publishers interpose a "your download will begin shortly" interstitial
        that only streams the PDF seconds later (LWW takes ~11s), so callers pass a
        long budget. Downloads AND PDF responses are captured context-wide so an
        attachment that lands in a popup tab still counts.

        A SINGLE reused tab handles all URLs (sharing the entitled session +
        Cloudflare clearance) — minimizing page open/close churn, which is what
        races Patchright's request-interception toggle and crashes its driver.
        When ``page`` is supplied, it is reused and remains caller-owned."""
        if not urls:
            return None
        self._navcap_needs_manual = False
        self._navcap_needs_login = False
        self._navcap_login_url = ""
        self._navcap_viewer_opened = False
        self._navcap_failure_reason = None
        budget = clamp_milliseconds(
            wait_ms if wait_ms is not None else 8000
        )   # room to spot a late bot wall
        captured: list = []
        dl: dict = {}

        def _sniff(r):
            _maybe_pdf_response(r, captured)

        def _on_dl(d):
            dl.setdefault("d", d)

        def _on_page(pg):
            try:
                pg.on("download", _on_dl)
                pg.on("response", _sniff)
            except Exception:
                pass

        owns_page = page is None
        if page is None:
            page = self._open_page(background=True)
        page.on("download", _on_dl)
        # Context-wide listeners, so a PDF/download that lands in a popup tab is
        # still caught (the context "response" event already covers `page` too).
        self._context.on("response", _sniff)
        self._context.on("page", _on_page)

        def _grab(resp) -> Optional[bytes]:
            if resp is not None:
                try:
                    b = resp.body()
                    if is_pdf_bytes(b):
                        return b
                except Exception:
                    pass
            if "d" in dl:
                try:
                    p = dl["d"].path()
                    if p:
                        b = Path(p).read_bytes()
                        if is_pdf_bytes(b):
                            return b
                except Exception:
                    pass
            for r in list(captured):
                try:
                    b = r.body()
                    if is_pdf_bytes(b):
                        return b
                except Exception:
                    continue
            return None

        try:
            for url in urls:
                if self._skip_requested():
                    return None
                captured.clear()
                dl.clear()
                target = apply_ezproxy(url, self.cfg)
                self.log(f"    (c) navigating to PDF url: {url}")
                resp = None
                try:
                    goto_kw = dict(wait_until="commit",
                                   timeout=clamp_milliseconds(
                                       self.cfg.browser.pdf_request_timeout_ms
                                   ))
                    if referer:
                        goto_kw["referer"] = referer   # some endpoints mint the token only with the article referer
                    resp = page.goto(target, **goto_kw)
                except Exception:
                    pass  # ERR_ABORTED when the navigation becomes a download/viewer
                try:
                    nav_status_c = resp.status if resp else None
                except Exception:
                    nav_status_c = None
                try:
                    target_host = (urlparse(target).hostname or "").lower()
                except Exception:
                    target_host = ""
                wiley_target = target_host.endswith(
                    "onlinelibrary.wiley.com"
                )
                deadline = time.time() + budget / 1000.0
                challenge_rounds = 0
                viewer_sources_retried = False
                viewer_download_clicked = False
                while True:
                    if self._skip_requested():
                        return None
                    # If Chrome has already rendered the document, save that
                    # loaded copy before calling Response.body() or replaying a
                    # signed URL.  ScienceDirect asset URLs can reject the second
                    # request even while the first copy remains visible.
                    viewer_sources = self._pdf_viewer_source_urls(page, target)
                    if viewer_sources:
                        self._navcap_viewer_opened = True
                    if viewer_sources and not viewer_download_clicked:
                        got, clicked = self._download_from_pdf_viewer(page)
                        if got:
                            self.log("    (c) captured PDF from the open viewer download")
                            return got
                        if clicked:
                            viewer_download_clicked = True
                            deadline = max(deadline, time.time() + 5.0)
                    data = _grab(resp)
                    if data:
                        return data
                    resp = None          # only the first body() read is valid
                    if viewer_sources and not viewer_sources_retried:
                        viewer_sources_retried = True
                        self.log("    (c) inline PDF viewer detected — recovering its source")
                        for source in viewer_sources:
                            got = self._request_pdf(source, referer)
                            if not got:
                                try:
                                    got = self._fetch_in_page(page, source)
                                except Exception:
                                    got = None
                            if got:
                                self.log("    (c) captured PDF from the viewer source")
                                return got
                    try:
                        live_url = page.url or target
                    except Exception:
                        live_url = target
                    if _wiley_pdf_redirected_to_abstract(target, live_url):
                        self._navcap_needs_login = True
                        self._navcap_login_url = live_url
                        self.log(
                            "    (c) Wiley redirected the PDF request to the "
                            "abstract page — institutional login is required"
                        )
                        return None
                    # A gated PDF navigation can itself raise an interactive bot
                    # wall (e.g. JSTOR's Cloudflare 3x3-image challenge on
                    # /stable/pdf/...). Wait for the human to solve it in the window
                    # instead of closing the tab out from under them, then
                    # re-navigate and grab the file with a fresh budget.
                    challenge_present = self._challenge_present(
                        page, nav_status=nav_status_c, trust_widgets=True
                    )
                    # CAPTCHA detection deliberately runs first. Wiley access
                    # pages can nevertheless carry challenge-like widgets on an
                    # HTTP-403 response. If the rendered page simultaneously has
                    # conclusive institutional-login evidence, the challenge
                    # signal is a false positive and must not prompt the user.
                    wiley_needs_login = (
                        wiley_target
                        and self._page_needs_institution_login(
                            page, pdf_access_failed=True
                        )
                    )
                    if challenge_present and wiley_needs_login:
                        self._navcap_needs_login = True
                        self._navcap_login_url = live_url
                        self.log(
                            "    (c) Wiley institutional-login page carried a "
                            "challenge-like marker — treating it as login, not CAPTCHA"
                        )
                        return None
                    if challenge_present:
                        if challenge_rounds >= 1:
                            self._navcap_needs_manual = True
                            self._navcap_failure_reason = "captcha_loop"
                            self.log(
                                "    (c) bot challenge reappeared on the same PDF "
                                "URL after one solve — marking captcha_loop"
                            )
                            return None
                        challenge_rounds += 1
                        if self.cfg.autodev:
                            self._navcap_needs_manual = True
                            self.log(
                                "    (c) bot challenge on the PDF tab — giving the "
                                "managed check a brief auto-clear window; otherwise "
                                "skip in --autodev (needs manual solve)"
                            )
                        else:
                            self.log("    (c) bot challenge on the PDF tab — waiting for you "
                                     "to solve it, then I'll grab the file…")
                        cleared = self._pass_challenge(
                            page,
                            nav_status=nav_status_c,
                            trust_widgets=True,
                        )
                        if not cleared:
                            self._navcap_needs_manual = True
                            self._navcap_failure_reason = "captcha_unresolved"
                            return None

                        # ScienceDirect can transition directly from the solved
                        # challenge into Chrome's native PDF viewer. Preserve that
                        # already-loaded, potentially one-use copy BEFORE issuing
                        # any API/fetch replay or navigating /pdfft again.
                        try:
                            page.wait_for_timeout(500)
                        except Exception:
                            pass
                        data = _grab(None)
                        if data:
                            self.log(
                                "    (c) captured PDF delivered while the "
                                "challenge cleared"
                            )
                            return data
                        viewer_data, viewer_detected, viewer_clicked = (
                            self._recover_pdf_viewer(page, target, referer)
                        )
                        if viewer_detected:
                            self._navcap_viewer_opened = True
                            viewer_sources_retried = True
                            viewer_download_clicked = (
                                viewer_download_clicked or viewer_clicked
                            )
                            if viewer_data:
                                self.log(
                                    "    (c) captured PDF from the viewer opened "
                                    "after challenge solve"
                                )
                                return viewer_data
                            # Keep the loaded viewer intact while a toolbar
                            # download event finishes; never destroy it by
                            # replaying the public /pdfft URL.
                            deadline = max(deadline, time.time() + 5.0)
                            continue

                        # No viewer appeared. The clearance cookie is now banked,
                        # so try the entitled request before one bounded re-nav.
                        got = (
                            self._request_pdf(target, referer)
                            or self._fetch_in_page(page, target)
                        )
                        if got:
                            self.log(
                                "    (c) captured the PDF via the entitled "
                                "request after solve"
                            )
                            return got
                        try:
                            resp = page.goto(target, **goto_kw)
                            try:
                                nav_status_c = resp.status if resp else None
                            except Exception:
                                nav_status_c = None
                        except Exception:
                            self.log(
                                "    (c) re-navigation failed after challenge solve"
                            )
                            break  # exit polling loop for this URL, try next
                        deadline = time.time() + max(budget, 20_000) / 1000.0
                        continue
                    if wiley_needs_login:
                        self._navcap_needs_login = True
                        self._navcap_login_url = live_url
                        self.log(
                            "    (c) Wiley PDF endpoint requires institutional login"
                        )
                        return None
                    if time.time() >= deadline:
                        # Some platforms put the authentication gate only on the
                        # PDF endpoint. Preserve that evidence before this
                        # temporary capture tab is closed (JoVE is one example).
                        try:
                            access_html = page.content()
                        except Exception:
                            access_html = ""
                        try:
                            access_url = page.url or target
                        except Exception:
                            access_url = target
                        if looks_institution_login_required(
                            access_html,
                            access_url,
                            acquisition_failed=True,
                            pdf_access_failed=True,
                            rendered_controls=self._rendered_access_controls(page),
                        ):
                            self._navcap_needs_login = True
                            self._navcap_login_url = access_url
                            self.log(
                                "    (c) PDF endpoint requires institutional login"
                            )
                            return None
                        break
                    try:
                        page.wait_for_timeout(400)
                    except Exception:
                        break
        finally:
            try:
                self._context.remove_listener("response", _sniff)
            except Exception:
                pass
            try:
                self._context.remove_listener("page", _on_page)
            except Exception:
                pass
            try:
                page.wait_for_timeout(200)   # let in-flight CDP ops settle
            except Exception:
                pass
            if owns_page:
                try:
                    page.close()
                except Exception:
                    pass
        return None

    def _click_accept_modal(self, page) -> bool:
        """Click an 'Accept and download' / 'Accept' confirmation in a Terms &
        Conditions modal that some publishers (e.g. JSTOR) pop up after the first
        download click. Returns True if such a control was clicked."""
        try:
            page.wait_for_timeout(700)   # let the modal render
        except Exception:
            pass
        for role in ("button", "link"):
            try:
                loc = page.get_by_role(role, name=_ACCEPT_TEXT_RE)
                n = min(loc.count(), 3)
            except Exception:
                n = 0
            for i in range(n):
                el = loc.nth(i)
                try:
                    if el.is_visible():
                        el.click(timeout=3000)
                        return True
                except Exception:
                    continue
        return False

    def _click_pdf_menu_item(self, page) -> bool:
        """After a "Download" control opens a format menu (PDF / EPUB / …), click
        the PDF item and never EPUB. Used by LWW / journals.lww.com and similar."""
        try:
            page.wait_for_timeout(800)   # let the menu render
        except Exception:
            pass
        for role in ("menuitem", "link", "button"):
            try:
                loc = page.get_by_role(role, name=_PDF_MENU_RE)
                n = min(loc.count(), 6)
            except Exception:
                n = 0
            for i in range(n):
                el = loc.nth(i)
                try:
                    name = (el.inner_text() or el.get_attribute("aria-label") or "").lower()
                    if "epub" in name:        # never pick EPUB
                        continue
                    if el.is_visible():
                        self.log("    selecting 'PDF' from the Download menu")
                        el.click(timeout=3000)
                        return True
                except Exception:
                    continue
        return False

    def _click_for_pdf(self, page, referer: Optional[str],
                       tried: Optional[set] = None, max_clicks: int = 2
                       ) -> ClickPDFResult:
        """Click a visible PDF / Download / Full-Text control and capture the
        resulting PDF, however it arrives: a download event, a Terms&Conditions
        modal's "Accept and download", an inline PDF in a popup tab, or a same-tab
        navigation. A context-wide response sniffer catches any application/pdf
        response during the click-through (the robust path for SPA publishers like
        JSTOR that open the PDF inline rather than firing a download).

        Bounded for speed (<= ``max_clicks`` clicks).  The structured result
        deliberately keeps a visible control distinct from a concrete PDF URL
        and from a viewer that opened without yielding bytes."""
        from urllib.parse import urljoin, urlparse

        tried = set(tried or ())
        self._click_viewer_opened = False
        landing_page = page
        landing_host = urlparse(page.url).netloc

        # --- response sniffer: collect any PDF responses anywhere in the context
        pdf_responses = []
        pdf_downloads = []

        def _sniff(resp):
            try:
                ct = ""
                try:
                    ct = (resp.headers or {}).get("content-type", "").lower()
                except Exception:
                    pass
                u = (resp.url or "")
                if "application/pdf" in ct or u.lower().split("?")[0].endswith(".pdf"):
                    pdf_responses.append(resp)
            except Exception:
                pass

        def _on_download(download):
            pdf_downloads.append(download)

        def _on_page(pg):
            try:
                pg.on("download", _on_download)
                pg.on("response", _sniff)
            except Exception:
                pass

        def _harvest():
            for download in list(pdf_downloads):
                try:
                    path = download.path()
                    if path:
                        body = Path(path).read_bytes()
                        if is_pdf_bytes(body):
                            return body
                except Exception:
                    continue
            for resp in list(pdf_responses):
                try:
                    body = resp.body()
                    if is_pdf_bytes(body):
                        return body
                except Exception:
                    continue
            return None

        try:
            self._context.on("response", _sniff)
            self._context.on("page", _on_page)
            page.on("download", _on_download)
        except Exception:
            pass

        # Wait briefly for a late-rendered Download/PDF control (LWW injects its
        # "Download" button via JS after load).
        try:
            page.get_by_role("button", name=_PDF_TEXT_RE).first.wait_for(timeout=4000)
        except Exception:
            try:
                page.get_by_role("link", name=_PDF_TEXT_RE).first.wait_for(timeout=2000)
            except Exception:
                pass

        elements = []
        for role, cap in (("link", 8), ("button", 6)):
            try:
                loc = page.get_by_role(role, name=_PDF_TEXT_RE)
                for i in range(min(loc.count(), cap)):
                    elements.append(loc.nth(i))
            except Exception:
                continue
        try:
            loc = page.locator("a[href*='pdf' i]")
            for i in range(min(loc.count(), 8)):
                elements.append(loc.nth(i))
        except Exception:
            pass

        outcome = ClickPDFResult()
        clicks = 0
        seen_href: set[str] = set()
        before = list(self._context.pages)
        result = None
        capture_source = None
        captured_url = None
        try:
            for el in elements:
                if clicks >= max_clicks:
                    break
                try:
                    if not el.is_visible():
                        continue
                except Exception:
                    continue
                href = None
                try:
                    href = el.get_attribute("href")
                except Exception:
                    pass
                if href:
                    absu = urljoin(page.url, href)
                    if absu in seen_href:
                        continue
                    seen_href.add(absu)
                    if is_supplement_url(absu):   # never click through to a supplement
                        continue
                    outcome.found_control = True
                    outcome.found_direct_url = True
                    outcome.pdf_url = outcome.pdf_url or absu
                    if absu in tried:   # already fetched & failed; clicking re-hits it
                        continue
                else:
                    outcome.found_control = True

                clicks += 1
                self.log("    clicking a PDF/Download control…")
                try:
                    el.scroll_into_view_if_needed(timeout=2000)
                except Exception:
                    pass
                # (a) click; handle a follow-up T&C modal OR a Download->PDF menu;
                #     capture the resulting download.
                try:
                    with page.expect_download(timeout=12000) as di:
                        el.click(timeout=4000)
                        if self._click_accept_modal(page):
                            self.log("    accepted a Terms & Conditions modal")
                        self._click_pdf_menu_item(page)
                    d = di.value
                    p = d.path()
                    if p:
                        data = Path(p).read_bytes()
                        if is_pdf_bytes(data):
                            result = data
                            capture_source = "direct_download"
                            captured_url = getattr(d, "url", None) or outcome.pdf_url
                            break
                except Exception:
                    pass
                # (b) the modal / menu may have appeared without a download event
                try:
                    self._click_accept_modal(page)
                    self._click_pdf_menu_item(page)
                except Exception:
                    pass
                try:
                    page.wait_for_timeout(1500)
                except Exception:
                    pass
                # (c) a sniffed application/pdf response (inline viewer / xhr)
                data = _harvest()
                if data:
                    self.log("    captured PDF from a network response")
                    result = data
                    capture_source = "pdf_response"
                    captured_url = (
                        getattr(pdf_responses[-1], "url", None)
                        if pdf_responses else None
                    )
                    break
                # (d) popup tab or same-tab navigation to the PDF URL
                new_pages = [pg for pg in self._context.pages if pg not in before]
                viewer_seen = False
                urls = []
                for tp in new_pages + [page]:
                    try:
                        if tp.is_closed():
                            continue
                        u = tp.url
                    except Exception:
                        continue
                    if u and not u.startswith("about:"):
                        viewer_data, detected, viewer_clicked = self._recover_pdf_viewer(
                            tp, u, referer
                        )
                        if detected:
                            viewer_seen = True
                            self._click_viewer_opened = True
                            outcome.viewer_opened = True
                            outcome.viewer_url = u
                            self.log("    open PDF viewer detected after click")
                        if viewer_data:
                            self.log("    captured PDF from the open viewer")
                            result = viewer_data
                            capture_source = "viewer_capture"
                            captured_url = u
                            break
                        if viewer_clicked:
                            try:
                                tp.wait_for_timeout(500)
                            except Exception:
                                pass
                            viewer_data = _harvest()
                            if viewer_data:
                                self.log("    captured late download from the open viewer")
                                result = viewer_data
                                capture_source = "viewer_capture"
                                captured_url = u
                                break
                        urls.append(u)
                if not result and not viewer_seen:
                    for u in urls:
                        data = self._request_pdf(u, referer)
                        if not data and landing_host and urlparse(u).netloc == landing_host:
                            # same-origin: fetch through the landing page's session
                            try:
                                if not landing_page.is_closed():
                                    data = self._fetch_in_page(landing_page, u)
                            except Exception:
                                data = None
                        if data:
                            result = data
                            capture_source = "direct_request"
                            captured_url = u
                            break
                if viewer_seen and not result:
                    self.log(
                        "    PDF viewer opened, but no bytes were captured; "
                        "keeping the popup alive for a final download poll"
                    )
                    try:
                        page.wait_for_timeout(1000)
                    except Exception:
                        pass
                    result = _harvest()
                # close popups one at a time, letting interception toggles settle
                for pg in new_pages:
                    try:
                        if pg.is_closed():
                            continue
                        pg.wait_for_timeout(150)
                        pg.close()
                    except Exception:
                        pass
                if result:
                    break

            if not result:
                # a download/response may still be in flight
                try:
                    page.wait_for_timeout(1500)
                except Exception:
                    pass
                result = _harvest()
        finally:
            try:
                self._context.remove_listener("response", _sniff)
            except Exception:
                pass
            try:
                self._context.remove_listener("page", _on_page)
            except Exception:
                pass
        outcome.data = result
        outcome.pdf_captured = bool(result)
        outcome.pdf_url = captured_url or outcome.pdf_url or outcome.viewer_url
        outcome.acquisition_source = capture_source
        if not result:
            outcome.failure_reason = (
                "viewer_open_capture_failed"
                if outcome.viewer_opened
                else "download_failed"
                if outcome.found_control
                else "no_pdf_control"
            )
        return outcome

    def _ieee_fetch(self, page, final_url: str, html: str, referer: Optional[str]) -> Optional[bytes]:
        """Compatibility delegate to the reviewed IEEE publisher adapter."""
        adapter = get_publisher_adapter("ieee")
        if adapter is None or adapter.run_browser_flow is None:
            return None
        return adapter.run_browser_flow(
            self,
            page=page,
            final_url=final_url,
            html=html,
            referer=referer,
        )

    def _lww_fetch(self, page, html: str, referer: Optional[str]) -> Optional[bytes]:
        """Compatibility delegate to the reviewed LWW publisher adapter."""
        adapter = get_publisher_adapter("lww")
        if adapter is None or adapter.run_browser_flow is None:
            return None
        return adapter.run_browser_flow(
            self,
            page=page,
            final_url=getattr(page, "url", ""),
            html=html,
            referer=referer,
        )

    def _try_navigate_pdf_candidates(
        self,
        urls: list[str],
        referer: Optional[str],
        result: EngineResult,
        page=None,
    ) -> bool:
        """Try document-navigation PDF capture and update ``result``.

        Return ``True`` when the outcome is terminal for this browser candidate:
        PDF bytes were captured, login is required, or an interactive challenge
        remains. A plain capture miss returns ``False`` so request/fetch/click
        fallbacks can still run without repeating the same navigation URL.
        """
        if not urls:
            return False
        self.log(f"    (c) navigate-capture for {len(urls)} url(s)")
        try:
            data = self._navigate_capture_pdf(urls, referer=referer, page=page)
        except Exception as exc:  # noqa: BLE001
            self.log(f"    (c) navigate-capture error: {exc}")
            data = None
        result.viewer_opened = (
            result.viewer_opened
            or bool(getattr(self, "_navcap_viewer_opened", False))
        )
        if data:
            result.ok, result.data, result.pdf_url = True, data, urls[0]
            result.acquisition_source = (
                "viewer_capture"
                if bool(getattr(self, "_navcap_viewer_opened", False))
                else "browser_navigation"
            )
            result.detail = f"ok via navigate-capture {urls[0]}"
            return True
        if getattr(self, "_navcap_needs_login", False):
            result.needs_login = True
            result.final_url = (
                getattr(self, "_navcap_login_url", "") or result.final_url
            )
            result.detail = (
                "institutional login required before this publisher "
                "will provide the PDF"
            )
            self.log(f"    no PDF: {result.detail}")
            return True
        if getattr(self, "_navcap_needs_manual", False):
            result.blocked = True
            result.needs_manual = True
            result.failure_reason = getattr(
                self, "_navcap_failure_reason", None
            ) or "captcha_unresolved"
            if result.failure_reason == "captcha_loop":
                result.detail = (
                    "captcha_loop: bot challenge reappeared on the same PDF "
                    "URL after it was solved once"
                )
            else:
                result.detail = (
                    "bot challenge on PDF tab needs manual solve "
                    "(skipped in --autodev)"
                    if self.cfg.autodev
                    else "bot challenge on PDF tab was not cleared"
                )
            return True
        return False

    # -- main entry ----------------------------------------------------------
    def attempt(self, cand: Candidate) -> EngineResult:
        check_item_deadline()
        if self._context is None:
            raise BrowserUnavailable("engine not started (use as context manager)")

        page = self._open_page(background=True)
        result = EngineResult(ok=False)
        try:
            if self._skip_requested():
                result.detail = "paper skipped by user"
                return result
            html = ""
            nav_ct = ""            # landing response content-type (spots a direct-PDF redirect)
            nav_status = None      # landing HTTP status (403 -> access denied, 404 -> not found)
            nav_error = ""         # browser-level navigation error, when page.goto raises
            challenge_seen = False # a bot wall was detected on the landing (403 is then the challenge, not a verdict)
            waf_challenge = False  # AWS WAF: HTTP 202 + x-amzn-waf-action: challenge
            forced_challenge = False
            passed = True
            referer = cand.referer or cand.landing_url
            if cand.landing_url:
                self.log(f"    [{cand.label}] opening landing: {cand.landing_url}")
                nav_resp = None
                try:
                    nav_resp = page.goto(
                        apply_ezproxy(cand.landing_url, self.cfg),
                        wait_until="domcontentloaded",
                        timeout=clamp_milliseconds(self.cfg.browser.nav_timeout_ms),
                    )
                    nav_resp = self._renavigate_ezproxy_redirect(
                        page,
                        apply_ezproxy(cand.landing_url, self.cfg),
                        nav_resp,
                    )
                except Exception as e:  # noqa: BLE001
                    nav_error = str(e)
                    result.detail = f"landing nav failed: {e}"
                    self.log(f"    landing nav error: {e}")
                    reason, detail = landing_terminal_verdict(
                        None, "", None, navigation_error=nav_error
                    )
                    if reason == "url_error":
                        result.url_error = True
                        result.url_error_detail = detail
                        result.detail = detail
                        result.final_url = cand.landing_url
                        self.log(f"    [{cand.label}] {detail} Skipping browser work.")
                        return result
                self._sleep()
                if self._skip_requested():
                    result.detail = "paper skipped by user"
                    return result
                try:
                    if nav_resp:
                        nav_status = nav_resp.status
                        nav_headers = nav_resp.headers or {}
                        nav_ct = nav_headers.get("content-type", "").lower()
                        waf_challenge = _response_is_waf_challenge(nav_headers)
                        # ScienceDirect serves a bare 403 shell before its bot
                        # check, without dependable DOM/vendor markers. The PII
                        # is valid; let attended mode clear the wall.
                        forced_challenge = waf_challenge
                except Exception:
                    nav_status = None
                result.http_status = nav_status
                if nav_status in (403, 429) or forced_challenge:
                    self.log(f"    landing returned HTTP {nav_status} — likely a bot wall / captcha")

                # Read the DOM once before challenge handling. Static server/block
                # pages and authoritative not-found pages are terminal, so there
                # is no value in waiting for a captcha, searching PDF controls, or
                # attempting downloads against them.
                try:
                    initial_html = page.content()
                    initial_url = page.url
                    initial_title = extract_title(initial_html)
                except Exception:
                    initial_html = ""
                    initial_url = cand.landing_url
                    initial_title = None
                if (nav_status == 403 and cand.publisher == "sciencedirect"
                        and not _article_document_evidence(
                            initial_html, initial_title or ""
                        )):
                    forced_challenge = True
                mismatch_detail = landing_identity_mismatch(
                    cand.target_doi or "", initial_html, initial_url
                )
                if mismatch_detail:
                    result.final_url = initial_url
                    result.title = initial_title
                    result.landing_html = initial_html
                    result.identity_mismatch = True
                    result.identity_mismatch_detail = mismatch_detail
                    result.failure_reason = "identifier_mismatch"
                    result.detail = mismatch_detail
                    self.log(f"    [{cand.label}] {mismatch_detail}")
                    return result
                reason, detail = (
                    (None, "")
                    if forced_challenge and not _is_browser_error_url(initial_url)
                    else landing_terminal_verdict(
                        nav_status, initial_html, initial_title,
                        navigation_error=nav_error,
                        final_url=initial_url,
                    )
                )
                if reason:
                    result.final_url = initial_url
                    result.title = initial_title
                    result.landing_html = initial_html
                    result.not_found = reason == "not_found"
                    result.url_error = reason == "url_error"
                    result.url_error_detail = detail if result.url_error else ""
                    result.detail = detail
                    self.log(f"    [{cand.label}] {detail} Skipping browser work.")
                    return result

                challenge_seen = (
                    forced_challenge
                    or self._challenge_present(page, nav_status=nav_status)
                )
                if challenge_seen:
                    self.log("    bot challenge present — waiting for it to clear"
                             + ("/solve it in the window" if not self.cfg.browser.headless else ""))
                passed = self._pass_challenge(
                    page,
                    nav_status=nav_status,
                    force_challenge=forced_challenge,
                )
                if self._skip_requested():
                    result.detail = "paper skipped by user"
                    return result
                self.log("    challenge cleared" if passed else "    challenge did NOT clear")
                try:
                    html = page.content()
                    result.final_url = page.url
                    result.title = extract_title(html)
                    result.landing_html = html
                    referer = page.url or referer
                    self.log(f"    landed on: {page.url}")
                except Exception:
                    pass
                result.paywalled = (not _is_browser_error_url(result.final_url)
                                    and looks_paywalled(html))
                # Pensoft journal articles are open access. Its page contains
                # generic account/subscription navigation that trips the broad
                # paywall heuristic even though the full article is rendered.
                if cand.publisher == "pensoft" or cand.open_access:
                    result.paywalled = False

                # A redirect or cleared challenge may finish on a static error or
                # article-not-found page. Re-check the final rendered landing
                # before running any PDF acquisition strategy.
                reason, detail = (
                    (None, "")
                    if challenge_seen and not passed and not _is_browser_error_url(result.final_url)
                    else landing_terminal_verdict(None, html, result.title,
                                                  final_url=result.final_url)
                )
                if reason:
                    if (reason == "url_error" and challenge_seen
                            and not _is_browser_error_url(result.final_url)):
                        result.blocked = True
                        result.needs_manual = self.cfg.autodev
                        result.failure_reason = "captcha_unresolved"
                        result.detail = (
                            "bot protection returned a static block page after "
                            "the challenge transition"
                        )
                        self.log(
                            f"    [{cand.label}] {result.detail}; treating it as "
                            "challenge evidence, not a publisher URL error"
                        )
                        return result
                    result.not_found = reason == "not_found"
                    result.url_error = reason == "url_error"
                    result.url_error_detail = detail if result.url_error else ""
                    result.detail = detail
                    self.log(f"    [{cand.label}] {detail} Skipping browser work.")
                    return result

                # Explicit institution-to-content gates need no failed PDF probe
                # for confirmation. Catch them before challenged PDF endpoints
                # consume the paper deadline; terse gates are still deferred to
                # the post-acquisition check below.
                if (not cand.open_access and looks_institution_login_required(
                    html, result.final_url or ""
                )):
                    result.needs_login = True
                    result.detail = (
                        "institutional login required before this publisher "
                        "will provide the PDF"
                    )
                    self.log(f"    [{cand.label}] no PDF: {result.detail}")

            # --- Zotero Connector: trigger save while the page is still alive ---
            # If Zotero is enabled and the page landed on a real article (not a
            # 404 / bot wall), trigger the Connector extension via its keyboard
            # shortcut. The Connector reads the live DOM, identifies the paper
            # via its translator, and tells Zotero desktop to download the PDF
            # using the browser's full session cookies. We wait briefly for the
            # extension to capture the page, then let the page close normally.
            if (self.cfg.zotero.enabled
                    and not cand.requires_strict_identity
                    and not result.not_found
                    and not result.url_error
                    and not result.blocked
                    and cand.landing_url):
                self.log("    [zotero] triggering Connector save on the live page...")
                if self.trigger_zotero_save(page):
                    result.zotero_triggered = True
                    self.log("    [zotero] Connector triggered — page data captured")
                    # Keep the page ALIVE while Zotero downloads the PDF. Zotero
                    # fetches the full-text PDF using the live browser session, so
                    # the tab must stay open until the download finishes (the
                    # page is closed by the finally block below only afterwards).
                    if self.zotero_wait_fn is not None:
                        self.log("    [zotero] keeping page alive while Zotero downloads the PDF...")
                        try:
                            if self.zotero_wait_fn():
                                result.zotero_pdf_ready = True
                                self.log("    [zotero] Zotero finished downloading the PDF")
                            else:
                                self.log("    [zotero] Zotero did not finish the PDF download in time")
                        except Exception as e:
                            self.log(f"    [zotero] error while waiting for Zotero PDF: {e}")

                    return result

            # Bespoke publisher handlers run BEFORE the "blocked" early-return:
            # challenge detection can false-negative (a solved page still flagged),
            # and these read the LIVE DOM, so give them a shot regardless.

            # IEEE bespoke stamp.jsp -> ielx flow.
            if cand.publisher == "ieee":
                data = self._ieee_fetch(page, result.final_url or cand.landing_url or "", html, referer)
                if data:
                    result.ok, result.data, result.found_link = True, data, True
                    result.pdf_url = result.final_url
                    result.detail = "ok via IEEE stamp/ielx"
                    return result

            # LWW / Wolters Kluwer downloadpdf.aspx -> interstitial -> pdfs.* flow.
            if cand.publisher == "lww" or "journals.lww.com" in (result.final_url or ""):
                data = self._lww_fetch(page, html, referer)
                if data:
                    result.ok, result.data, result.found_link = True, data, True
                    result.pdf_url = result.final_url
                    result.detail = "ok via LWW downloadpdf.aspx"
                    return result

            # Bespoke handlers didn't yield a PDF; if the page is still behind an
            # unsolved challenge and we have no direct PDF URL, report blocked now.
            if cand.landing_url and not passed and not cand.pdf_url:
                result.blocked = True
                result.needs_manual = self.cfg.autodev
                result.detail = ("bot challenge needs manual solve (skipped in --autodev)"
                                 if self.cfg.autodev else "bot challenge not cleared")
                return result

            # Build an ordered, de-duplicated PDF URL list: the candidate's known
            # (publisher) URL first, then citation_pdf_url + discovered links.
            pdf_urls: list[str] = []
            if cand.pdf_url:
                pdf_urls.append(cand.pdf_url)
            # The DOI/landing may redirect STRAIGHT to a PDF file (the page IS the
            # PDF — e.g. an OA journal serving Paper1234.pdf directly, which Chrome
            # renders in its viewer so there's no link to discover). The landed URL
            # is then the file itself; fetch it via the request path below.
            final = result.final_url or ""
            if final and final not in pdf_urls and _looks_like_pdf_url(final, nav_ct):
                self.log(f"    landed directly on a PDF: {final}")
                pdf_urls.append(final)
            if html:
                disc = find_pdf_links(
                    html,
                    result.final_url or cand.landing_url or "",
                    cand.publisher,
                    target_doi=cand.target_doi,
                )
                result.discovered = disc
                for u in disc:
                    if u not in pdf_urls:
                        pdf_urls.append(u)

            wiley_navigation = (
                (cand.publisher or "").lower() == "wiley"
                or (urlparse(result.final_url or "").hostname or "").lower()
                .endswith("onlinelibrary.wiley.com")
            )
            if wiley_navigation:
                pdf_urls = _canonicalize_wiley_pdf_urls(
                    pdf_urls, result.final_url or cand.landing_url or ""
                )

            if pdf_urls:
                result.found_link = True
                self.log(f"    found {len(pdf_urls)} candidate PDF url(s); first: {pdf_urls[0]}")
            else:
                self.log("    no PDF url discovered on the page yet")

            final_host = urlparse(result.final_url or "").netloc.lower()
            sciencedirect_navigation_first = (
                "sciencedirect" in final_host
                or any(
                    "sciencedirect.com/science/article/pii/" in u.lower()
                    and "/pdfft" in u.lower()
                    for u in pdf_urls
                )
            )
            navigated_pdf_urls: set[str] = set()

            # These OA platforms expose complete article HTML but throttle large
            # generated/static PDF streams severely. In unattended batches,
            # Chromium printing is a fast, bounded primary-paper PDF fallback.
            render_oa_fulltext = (
                self.cfg.autodev
                and (cand.publisher or "").lower() in {"pensoft", "copernicus"}
                and bool(html and passed)
            )
            if render_oa_fulltext:
                self.log(
                    f"    (a0) rendering complete {cand.publisher} OA article as PDF"
                )
                data = self._render_fulltext_pdf(page)
                if data:
                    result.ok, result.data = True, data
                    result.pdf_url = result.final_url or cand.landing_url
                    result.detail = (
                        f"ok via browser-rendered {cand.publisher} full text"
                    )
                    return result
                if (cand.publisher or "").lower() == "pensoft":
                    result.detail = (
                        "Pensoft full-text PDF render failed; retaining complete "
                        "OA HTML instead of entering its unbounded PDF stream"
                    )
                    return result

            # ScienceDirect's /pdfft is a document endpoint. Sending APIRequest
            # and fetch probes first gives it XHR-style headers, adds two needless
            # WAF transactions, and can consume a short-lived asset token. Use a
            # real top-level navigation first; ordinary request/fetch remain as
            # bounded fallbacks if navigation simply misses without a challenge.
            if (pdf_urls and html and passed
                    and sciencedirect_navigation_first):
                navigation_urls = pdf_urls[:2]
                navigated_pdf_urls.update(navigation_urls)
                if self._try_navigate_pdf_candidates(
                    navigation_urls, referer, result
                ):
                    return result

            # (a) fast out-of-page request (works for open access / direct files).
            # If this fails, the engine falls back to:
            #   (b) in-page fetch with the entitled browser session,
            #   (c) navigate-capture for JSTOR/LWW/interstitial flows,
            #   (d) click-for-pdf on PDF/Download controls,
            # before reporting the final acquisition result.
            # Pensoft's generated PDF endpoint can dribble a large file for many
            # minutes. In unattended mode make one bounded request, then retain
            # its OA article HTML instead of repeating equivalent slow endpoints.
            request_limit = (
                1
                if self.cfg.autodev and cand.publisher == "pensoft"
                else 6
            )
            requested_pdf_urls: set[str] = set()
            for u in pdf_urls[:request_limit]:
                self.log(f"    (a) request: {u}")
                requested_pdf_urls.add(u)
                data = self._request_pdf(u, referer)
                if data:
                    result.ok, result.data, result.pdf_url = True, data, u
                    result.acquisition_source = "direct_request"
                    result.detail = f"ok via request {u}"
                    return result

            # Only pay the translator cost after known resolver/DOM candidates
            # fail (or when there were none). The translated URLs still join the
            # same in-page, navigation-capture, and click fallbacks below.
            translated: list[str] = []
            if html and passed and self.cfg.browser.translators_dir:
                translator_url = result.final_url or cand.landing_url or ""
                translated = self._translator_pdf_urls(
                    page,
                    translator_url,
                    target_doi=cand.target_doi,
                    matching_url=self._translator_matching_url(
                        translator_url, cand.landing_url
                    ),
                )
                translated = list(dict.fromkeys(translated))
                if wiley_navigation:
                    translated = _canonicalize_wiley_pdf_urls(
                        translated, result.final_url or cand.landing_url or ""
                    )
                result.translator_matched = bool(
                    getattr(self, "_translator_matched", False)
                )
                result.translator_name = getattr(
                    self, "_translator_name", None
                )
                result.translator_candidate = getattr(
                    self, "_translator_candidate", None
                )
                if not translated:
                    result.failure_reason = getattr(
                        self, "_translator_failure_reason", None
                    )
                if translated:
                    # Promote every translator-confirmed URL, including one
                    # that generic DOM discovery already placed late in a long
                    # list. This keeps it reachable by the bounded in-page and
                    # navigation fallbacks without requesting any URL twice.
                    translated_set = set(translated)
                    pdf_urls = translated + [
                        u for u in pdf_urls if u not in translated_set
                    ]
                    result.found_link = True
                    translator_requests = 0
                    for u in translated:
                        if u in requested_pdf_urls:
                            continue
                        self.log(f"    (a) translator request: {u}")
                        requested_pdf_urls.add(u)
                        translator_requests += 1
                        data = self._request_pdf(u, referer)
                        if data:
                            result.ok, result.data, result.pdf_url = True, data, u
                            result.acquisition_source = "translator"
                            result.detail = f"ok via translator request {u}"
                            return result
                        if translator_requests >= 2:
                            break

            # It is worth trying a known direct URL despite a challenged landing:
            # public PDFs can still work. If it did not, preserve the real blocker
            # instead of downgrading the item to a generic download failure.
            if cand.landing_url and challenge_seen and not passed:
                result.blocked = True
                result.needs_manual = self.cfg.autodev
                result.detail = (
                    "bot challenge needs manual solve (skipped in --autodev)"
                    if self.cfg.autodev else "bot challenge not cleared"
                )
                return result

            # (b) in-page fetch with browser session cookies (entitled access).
            # Uses the page's live JS context with credentials:include — works
            # for publishers (SIAM, Nature, Oxford) where bare HTTP is bounced.
            skip_slow_pensoft_in_page = (
                self.cfg.autodev and cand.publisher == "pensoft"
            )
            if skip_slow_pensoft_in_page and pdf_urls and html and passed:
                self.log(
                    "    (b) skipping Pensoft in-page PDF buffering in --autodev; "
                    "retaining full-text HTML if the bounded request did not finish"
                )
            if (pdf_urls and html and passed
                    and not skip_slow_pensoft_in_page):
                for u in pdf_urls[:3]:
                    self.log(f"    (b) in-page fetch: {u}")
                    try:
                        data = self._fetch_in_page(page, u)
                    except Exception as exc:  # noqa: BLE001
                        self.log(f"    (b) in-page fetch error: {exc}")
                        data = None
                    if data:
                        result.ok, result.data, result.pdf_url = True, data, u
                        result.acquisition_source = (
                            "translator"
                            if u in translated
                            else "in_page_fetch"
                        )
                        result.detail = f"ok via in-page fetch {u}"
                        return result

            # (c) navigate-capture: top-level navigation (Sec-Fetch-Dest: document)
            # for publishers that require it (JSTOR, LWW, interstitial-based).
            navigate_required = (
                (cand.publisher or "").lower()
                in {"jstor", "lww", "pmc", "sciencedirect", "pensoft", "copernicus"}
                or "sciencedirect" in final_host
                or (cand.label or "").lower().startswith("pmc-")
                or (
                    cand.open_access
                    and (cand.publisher or "").lower()
                    in {"taylor-francis", "oxford"}
                )
            )
            navigation_urls = [
                u for u in pdf_urls if u not in navigated_pdf_urls
            ][:2]
            if (navigation_urls and html and passed
                    and (not self.cfg.autodev or navigate_required)):
                if self._try_navigate_pdf_candidates(
                    navigation_urls,
                    referer,
                    result,
                    page=page if wiley_navigation else None,
                ):
                    return result
            elif pdf_urls and html and passed and self.cfg.autodev:
                self.log(
                    "    (c) skipping optional navigate-capture in --autodev "
                    "(avoids uninterruptible browser response-body stalls)"
                )

            # (d) click-for-pdf: always allow one strict PDF/Download control as
            # the final browser fallback. A publisher can leave a stale
            # citation_pdf_url while its visible button still mints a fresh,
            # session-bound URL. Re-clicking once is therefore useful even when
            # the href was already requested; the click has document/download
            # semantics rather than APIRequest/fetch semantics.
            if html and passed:
                self.log("    (d) clicking PDF/Download buttons (max 1 click)")
                click_result = self._click_for_pdf(
                    page, referer, tried=set(), max_clicks=1)
                result.viewer_opened = (
                    result.viewer_opened
                    or click_result.viewer_opened
                )
                result.viewer_url = click_result.viewer_url or result.viewer_url
                result.found_control = (
                    result.found_control or click_result.found_control
                )
                result.found_link = (
                    result.found_link or click_result.found_direct_url
                )
                result.failure_reason = (
                    click_result.failure_reason or result.failure_reason
                )
                if click_result.pdf_captured:
                    result.ok, result.data = True, click_result.data
                    result.pdf_url = click_result.pdf_url or result.pdf_url
                    result.acquisition_source = (
                        click_result.acquisition_source or "direct_download"
                    )
                    result.detail = (
                        "ok via click-for-pdf "
                        f"({result.acquisition_source})"
                    )
                    return result

            # Diagnose institutional authentication only AFTER every automatic
            # acquisition strategy failed. Publisher headers commonly advertise
            # "institutional access" even for an already-entitled/OA reader, so
            # early detection would create false positives. Here the failed
            # acquisition supplies the context needed to recognize terse gates
            # such as "Get Access" / "Restricted access" and access-portal
            # controls on platforms whose article body has no login sentence.
            # Re-read the live DOM: SPA publishers can render those controls well
            # after the initial post-navigation snapshot used for PDF discovery.
            try:
                access_html = page.content()
            except Exception:
                access_html = html
            try:
                access_url = page.url or result.final_url or ""
            except Exception:
                access_url = result.final_url or ""
            access_controls = self._rendered_access_controls(page)
            if (not cand.open_access and looks_institution_login_required(
                access_html,
                access_url,
                acquisition_failed=True,
                pdf_access_failed=result.found_link,
                rendered_controls=access_controls,
            )):
                result.needs_login = True
                result.detail = ("institutional login required before this publisher "
                                 "will provide the PDF")
                self.log(f"    [{cand.label}] no PDF: {result.detail}")

            # --- Zotero Connector: trigger save while the page is still alive ---
            # If Zotero is enabled and the page landed on a real article (not a
            # 404 / bot wall), trigger the Connector extension via its keyboard
            # shortcut. The Connector reads the live DOM, identifies the paper
            # via its translator, and tells Zotero desktop to download the PDF
            # using the browser's full session cookies. We wait briefly for the
            # extension to capture the page, then let the page close normally.
            if (self.cfg.zotero.enabled
                    and not cand.requires_strict_identity
                    and not result.not_found
                    and not result.url_error
                    and not result.blocked
                    and cand.landing_url):
                self.log("    [zotero] triggering Connector save on the live page...")
                if self.trigger_zotero_save(page):
                    result.zotero_triggered = True
                    self.log("    [zotero] Connector triggered — page data captured")
                    # Keep the page ALIVE while Zotero downloads the PDF. Zotero
                    # fetches the full-text PDF using the live browser session, so
                    # the tab must stay open until the download finishes (the
                    # page is closed by the finally block below only afterwards).
                    if self.zotero_wait_fn is not None:
                        self.log("    [zotero] keeping page alive while Zotero downloads the PDF...")
                        try:
                            if self.zotero_wait_fn():
                                result.zotero_pdf_ready = True
                                self.log("    [zotero] Zotero finished downloading the PDF")
                            else:
                                self.log("    [zotero] Zotero did not finish the PDF download in time")
                        except Exception as e:
                            self.log(f"    [zotero] error while waiting for Zotero PDF: {e}")

                return result

            # Did the identifier simply lead to no paper? Decide from the LANDING
            # only (its status / text), and only when no bot wall was involved — a
            # solved Cloudflare 403 must not be mistaken for "no paper" (see the
            # helper). A failed /pdf fetch is never fed in (it 404s for a merely
            # wrong PDF URL on an article that does exist).
            result.not_found, result.access_denied = landing_no_paper_verdict(
                nav_status, html, result.title, challenge_seen)

            # Classify the failure honestly.
            if result.viewer_opened:
                result.failure_reason = "viewer_open_capture_failed"
                result.detail = (
                    "PDF opened in Chrome's viewer, but its bytes could not be "
                    "captured or saved"
                )
            elif result.found_link:
                result.failure_reason = result.failure_reason or "download_failed"
                if cand.open_access:
                    result.detail = (
                        "open-access PDF link found, but the publisher did not "
                        "deliver PDF bytes (download/bot-protection failure)"
                    )
                else:
                    result.detail = (
                        "found a direct PDF link, but the browser session did not "
                        "capture PDF bytes; this is a download failure and does "
                        "not by itself prove missing login or entitlement"
                    )
            elif result.found_control:
                result.failure_reason = result.failure_reason or "download_failed"
                result.detail = (
                    "a PDF/download control was found, but it yielded neither "
                    "a direct PDF URL nor PDF bytes"
                )
            elif result.not_found:
                result.failure_reason = "not_found"
                result.detail = (f"identifier resolves to no paper "
                                 f"(HTTP {nav_status or '?'} / 'not found' page)")
            elif result.access_denied:
                result.failure_reason = "access_denied"
                result.detail = f"access denied (HTTP {nav_status}); no open-access copy found"
            elif result.paywalled:
                result.failure_reason = "access_denied"
                result.detail = "no PDF link found; page looks paywalled"
            else:
                result.failure_reason = (
                    result.failure_reason or "no_pdf_control"
                )
                result.detail = "could not locate a PDF link or button on the page"
            self.log(f"    [{cand.label}] no PDF: {result.detail}")

            # --- Zotero Connector: trigger save while the page is still alive ---
            # If Zotero is enabled and the page landed on a real article (not a
            # 404 / bot wall), trigger the Connector extension via its keyboard
            # shortcut. The Connector reads the live DOM, identifies the paper
            # via its translator, and tells Zotero desktop to download the PDF
            # using the browser's full session cookies. We wait briefly for the
            # extension to capture the page, then let the page close normally.
            if (self.cfg.zotero.enabled
                    and not cand.requires_strict_identity
                    and not result.not_found
                    and not result.url_error
                    and not result.blocked
                    and cand.landing_url):
                self.log("    [zotero] triggering Connector save on the live page...")
                if self.trigger_zotero_save(page):
                    result.zotero_triggered = True
                    self.log("    [zotero] Connector triggered — page data captured")
                    # Keep the page ALIVE while Zotero downloads the PDF. Zotero
                    # fetches the full-text PDF using the live browser session, so
                    # the tab must stay open until the download finishes (the
                    # page is closed by the finally block below only afterwards).
                    if self.zotero_wait_fn is not None:
                        self.log("    [zotero] keeping page alive while Zotero downloads the PDF...")
                        try:
                            if self.zotero_wait_fn():
                                result.zotero_pdf_ready = True
                                self.log("    [zotero] Zotero finished downloading the PDF")
                            else:
                                self.log("    [zotero] Zotero did not finish the PDF download in time")
                        except Exception as e:
                            self.log(f"    [zotero] error while waiting for Zotero PDF: {e}")


            return result
        finally:
            # In keep-open (debug) mode leave the tab so the user can inspect it —
            # EXCEPT in connect mode, where the window is the user's own Chrome, so
            # always close the tab WE opened (never a pre-existing user tab) to avoid
            # piling up one landing tab per item in their browser.
            if self._connected or not self.cfg.browser.keep_open:
                try:
                    page.close()
                except Exception:
                    pass
