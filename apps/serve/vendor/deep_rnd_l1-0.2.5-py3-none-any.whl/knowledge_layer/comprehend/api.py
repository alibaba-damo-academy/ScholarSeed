"""Single-document L1 extraction, independent of CLI and model providers."""
from __future__ import annotations

import logging

from knowledge_layer.core.control import VALID_TYPES, FatalLLMError, PipelineStop
from knowledge_layer.core.docio import clean_source_map, prepare_content, parse_sentences_index
from .options import ExtractionOptions, SourceImage
from .extract import classify_paper_type, compute_completeness, extract_card_combined, validate_card, validate_source_map

async def process_single_doc(llm, doc_id: str, doc: dict, depth: str,
                             with_source_map: bool, reclassify: bool,
                             stop: PipelineStop,
                             usage_out: dict, fmt=None,
                             registry_ctx: str = "",
                             type_log: list | None = None,
                             *, options: ExtractionOptions = ExtractionOptions(),
                             images: tuple[SourceImage, ...] = ()) -> tuple[dict, dict | None]:
    """处理单个文档。返回 (knowledge_object, source_map_entry | None)。

    fmt=None → 4 类固定卡片路由（默认）；fmt=FormatSpec → 按自定义格式抽（跳过 Classify）。
    旁路:分类时把真实类型(可能四类之外)收进 type_log,只统计不影响抽卡类型。
    """
    title = doc.get("title", "") or "(title unavailable)"
    abstract = doc.get("abstract", "") or ""

    # 1. 类型：自定义格式时不需要分类路由（格式已显式）；否则入参优先，缺失/强制 LLM 分类
    if fmt is not None:
        paper_type = fmt.name
    else:
        paper_type = doc.get("paper_type", "")
        if paper_type not in VALID_TYPES:
            paper_type = ""
        if reclassify or not paper_type:
            registry_out: dict = {}
            paper_type = await classify_paper_type(
                llm, title, abstract or doc.get("classification_context", ""), registry_ctx=registry_ctx,
                stop=stop, where=f"{doc_id}/classify",
                usage_out=usage_out, registry_out=registry_out,
                attempts=options.llm_attempts, timeout=options.timeout,
            )
            if registry_out and type_log is not None:
                type_log.append({"title": doc.get("title", ""),
                                 "registry_type": registry_out.get("registry_type"),
                                 "routed_type": paper_type,
                                 "definition": registry_out.get("definition", "")})

    # 2. 内容准备（#N 编号 + partial 截断）
    content = prepare_content(doc, depth)

    text_index = parse_sentences_index(content)
    image_index = {image.number: image.label.replace("\n", " ") for image in images}
    if len(image_index) != len(images) or set(image_index) & set(text_index):
        raise ValueError("Image source IDs must be unique and distinct from text IDs")
    if images:
        content += "\n" + "\n".join(
            f"#{number} [Attached image source] {label}"
            for number, label in image_index.items()
        )

    # 3. 提取 + 校验重试
    card, common_fields, card_source_map, units = None, {}, {}, []
    repair_context = None
    errors = []
    sent_idx = parse_sentences_index(content) if with_source_map else {}
    for attempt in range(options.validation_attempts):
        try:
            card, common_fields, card_source_map, units = await extract_card_combined(
                llm, paper_type, title, content,
                with_source_map=with_source_map,
                stop=stop, where=f"{doc_id}/card", usage_out=usage_out, fmt=fmt,
                repair_context=repair_context, options=options, images=images,
            )
            errors = (fmt.validate(card, common_fields, depth) if fmt is not None
                      else validate_card(paper_type, depth, card, common_fields))
            if with_source_map:
                card_source_map = clean_source_map(card_source_map, sent_idx)
            if with_source_map:  # source_map 不合规(集合键塌陷/缺分条键)也触发重抽
                errors = errors + validate_source_map(card, card_source_map)
            if not errors:
                break
            repair_context = {"errors": errors, "previous": {
                "card": card, "common_fields": common_fields,
                "source_map": card_source_map, "units": units}}
            logging.warning(
                f"[RETRY] {doc_id}: card validation failed "
                f"(attempt {attempt + 1}/{options.validation_attempts}): {errors}"
            )
        except (FatalLLMError, RuntimeError):
            raise
        except Exception as exc:
            logging.warning(
                f"[RETRY] {doc_id}: card extraction error "
                f"(attempt {attempt + 1}/{options.validation_attempts}): {exc}"
            )
            if attempt + 1 >= options.validation_attempts:
                raise

    # 4. 质量注记 + 完整度标记
    quality_notes = []
    if depth == "metadata_only":
        quality_notes.append("Reading depth is 'metadata_only' — extracted from abstract only.")
    if not (doc.get("content") or "").strip():
        quality_notes.append("No full text available.")
    if not abstract or len(abstract) < 100:
        quality_notes.append(f"Abstract is very short ({len(abstract or '')} chars).")
    # source_map 兜底:重试用尽仍不合规 → 不静默:清集合键 + 如实标注,
    # 避免"标 complete 却部分元组无溯源"。
    if with_source_map and card:
        sm_errors = validate_source_map(card, card_source_map)
        if sm_errors:
            if isinstance(card_source_map, dict):
                card_source_map.pop("card.experiments.results", None)
            quality_notes.append("results source_map incomplete — " + sm_errors[0])

    ko = {
        "docId": doc_id,
        "title": doc.get("title", ""),
        "abstract": abstract,
        "year": doc.get("year"),
        "paper_type": paper_type,
        "relevance_level": doc.get("relevance_level", "L1"),
        "reading_depth": depth,
        "card": card,
        "common_fields": common_fields,
        "completeness": (fmt.completeness(card, common_fields, depth) if fmt is not None
                         else compute_completeness(paper_type, depth, card, common_fields)),
    }
    if fmt is not None:
        ko["format"] = fmt.name
    if units:
        ko["units"] = units
    if quality_notes:
        ko["quality_notes"] = " | ".join(quality_notes)

    ko["extraction_quality"] = {
        "status": "DEGRADED" if errors else "READY",
        "errors": errors,
        "attempts": attempt + 1,
        "source_map_required": with_source_map,
    }

    # 5. source_map（字段路径 → 句子 ID → 句子原文）
    source_map_entry = None
    if with_source_map and card_source_map:
        sent_idx = parse_sentences_index(content)
        cleaned = clean_source_map(card_source_map, sent_idx)  # 剔除指向不存在句子的 id
        if cleaned:
            all_ids = {i for ids in cleaned.values() for i in ids}
            source_map_entry = {
                "docId": doc_id,
                "title": doc.get("title", ""),
                "card_mapping": cleaned,
                "sentences": {str(sid): text_index[sid] for sid in sorted(all_ids) if sid in text_index},
                **({"images": {str(sid): {"kind": "image", "label": image_index[sid]}
                               for sid in sorted(all_ids) if sid in image_index}} if images else {}),
            }
    return ko, source_map_entry


