"""LLM 调用辅助 — 重试、超时、JSON 提取、usage 合并。"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

from .control import (
    DocFailedError,
    FatalLLMError,
    PipelineStop,
    PipelineStopped,
    TruncatedOutputError,
    classify_http_error,
)

# Inner LLM call retry (API/network/parse failures); CLI 可在启动时覆盖
LLM_RETRIES = 3


def merge_usage(target: dict, source: dict):
    for key in ("prompt_cache_hit_tokens", "prompt_cache_miss_tokens",
                "completion_tokens", "prompt_tokens"):
        if key in source:
            target[key] = target.get(key, 0) + (source[key] or 0)
    if source.get("_provider"):
        target["_provider"] = source["_provider"]


def extract_json_from_response(text: str) -> Any:
    """Extract JSON from LLM response, handling markdown code blocks."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        brace_start = text.find("{")
        brace_end = text.rfind("}")
        if brace_start != -1 and brace_end != -1:
            try:
                return json.loads(text[brace_start:brace_end + 1])
            except json.JSONDecodeError:
                pass
        return None


def as_dict(parsed) -> dict:
    """期望 JSON 对象时的防御：模型偶尔回数组/标量，按"无内容"处理而不是 .get 崩溃。"""
    return parsed if isinstance(parsed, dict) else {}


def dict_items(seq) -> list:
    """列表里只留对象元素（模型偶尔混入字符串/数字）。"""
    return [x for x in seq if isinstance(x, dict)] if isinstance(seq, list) else []


async def llm_call(llm, system: str, user: str, *,
                   expect_json: bool,
                   max_tokens: Optional[int] = None,
                   temperature: Optional[float] = None,
                   cache_prefix: Optional[str] = None,
                   stop: Optional[PipelineStop] = None,
                   where: str = "?",
                   usage_out: Optional[dict] = None,
                   timeout: Optional[float] = None,
                   attempts: Optional[int] = None, images: tuple = ()) -> tuple[Any, dict]:
    """1 次 LLM 调用 + 网络重试 (LLM_RETRIES 次). 返回 (parsed_or_text, usage).

    异常语义: 致命错误 (401/402/422) 立即抛 FatalLLMError; 熔断/停止事件抛
    PipelineStopped (停整批); 重试耗尽抛 DocFailedError (单文档失败, 批次应继续)。
    usage_out 会累计每次尝试的 usage（含失败尝试）。
    timeout 是整体硬超时 (asyncio.wait_for)，防止 keep-alive 心跳掩盖卡死。
    """
    effective_timeout = timeout if timeout is not None else getattr(llm, "timeout", None)
    retry_count = LLM_RETRIES if attempts is None else attempts
    if retry_count < 1:
        raise ValueError("attempts must be positive")
    last_exc: Optional[Exception] = None
    for attempt in range(retry_count):
        if stop is not None and stop.should_stop():
            raise PipelineStopped(f"pipeline stopped: {stop.fatal_reason}")
        try:
            chat_coro = llm.chat(system, user, max_tokens=max_tokens,
                                 json_mode=expect_json, cache_prefix=cache_prefix,
                                 temperature=temperature, **({"images": images} if images else {}))
            if effective_timeout is not None:
                text, usage = await asyncio.wait_for(chat_coro, timeout=effective_timeout)
            else:
                text, usage = await chat_coro
            if usage_out is not None:
                merge_usage(usage_out, usage)
            truncated = (usage or {}).get("_finish_reason") == "length"
            if truncated:
                logging.warning(f"[LLM_TRUNCATED] {where}: 输出撞上 max_tokens 上限被截断")
            if expect_json:
                parsed = extract_json_from_response(text)
                if parsed is None:
                    if truncated:
                        raise TruncatedOutputError(
                            f"LLM output truncated at max_tokens ({where}); "
                            f"调大 --max-tokens 或缩小单次输入")
                    raise ValueError(f"JSON parse failed: {text[:200]!r}")
                if stop is not None:
                    await stop.on_success()
                return parsed, usage
            if stop is not None:
                await stop.on_success()
            return text.strip(), usage
        except TruncatedOutputError:
            raise  # 不是服务健康问题：不计熔断，也不拿同一 prompt 白白重试
        except Exception as exc:
            last_exc = exc
            code, fatal = classify_http_error(exc)
            if fatal:
                if stop is not None:
                    await stop.on_error(exc, where)
                raise FatalLLMError(code or 0, str(exc)) from exc
            if stop is not None:
                triggered = await stop.on_error(exc, where)
                if triggered:
                    raise PipelineStopped(f"pipeline stopped: {stop.fatal_reason}") from exc
            if attempt + 1 < retry_count:
                logging.warning(
                    f"[LLM_RETRY] {where}: attempt {attempt + 2}/{retry_count}, "
                    f"error={type(last_exc).__name__}: {str(last_exc)[:120]}"
                )
                await asyncio.sleep(1.5 * (attempt + 1))
    raise DocFailedError(
        f"LLM call failed after {retry_count} attempts ({where}): {last_exc}"
    )
