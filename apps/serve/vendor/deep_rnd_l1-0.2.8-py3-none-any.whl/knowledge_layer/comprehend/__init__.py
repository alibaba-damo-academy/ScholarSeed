"""Provider-independent single-paper extraction API."""

from .api import process_single_doc
from .options import PROMPT_VERSION, VERSION, ExtractionOptions, SourceImage

__all__ = [
    "process_single_doc",
    "ExtractionOptions",
    "SourceImage",
    "PROMPT_VERSION",
    "VERSION",
]

from .extract import classify_paper_type
from .protocol import (
    BLOCK_VERSION,
    PAPER_TYPES,
    ExtractionProtocolError,
    ExtractionResponseClient,
    ExtractionSyntaxError,
    build_block_prompt,
    extraction_blocks,
)

__all__ += [
    "BLOCK_VERSION",
    "PAPER_TYPES",
    "ExtractionProtocolError",
    "ExtractionSyntaxError",
    "ExtractionResponseClient",
    "build_block_prompt",
    "extraction_blocks",
    "classify_paper_type",
]
