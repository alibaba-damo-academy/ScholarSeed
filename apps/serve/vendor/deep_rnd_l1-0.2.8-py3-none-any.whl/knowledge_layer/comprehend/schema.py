"""自定义格式规格（FormatSpec）——「你给格式，我按格式抽」。

调用方给一个格式 JSON，Comprehend 就按它抽，而不是固定的 4 类卡片。格式定义了：
  - 要抽哪些字段（card_fields）→ 渲染成提取 prompt
  - 哪些字段必填（required_fields）→ 驱动校验与完整度标记
  - 哪些字段要溯源（source_map_fields）→ 缺省时自动从 card_fields 叶子推断
  - 可选：KnowledgeUnit 拆分 + 角色标注（units，如 ideation 的 anchor/pressure/...）

格式文件示例（method 复现场景）：
{
  "name": "reproduce",
  "card_title": "Reproduction Card",
  "card_fields": {
    "method_name": "The method/model name",
    "architecture": "Architecture details needed to reimplement",
    "hyperparameters": {"lr": "learning rate", "batch_size": "...", "epochs": "..."},
    "datasets": ["dataset name + split used"],
    "key_results": "Headline numbers to reproduce (with exact values)"
  },
  "required_fields": ["method_name", "hyperparameters", "key_results"],
  "min_lengths": {"card.architecture": 40},
  "units": {"enabled": true, "roles": ["anchor","pressure","component","bridge"],
            "role_descriptions": {"anchor": "...", "pressure": "...",
                                  "component": "...", "bridge": "..."},
            "target_count": "5-10"}
}
"""
from __future__ import annotations

import json
import re

from .prompts import build_custom_prompt


def _render_skeleton(fields, indent=1):
    """把 card_fields（嵌套 dict，叶子是描述字符串）渲染成带描述的 JSON 骨架。"""
    pad = "  " * indent
    if isinstance(fields, dict):
        lines = []
        for k, v in fields.items():
            if isinstance(v, (dict, list)):
                lines.append(f'{pad}"{k}": {_render_skeleton(v, indent + 1)}')
            else:
                lines.append(f'{pad}"{k}": "{v}"')
        return "{\n" + ",\n".join(lines) + "\n" + "  " * (indent - 1) + "}"
    if isinstance(fields, list):
        inner = fields[0] if fields else "item description"
        if isinstance(inner, (dict, list)):
            return "[" + _render_skeleton(inner, indent + 1) + "]"
        return f'["{inner}"]'
    return f'"{fields}"'


def _leaf_paths(fields, prefix="card"):
    """从 card_fields 推断可溯源的叶子字段路径（数组用 [i]）。"""
    out = []
    if isinstance(fields, dict):
        for k, v in fields.items():
            out.extend(_leaf_paths(v, f"{prefix}.{k}"))
    elif isinstance(fields, list):
        inner = fields[0] if fields else None
        if isinstance(inner, (dict, list)):
            out.extend(_leaf_paths(inner, f"{prefix}[i]"))
        else:
            out.append(f"{prefix}[i]")
    else:
        out.append(prefix)
    return out


class FormatSpec:
    def __init__(self, raw: dict):
        if not isinstance(raw, dict) or not raw.get("card_fields"):
            raise ValueError("format spec must be a JSON object with a 'card_fields' key")
        self.name = raw.get("name", "custom")
        self.card_title = raw.get("card_title", f"{self.name} Card")
        self.card_fields = raw["card_fields"]
        self.required_fields = raw.get("required_fields") or []
        self.min_lengths = raw.get("min_lengths") or {}
        self.units = raw.get("units")
        # 溯源字段：显式给了就用，否则从叶子自动推断（含 common_fields 常规项）
        smf = raw.get("source_map_fields")
        if smf is None:
            smf = _leaf_paths(self.card_fields) + [
                "common_fields.core_contribution", "common_fields.claims[i]",
                "common_fields.limitations"]
        self.source_map_fields = smf

    @classmethod
    def load(cls, path: str) -> "FormatSpec":
        with open(path, "r", encoding="utf-8") as f:
            return cls(json.load(f))

    def card_prompt(self) -> str:
        skeleton = _render_skeleton(self.card_fields)
        # 转义花括号供 str.format 场景安全（本 prompt 不再经 .format，直接返回）
        return (f"Extract the following structured card. Respond in JSON format:\n"
                f"{skeleton}\n\n"
                f"Be precise and factual. For any field whose information is genuinely "
                f"absent from the text, set it to null (keep the key, value null) — do NOT "
                f"invent content and do NOT write placeholder notes.")

    def build_prompt(self, with_source_map: bool) -> str:
        return build_custom_prompt(self.card_title, self.card_prompt(),
                                   with_source_map, self.source_map_fields, self.units)

    # ---- 校验 + 完整度（Schema 纪律：字段可空但形状不变，缺失显式标注）----
    def validate(self, card: dict, common_fields: dict, depth: str) -> list:
        errors = []
        if not common_fields:
            errors.append("common_fields is required")
        else:
            tldr = common_fields.get("tldr")
            if not tldr:
                errors.append("common_fields.tldr is required")
            elif len(str(tldr).split()) < 8 and len(re.findall(r"[\u4e00-\u9fff]", str(tldr))) < 16:
                errors.append(f"common_fields.tldr too short ({len(str(tldr).split())} words)")
        if not card:
            errors.append(f"card must not be null for depth={depth}")
            return errors
        if depth == "metadata_only":
            return errors
        for f in self.required_fields:
            cur = card
            ok = True
            for part in f.split("."):
                if isinstance(cur, dict) and cur.get(part):
                    cur = cur[part]
                else:
                    ok = False
                    break
            if not ok:
                errors.append(f"card.{f} is required by format '{self.name}'")
        for path, minlen in self.min_lengths.items():
            cur = card if not path.startswith("card.") else card
            key = path[len("card."):] if path.startswith("card.") else path
            node = card
            for part in key.split("."):
                node = node.get(part) if isinstance(node, dict) else None
            if isinstance(node, str) and len(node) < minlen:
                errors.append(f"{path} too short ({len(node)} < {minlen})")
        return errors

    def completeness(self, card: dict, common_fields: dict, depth: str) -> dict:
        missing = self.validate(card or {}, common_fields or {}, depth)
        return {"complete": not missing, "missing": missing}
