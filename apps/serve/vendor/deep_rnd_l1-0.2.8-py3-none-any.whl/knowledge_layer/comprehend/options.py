"""Immutable per-extraction controls shared by product and research callers."""
from dataclasses import dataclass
from math import isfinite

VERSION = "0.2.8"
PROMPT_VERSION = "l1/v2.6"
LANGUAGES = {"en": "English", "zh": "Simplified Chinese"}

@dataclass(frozen=True)
class ExtractionOptions:
    validation_attempts: int = 3
    llm_attempts: int = 1
    timeout: float | None = None
    output_language: str = "en"
    supports_cache_prefix: bool = False

    def __post_init__(self):
        if any(type(value) is not int or value < 1 for value in (self.validation_attempts, self.llm_attempts)):
            raise ValueError("Extraction attempts must be positive")
        if self.output_language not in LANGUAGES:
            raise ValueError("Unsupported extraction language")
        if self.timeout is not None and (not isfinite(self.timeout) or self.timeout <= 0):
            raise ValueError("Extraction timeout must be positive")


@dataclass(frozen=True)
class SourceImage:
    """Optional caller-owned image. IDs share the numbered input namespace."""
    number: int
    label: str
    media_type: str
    data: str

    def __post_init__(self):
        if type(self.number) is not int or self.number < 1 or not self.label.strip():
            raise ValueError("Image source requires a positive ID and label")
        if self.media_type not in ("image/png", "image/jpeg") or not self.data:
            raise ValueError("Image source requires encoded PNG or JPEG data")
