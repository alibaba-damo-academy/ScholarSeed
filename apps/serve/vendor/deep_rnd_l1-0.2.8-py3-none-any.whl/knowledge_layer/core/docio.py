"""文档输入契约 — 加载/校验 docs.json、内容规范化（#N 编号）、阅读深度决策、截断。

原子输入契约（docs.json，一个 JSON 对象，key 为 doc_id）：
  {
    "<doc_id>": {
      "title": "...",                  // 必填
      "abstract": "...",               // 可选
      "content": "...",                // 可选全文；纯文本 或 已带 "#N " 行编号
      "relevance_level": "L1|L2|L3",   // 可选，默认 L1（决定阅读深度）
      "paper_type": "method|benchmark|survey|theory",  // 可选，缺省时由 LLM 分类
      "bib": {"<bib_id>": {"title": "..."}},           // 可选（relate-delta 用）
      "year": 2024                     // 可选
    }
  }
不依赖任何目录约定；convert 子命令可从综述工程的 02_retrieval/ 生成此格式。
"""
from __future__ import annotations

import os
import re

from .control import load_json

_SENT_LINE_RE = re.compile(r"^#(\d+)\s+(.*)$")

# Partial 模式动态截断参数：≤ NO_TRIM 不截断；超过则取前 TRIM_RATIO，上限 TRIM_CAP
PARTIAL_NO_TRIM_THRESHOLD = 60000
PARTIAL_TRIM_RATIO = 0.70
PARTIAL_TRIM_CAP = 80000


# ============================================================================
# 输入加载
# ============================================================================

def load_docs(input_path: str) -> dict:
    """加载并粗校验 docs.json。返回 {doc_id: doc_dict}。"""
    docs = load_json(input_path, None)
    if not isinstance(docs, dict) or not docs:
        raise ValueError(f"Input {input_path} must be a non-empty JSON object keyed by doc_id")
    bad = [k for k, v in docs.items() if not isinstance(v, dict) or not v.get("title")]
    if bad:
        raise ValueError(f"{len(bad)} docs missing 'title' (e.g. {bad[:3]})")
    return docs


def convert_retrieval_dir(retrieval_dir: str) -> dict:
    """适配器：把综述工程 02_retrieval/(selected_paper.json + paper_info.json) 合并为 docs.json 格式。

    仅做字段搬运，不做任何 LLM 调用。paper_info 缺失的条目退化为 metadata-only 文档。
    """
    entity = load_json(os.path.join(retrieval_dir, "selected_paper.json"), {})
    paper_info = load_json(os.path.join(retrieval_dir, "paper_info.json"), {})
    if not entity:
        raise ValueError(f"No selected_paper.json under {retrieval_dir}")

    title_index = {}
    for key, value in paper_info.items():
        if isinstance(value, dict) and value.get("title"):
            title_index[value["title"].strip().lower()] = key

    docs = {}
    for pid, ent in entity.items():
        if not isinstance(ent, dict):
            continue
        info = paper_info.get(pid)
        if info is None and ent.get("title"):
            key = title_index.get(ent["title"].strip().lower())
            info = paper_info.get(key) if key else None
        info = info if isinstance(info, dict) else {}

        parse_dict = info.get("parse_dict")
        if isinstance(parse_dict, dict):
            content = parse_dict.get("sections", "")
        else:
            content = info.get("sections") or info.get("sentences") or ""

        doc = {
            "title": ent.get("title", ""),
            "abstract": ent.get("abstract", ""),
            "year": ent.get("year"),
            "relevance_level": ent.get("relevance_level", "L1"),
        }
        if ent.get("paper_type"):
            doc["paper_type"] = ent["paper_type"]
        if isinstance(content, str) and content.strip():
            doc["content"] = content
        bib = info.get("bib") or info.get("bib_info")
        if isinstance(bib, dict) and bib:
            doc["bib"] = bib
        if info.get("arxiv_id") or ent.get("arxiv_id"):
            doc["arxiv_id"] = info.get("arxiv_id") or ent.get("arxiv_id")
        docs[pid] = doc
    return docs


# ============================================================================
# 内容规范化（#N 句子编号）
# ============================================================================

def has_numbered_lines(text: str) -> bool:
    for line in text.splitlines()[:50]:
        if _SENT_LINE_RE.match(line):
            return True
    return False


def number_sentences(text: str) -> str:
    """给纯文本按句/行加 "#N " 编号（source_map 溯源的锚点）。已编号则原样返回。"""
    if has_numbered_lines(text):
        return text
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if len(lines) <= 1:
        # CJK 标点后无空格也切句；ASCII 标点要求空格（避免切开小数 3.5）
        sentences = re.split(r"(?<=[。！？])\s*|(?<=[.!?])\s+", text.strip())
        lines = [s.strip() for s in sentences if s.strip()]
    if not lines:
        return text
    return "\n".join(f"#{i + 1} {s}" for i, s in enumerate(lines))


def parse_sentences_index(numbered_text: str) -> dict[int, str]:
    """把 #N 编号文本解析为 {id: text}。"""
    idx: dict[int, str] = {}
    for line in numbered_text.splitlines():
        m = _SENT_LINE_RE.match(line)
        if m:
            idx[int(m.group(1))] = m.group(2)
        elif line.startswith("  ") and idx:
            # Indented continuations belong to the preceding source block.
            sid = next(reversed(idx))
            idx[sid] += "\n" + line[2:]
    return idx


def clean_source_map(mapping: dict, sent_idx: dict) -> dict:
    """只保留能在原文句子索引里解析的 id；丢弃空字段。

    LLM 偶尔会在溯源里吐出 0 号或越界的句子 id，导致 mapping 指向不存在的句子。
    在生成端就剔除，保证 source_map 自洽（lint 的 SM004/DSM004 才不会误伤）。
    """
    out: dict = {}
    for field, ids in (mapping or {}).items():
        if not isinstance(ids, list):
            continue
        kept = [i for i in ids if type(i) is int and i in sent_idx]
        if kept:
            out[field] = kept
    return out


# ============================================================================
# 阅读深度决策 + 内容准备
# ============================================================================

def determine_reading_depth(relevance_level: str, has_full_text: bool) -> str:
    """importance × 全文可得性 → full / partial / metadata_only。"""
    if not has_full_text:
        return "metadata_only"
    if relevance_level == "L3":
        return "metadata_only"
    if relevance_level == "L2":
        return "partial"
    return "full"


def trim_content_partial(text: str) -> tuple[str, bool]:
    """Partial 模式动态截断：≤60k 不截；否则取前 min(len×0.7, 80k)，按行边界。"""
    if len(text) <= PARTIAL_NO_TRIM_THRESHOLD:
        return text, False
    budget = min(int(len(text) * PARTIAL_TRIM_RATIO), PARTIAL_TRIM_CAP)
    kept: list[str] = []
    used = 0
    for line in text.splitlines(keepends=True):
        if used + len(line) > budget:
            if not kept:  # 单行本身超预算：硬切该行
                kept.append(line[:budget])
            break
        kept.append(line)
        used += len(line)
    return "".join(kept) + "\n\n[...content truncated...]", True


def prepare_content(doc: dict, depth: str) -> str:
    """根据深度准备送入 LLM 的正文（带 #N 编号）。"""
    title = doc.get("title", "") or "(title unavailable)"
    abstract = doc.get("abstract", "") or ""
    content = doc.get("content", "") or ""

    if depth != "metadata_only" and content.strip():
        numbered = number_sentences(content)
        if depth == "partial":
            numbered, _ = trim_content_partial(numbered)
        return numbered
    if abstract:
        return number_sentences(abstract)
    return f"Title: {title}"
