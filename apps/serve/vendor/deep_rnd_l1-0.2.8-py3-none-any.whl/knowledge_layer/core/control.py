"""运行控制与 IO — 错误分类、熔断、进度追踪、优雅关停、原子写。

自包含：不依赖任何工程目录约定，所有路径由调用方传入。
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import signal
import sys
import tempfile
import time
from datetime import datetime
from typing import Optional

VALID_TYPES = ("method", "benchmark", "survey", "theory")


# ============================================================================
# JSON IO
# ============================================================================

def load_json(path: str, default=None):
    if not path or not os.path.exists(path):
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return default if default is not None else {}


def atomic_write_json(path: str, payload):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        prefix=".tmp_", suffix=".json", dir=os.path.dirname(path) or "."
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise


# ============================================================================
# Fatal Error / Pipeline Stop
# ============================================================================

class FatalLLMError(Exception):
    """不可恢复的 LLM 错误 (401/402/422 等), 必须立即停止本次运行."""

    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"FATAL HTTP {code}: {message}")


class PipelineStopped(RuntimeError):
    """熔断/致命错误已触发, 整条流水线停止 (区别于单文档失败)."""


class DocFailedError(RuntimeError):
    """单文档 LLM 重试耗尽 — 记失败、跳过该文档、批次继续."""


class TruncatedOutputError(DocFailedError):
    """输出撞上 max_tokens 被截断且 JSON 不完整 — 同一 prompt 重试只会再截断，直接判单文档失败."""


_FATAL_CODES = {401, 402, 422}

# 字符串回退只认明确的状态码上下文: 错误消息可能内嵌模型输出/论文片段
# (如 JSON parse failed 携带的原文摘录), 裸 " 401"/"(401)" 会把文档里的数字误判为致命错误
_HTTP_CODE_RE = re.compile(
    r"(?:HTTP|[Ss]tatus(?:[ _]?code)?|[Ee]rror code)\D{0,3}(401|402|422|429|500|503)\b")


def classify_http_error(exc: Exception) -> tuple[Optional[int], bool]:
    """返回 (status_code 或 None, is_fatal)."""
    # 通用: 带整数 status_code 属性的异常 (anthropic.APIStatusError 等), 不走字符串匹配
    code = getattr(exc, "status_code", None)
    if isinstance(code, int):
        return code, code in _FATAL_CODES
    m = _HTTP_CODE_RE.search(str(exc))
    if m:
        code = int(m.group(1))
        return code, code in _FATAL_CODES
    return None, False


class PipelineStop:
    """全局连续失败计数 + 致命错误探测; 触发停止时 set Event."""

    def __init__(self, consec_threshold: int = 10):
        self.consec = 0
        self.threshold = consec_threshold
        self.lock = asyncio.Lock()
        self.fatal_reason: Optional[str] = None
        self.stop_event = asyncio.Event()
        self.total_errors = 0

    async def on_error(self, exc: Exception, where: str) -> bool:
        async with self.lock:
            self.total_errors += 1
            self.consec += 1
            code, fatal = classify_http_error(exc)
            if fatal:
                self.fatal_reason = (
                    f"FATAL HTTP {code} ({where}): {str(exc)[:200]} "
                    f"-- stopping immediately"
                )
                self.stop_event.set()
                return True
            if self.consec >= self.threshold:
                self.fatal_reason = (
                    f"reached {self.threshold} consecutive errors "
                    f"({where}, last: {str(exc)[:200]})"
                )
                self.stop_event.set()
                return True
        return False

    async def on_success(self) -> None:
        async with self.lock:
            self.consec = 0

    def should_stop(self) -> bool:
        return self.stop_event.is_set()


# ============================================================================
# Progress
# ============================================================================

class ProgressTracker:
    """增量写 progress.json，可供外部轮询；终态含 quality_stats."""

    def __init__(self, progress_path: str, total: int):
        self.path = progress_path
        self.total = total
        self.processed = 0
        self.failed = 0
        self.failed_docs: list[dict] = []
        self.started_at = datetime.now().isoformat()
        self._start_time = time.time()
        self._write()

    def _write(self):
        elapsed = time.time() - self._start_time
        remaining = 0
        if self.processed > 0:
            remaining = elapsed / self.processed * (self.total - self.processed - self.failed)
        atomic_write_json(self.path, {
            "status": "running",
            "total": self.total,
            "processed": self.processed,
            "failed": self.failed,
            "started_at": self.started_at,
            "updated_at": datetime.now().isoformat(),
            "elapsed_sec": round(elapsed, 1),
            "estimated_remaining_sec": round(remaining, 1),
            "failed_docs": self.failed_docs[-20:],
        })

    def record_success(self):
        self.processed += 1
        self._write()

    def record_failure(self, doc_id: str, error: str):
        self.failed += 1
        self.failed_docs.append({"docId": doc_id, "error": error})
        self._write()

    def finalize(self, status: str, quality_stats: dict):
        atomic_write_json(self.path, {
            "status": status,
            "total": self.total,
            "processed": self.processed,
            "failed": self.failed,
            "started_at": self.started_at,
            "completed_at": datetime.now().isoformat(),
            "elapsed_sec": round(time.time() - self._start_time, 1),
            "failed_docs": self.failed_docs,
            "quality_stats": quality_stats,
        })


class GracefulShutdown:
    """SIGINT/SIGTERM handler for graceful shutdown."""

    def __init__(self):
        self.should_stop = False
        signal.signal(signal.SIGINT, self._handler)
        signal.signal(signal.SIGTERM, self._handler)

    def _handler(self, signum, frame):
        if self.should_stop:
            sys.exit(1)
        self.should_stop = True
        print("\n[SIGINT] Graceful shutdown requested. Waiting for in-flight tasks...",
              file=sys.stderr)
