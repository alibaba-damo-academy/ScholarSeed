"""Research knowledge extraction primitives."""
